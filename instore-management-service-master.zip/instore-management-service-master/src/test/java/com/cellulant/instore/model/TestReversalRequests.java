package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestReversalRequests {
	
	@InjectMocks
	ReversalRequests reversalRequests;

	@Test
    void testBean() {
		
		ReversalRequests reversalRequests = new ReversalRequests();
		ReversalRequests allArgsReversalRequests1 = new ReversalRequests(1l, "abc", 1, 1l, "abc", 1d, 1, 1);
	
		reversalRequests.setReversalRequestId(1l);
		reversalRequests.setBeepTransactionId( "abc");
		reversalRequests.setReferenceId(1);
		reversalRequests.setClientId(1l);
		reversalRequests.setMessage("abc");
		reversalRequests.setAmount(1d);
		reversalRequests.setStatus(1);
		reversalRequests.setActive(1);
		
		
	
		assertEquals(1l, (long)reversalRequests.getReversalRequestId());
		assertEquals("abc", reversalRequests.getBeepTransactionId());
		assertEquals(1,(int)reversalRequests.getReferenceId());
		assertEquals(1l, (long)reversalRequests.getClientId());
		assertEquals("abc",reversalRequests.getMessage());
		assertEquals(1, (int)reversalRequests.getStatus());
		assertEquals(1, (int)reversalRequests.getActive());
		
		reversalRequests.equals(allArgsReversalRequests1);
		reversalRequests.hashCode();

	}
	
	@Test
	void onCreate() {
		reversalRequests.onCreate();
	}

	@Test
	void onUpdate() {
		reversalRequests.onUpdate();
		
	}

	@Test
	void testToString() {
		
		assertNotNull(reversalRequests.toString());
	}

}
