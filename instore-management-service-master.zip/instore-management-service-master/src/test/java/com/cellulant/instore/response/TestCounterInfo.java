package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestCounterInfo {
	
	
	@InjectMocks
	private CounterInfo counterInfo;
	
	@Test 
	void testBean() {
		CounterInfo counterInfo = new CounterInfo();
		CounterInfo allArgsCounterInfo =  new CounterInfo("1", "abc", "abc", "abc", "abc", "abc");
		
		counterInfo.setCounterCode("1");
		counterInfo.setCounterName("abc");
		counterInfo.setEmailAddress("abc");
		counterInfo.setMsisdn("abc");
		counterInfo.setStoreName("abc");
		counterInfo.setUserName("abc");
		
		assertEquals("1", counterInfo.getCounterCode());
		assertEquals("abc", counterInfo.getCounterName());
		assertEquals("abc", counterInfo.getEmailAddress());
		assertEquals("abc", counterInfo.getMsisdn());
		assertEquals("abc", counterInfo.getStoreName());
		assertEquals("abc", counterInfo.getUserName());
	}
	
	@Test
	void testToString() {
		assertNotNull(counterInfo.toString());
	}

}
