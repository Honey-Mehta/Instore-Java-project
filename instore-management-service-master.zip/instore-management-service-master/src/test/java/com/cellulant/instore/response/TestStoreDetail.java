package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoreDetail {
	
	@InjectMocks
	StoreDetail storeDetail;
	
	@Test
	void testBeans() {
		StoreDetail storeDetail = new StoreDetail();
		StoreDetail allArgsStoreDetail =  new StoreDetail(1l, "abc", "123", "abc", "123");
		StoreDetail detail = storeDetail.builder().counterName("abc").storeMsisdn("123").build();
		
		storeDetail.setCounterMsisdn("123");
		storeDetail.setCounterName("abc");
		storeDetail.setStoreId(1l);
		storeDetail.setStoreMsisdn("123");
		storeDetail.setStoreName("abc");
		
		assertEquals("123", storeDetail.getCounterMsisdn());
		assertEquals("abc", storeDetail.getCounterName());
		assertEquals(1l, storeDetail.getStoreId());
		assertEquals("123", storeDetail.getStoreMsisdn());
		assertEquals("abc", storeDetail.getStoreName());
	}
	
	@Test
	void testToString() {
		
		assertNotNull(storeDetail.toString());
	}

}
