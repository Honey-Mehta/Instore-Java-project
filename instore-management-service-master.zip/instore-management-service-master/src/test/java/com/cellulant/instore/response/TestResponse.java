package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestResponse {
	
	@InjectMocks
	private Response response;
	
	@Test
	void testBean() {
		
		Response response =  new Response();
		Response allArgsResponse =  new Response(1, "abc");
		
		response.setMessage("abc");
		response.setStatusCode(123);
		response.setSuccess(false);
		
        
        assertEquals(123,response.getStatusCode());
        assertEquals("abc", response.getMessage());
        
       
		
	}
	
	@Test
	void testToString() {
		response.toString();
		assertNotNull(response.toString());
	}

}
