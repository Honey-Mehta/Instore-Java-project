package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoresParam {
	
	@InjectMocks
	StoresParam storesParam;
	
	@Test
	void testBean() {
		
		StoresParam storesParam = new StoresParam();
		StoresParam allArgsStoresParam =  new StoresParam(1l, "abc", "abc", "abc", "123", "abc", 2l,"abc");
		
		storesParam.setAddress("abc");
		storesParam.setCity("abc");
		storesParam.setCountry("abc");
		storesParam.setMsisdn("123");
		storesParam.setStoreId(1l);
		storesParam.setStoreName("abc");
		storesParam.setTotalCounter(1l);
		
		assertEquals("abc", storesParam.getAddress());
		assertEquals("abc", storesParam.getCity());
		assertEquals("abc", storesParam.getCountry());
		assertEquals("123", storesParam.getMsisdn());
		assertEquals(1l, storesParam.getStoreId());
		assertEquals("abc", storesParam.getStoreName());
		assertEquals(1l, storesParam.getTotalCounter());
	}
	
	@Test
	void testToString() {
		storesParam.toString();
		assertNotNull(storesParam.toString());
	}

}
