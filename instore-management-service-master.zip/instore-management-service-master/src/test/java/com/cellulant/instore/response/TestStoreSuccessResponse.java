package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoreSuccessResponse {

	@InjectMocks
	StoreSuccessResponse storeSuccessResponse;
	
	@Test
	void testBean() {
		StoreSuccessResponse storeSuccessResponse = new StoreSuccessResponse();
		StoreSuccessResponse allArgsStoreSuccessResponse = new StoreSuccessResponse(false, 0, "abc", storeSuccessResponse);
		
		storeSuccessResponse.setMessage("abc");
		storeSuccessResponse.setStoreId(1l);
		storeSuccessResponse.setSuccess(false);
		storeSuccessResponse.setStatusCode(1);
		
		assertEquals("abc", storeSuccessResponse.getMessage());
		assertEquals(1l, storeSuccessResponse.getStoreId());
		assertEquals(false, storeSuccessResponse.getSuccess());
		assertEquals(1, storeSuccessResponse.getStatusCode());
	}
	
	@Test
	void testToString() {
		storeSuccessResponse.toString();
		assertNotNull(storeSuccessResponse.toString());
	}
}
