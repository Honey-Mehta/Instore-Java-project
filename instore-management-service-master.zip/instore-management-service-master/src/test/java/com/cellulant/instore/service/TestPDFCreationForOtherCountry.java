package com.cellulant.instore.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.response.QRCodeCounter;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

@ExtendWith(MockitoExtension.class)
 class TestPDFCreationForOtherCountry {
	
	@InjectMocks
	PDFCreationForOtherCountry country;
	
	@Mock
	ApplicationProperties applicationProperties;

	@Mock
	CounterRepository counterRepository;

	@Mock
	StoreRepository storeRepository;
	
	@Mock
	RestTemplate restTemplate;
	
	@Mock 
	PDFservice pdfservice;
	
	@Mock
	Gson gson;
	
	@Mock
	QRCodeService qrCodeService;
	
	QRCodeCounter counterInfo; 
	
	 @BeforeEach
	  void SetUp() {
		   counterInfo = new QRCodeCounter(1l, "1234", "8840642909", "counter-Name", "storename", 1l, "KEN");
	  }

	 private final String getServiceResult = "{\r\n"
	 		+ "\"success\": true,\r\n"
	 		+ "\"statusCode\": 200,\r\n"
	 		+ "\"message\": \"Success\",\r\n"
	 		+ "\"data\": {\r\n"
	 		+ "\"shortCode\": \"369\",\r\n"
	 		+ "\"currencyCode\": \"KSH\",\r\n"
	 		+ "\"counterCode\": \"3\",\r\n"
	 		+ "\"qrCode\": {\r\n"
	 		+ "\"url\": \"https://paybylink-instore.test.tingg.africa/KEN/3\",\r\n"
	 		+ "\"pdf\": \"https://instore.dev.tingg.africa/api/v1/instore-service/app/genrateQrCode/?counterCode=3\"\r\n"
	 		+ "},\r\n"
	 		+ "\"paymentMethods\": [\r\n"
	 		+ "{\r\n"
	 		+ "\"country\": \"ZMB\",\r\n"
	 		+ "\"client_name\": \"Airtel Zambia\",\r\n"
	 		+ "\"client_code\": \"AIRTELZM\",\r\n"
	 		+ "\"logo\": \"https://customers.dev.tingg.africa/api/v1/app/images/ddbfb8eb-9a33-4ffe-bc68-cd22f6353cc4\"\r\n"
	 		+ "},\r\n"
	 		+ "{\r\n"
	 		+ "\"country\": \"KEN\",\r\n"
	 		+ "\"client_name\": \"DTB\",\r\n"
	 		+ "\"client_code\": \"DTB\",\r\n"
	 		+ "\"logo\": \"https://customers.dev.tingg.africa/api/v1/app/images/4bfc543d-17c8-4793-982d-e40b0cad83a2\"\r\n"
	 		+ "},\r\n"
	 		+ "{\r\n"
	 		+ "\"country\": \"KEN\",\r\n"
	 		+ "\"client_name\": \"Safaricom Limited\",\r\n"
	 		+ "\"client_code\": \"SAFKE\",\r\n"
	 		+ "\"logo\": \"https://customers.dev.tingg.africa/api/v1/app/images/0953fe8f-21bc-4dde-9a93-56193c41dd3b\"\r\n"
	 		+ "},\r\n"
	 		+ "{\r\n"
	 		+ "\"country\": \"KEN\",\r\n"
	 		+ "\"client_name\": \"DTB_Test\",\r\n"
	 		+ "\"client_code\": \"DTB_Test\",\r\n"
	 		+ "\"logo\": \"https://customers.dev.tingg.africa/api/v1/app/images/7f9f6000-3eea-49a5-92d2-d37fd5fc8693\"\r\n"
	 		+ "}\r\n"
	 		+ "]\r\n"
	 		+ "}\r\n"
	 		+ "}";
	 
	 @Test
	  void testDownLoadPDF() {
		  String counterCode = "1234";
		  Stores stores = new Stores();
			 stores.setStoreId(1l);
			 stores.setActive(1);
			 stores.setStoreName("amazon");
		  Mockito.when(storeRepository.findStoreById(counterInfo.getStoreId())).thenReturn(stores);
		  Gson gson = new Gson();
		  String url = "https://run.mocky.io/v3/05a8b08e-5950-4fa2-9af5-7573912d2aba";
		  HttpHeaders headers = new HttpHeaders();
			 headers.set("X-Country-Code", counterInfo.getCountry());
			 HttpEntity<String> http = new HttpEntity<>(null, headers);
	    	when(this.applicationProperties.getUssdUrl()).thenReturn(url);
	      Mockito.when(restTemplate
				.exchange(applicationProperties.getUssdUrl()+counterCode ,HttpMethod.GET,http, String.class)).thenReturn(new ResponseEntity<String>(getServiceResult,HttpStatus.OK));;
		  assertThrows(NullPointerException.class,()-> country.downLoadPDF(counterCode, counterInfo));
	  }
}
