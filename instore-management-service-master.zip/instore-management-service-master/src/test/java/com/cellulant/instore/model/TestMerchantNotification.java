package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestMerchantNotification {
	
	@InjectMocks
	MerchantNotification merchantNotification;

	@Test
    void testBean() {
		
	    MerchantNotification merchantNotification = new MerchantNotification();
	    MerchantNotification allArgsStoresMerchantNotification = new MerchantNotification(1l, "1", 1l, 1l, 1l, "abc", 1l, 1l, 1d, 1, "abc", 1l);
	    merchantNotification.setMerchantNotificationId(1l);
	    merchantNotification.setBeepTransactionId("1");
	    merchantNotification.setCounterId(1l);
	    merchantNotification.setUserId(1l);
	    merchantNotification.setNotificationTypeId(1l);
	    merchantNotification.setReference("abc");
	    merchantNotification.setReversalId(1l);
	    merchantNotification.setClientId(1l);
	    merchantNotification.setAmount(1d);
	    merchantNotification.setBeepStatus(1);
	    merchantNotification.setNarration("abc");
	    merchantNotification.setCounterCode(1l);
		
	    
		assertEquals(1l, (long)merchantNotification.getMerchantNotificationId());
		assertEquals(1l, (long)merchantNotification.getNotificationTypeId());
		assertEquals(1l, (long)merchantNotification.getCounterId());
		assertEquals(1l, (long)merchantNotification.getUserId());
		assertEquals("1", merchantNotification.getBeepTransactionId());
		assertEquals("abc",merchantNotification.getReference());
		assertEquals(1l, (long)merchantNotification.getReversalId());
		assertEquals(1l, (long)merchantNotification.getClientId());
	//	assertEquals(1, (double)merchantNotification.getAmount());
		assertEquals(1, (int)merchantNotification.getBeepStatus());
		assertEquals("abc",merchantNotification.getNarration());
		assertEquals(1l, (long)merchantNotification.getCounterCode());
		
		
		merchantNotification.equals(allArgsStoresMerchantNotification);
		merchantNotification.hashCode();

	}
	
	@Test
	void onCreate() {
		merchantNotification.onCreate();
	}

	@Test
	void onUpdate() {
		merchantNotification.onUpdate();
	}

	@Test
	void testToString() {
	assertNotNull(merchantNotification.toString());	
	}

}
