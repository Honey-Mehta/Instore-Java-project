package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestActionable {

	@InjectMocks
	Actionable actionable;

	@Test
    void testBean() {
		
		Actionable actionable = new Actionable();
	
		
		
		actionable.setModifiedBy(1l);
		actionable.setCreatedBy(1l);
		
	
		

		assertEquals(1l,(long)actionable.getCreatedBy());
		assertEquals(1l,(long) actionable.getModifiedBy());
		
	
		actionable.hashCode();

	}
	
	@Test
	void onCreate() {
		actionable.onCreate();
	}

	@Test
	void onUpdate() {
		actionable.onUpdate();
	}

	@Test
	void testToString() {
		actionable.toString();
		assertNotNull(actionable.toString());
	}
}
