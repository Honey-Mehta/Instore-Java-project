package com.cellulant.instore.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.StoreDto;
import com.cellulant.instore.response.StoresParam;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.service.StoreService;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

import javassist.NotFoundException;

@ExtendWith(MockitoExtension.class)
 class TestStoreController {
	
	 @InjectMocks
	 private StoreController storeController;
	 
	 
	 @Mock
	 private UserRepository userRepository;
	 
	 @Mock
	 private StoreAssignmentRepository storeAssignmentRepository;
	 
	 @Mock
	 private StoreService storeService;
	 
	 @Mock
	 private StoreRepository storeRepository;
	 
	 @Mock
	 private ApplicationProperties applicationProperties;
	 
	 @Test
	 void testGetStores() {
		 int page=1;
		 int size=10;
		 Long casUserId = 1l;
		 Long userId = null;
		 List<StoresParam> storeList = new ArrayList<>();
		 String xCountryCode = "zmb";
		 StoresParam storesParam = new StoresParam();
		 storesParam.setStoreId(1l);
		 storesParam.setMsisdn("123456789");
		 storesParam.setTotalCounter(125l);
		 storeList.add(storesParam);
		 String searchStores= "";
		CASUser casUser = CASUser.builder().customerID(1l).build();
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, null);
		ResponseEntity<Object> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
	//	Mockito.when(userRepository.findCasUser(casUserId,applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(storeService.fetchStoresWithPagination(searchStores, page, size, casUser, xCountryCode, userId)).thenReturn(myResponse);
		 ResponseEntity<Object> reponse = storeController.getStores(searchStores,xCountryCode,page,userId, size, casUser);
		 assertNotNull(response);
	        
	 }
	 
	 
//	 @Test
//	 void testGetStoresAsStoreManager() {
//		 int page=1;
//		 int size=10;
//		 Integer casUserId = 1;
//		 Long userId = 2l;
//		 Long storeId = 1l;
//		 List<StoresParam> storeList = new ArrayList<>();
//		 String xCountryCode = "zmb";
//		 StoresParam storesParam = new StoresParam();
//		 storesParam.setStoreId(1l);
//		 storesParam.setMsisdn("123456789");
//		 storesParam.setTotalCounter(125l);
//		 storeList.add(storesParam);
//		 String searchStores= "";
//		 Pageable paging = PageRequest.of(page-1, size);
//		CASUser casUser = CASUser.builder().customerID(1l).build();
//		Page<StoresParam> response = new PageImpl(storeList);
//		Mockito.when(userRepository.findCasUser(casUserId)).thenReturn(userId);
//		 Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeId);
//		 Mockito.when(storeRepository.findStoresForStoresManager(paging,storeId)).thenReturn(response);
//		 ResponseEntity<Object> reponse = storeController.getStores(searchStores,xCountryCode,casUserId,page,size, casUser);
//		 assertNotNull(response);
//	        
//	 }
	 

	 
	 @Test
	 void testSaveStores() {
		 CASUser casUser= CASUser.builder().customerID(1l).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setCountryID("AFG");
		 storeDto.setActive(1);
		 Stores store = new Stores();
			store.setStoreName(storeDto.getStoreName());
			store.setActive(storeDto.getActive());
			SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, storeDto);
			ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
			Mockito.when(storeService.createStores(storeDto, casUser)).thenReturn((ResponseEntity<Object>) myResponse);
			ResponseEntity<Object> success = storeController.saveStore(storeDto, casUser);
			assertNotNull(success);
	 }
	 
	 @Test
	 void testUpdateStores() throws NotFoundException {
		 CASUser casUser= CASUser.builder().customerID(1l).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(1);
		 Stores store = new Stores();
			store.setStoreName(storeDto.getStoreName());
			store.setActive(storeDto.getActive());
			SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, storeDto);
			ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
			Mockito.when(storeService.updateStoresInfo(storeDto, casUser)).thenReturn((ResponseEntity<Object>) myResponse);
			ResponseEntity<Object> success = storeController.updateStore(storeDto, casUser);
			assertNotNull(success);
	 }
	 

	 
	 @Test
	 void testGetStoresById() throws NotFoundException {
		 CASUser casUser= CASUser.builder().customerID(1l).build();
		
		 Stores stores = new Stores();
		 stores.setStoreId(1l);
		 stores.setActive(1);
		 stores.setStoreName("amazon");
		 Long id =1l;
		 Mockito.when(storeRepository.findStoreById(id)).thenReturn(stores);
		 Mockito.when(storeService.findStoreDetail(id,casUser)).thenReturn(Mockito.any());
		 ResponseEntity<Object> response = storeController.getStoresById(id,casUser);
		 
		 assertNotNull(stores);
		 
	 }
	 
	 @Test
	 void testGetStoresIdNotFound() throws NotFoundExceptions {
		 Stores stores = null;
		
		 Long id =1l;
		 
		 assertThrows(NotFoundExceptions.class,
	                () ->storeController.getStoresById(id,null));
		 
	 }
	 

	 
	 @Test
	 void testDeleteStoreById() throws NotFoundException {
		 CASUser casUser = CASUser.builder().customerLevel(Code.ADMIN).customerID(1l).build();
		 Long storeId=1l;
		 Stores store = new Stores();
		 store.setStoreId(1l);
		 store.setStoreName("abc");
			Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		
		 assertThrows(PermissionException.class,
	                () ->storeController.deleteStoreById(storeId,casUser));

	 }
	 
	 @Test
	 void testDeleteStoreByIdUserNotAdminNotCustomer() {
		 CASUser casUser = CASUser.builder().customerLevel(Code.RESELLER).customerID(1l).build();
		 Long storeId=1l;
		 Stores store = new Stores();
		 store.setStoreId(1l);
		 store.setStoreName("abc");
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		assertThrows(PermissionException.class,
                () ->storeController.deleteStoreById(storeId,casUser));
		
	 }
	 
	 @Test
	 void testDeleteStoreIdForMerchant() {
		 CASUser casUser = CASUser.builder().customerLevel(Code.CUSTOMER).customerID(1l).build();
		 Long storeId=1l;
		 Stores store = new Stores();
		 store.setStoreId(1l);
		 store.setStoreName("abc");
		 Long userIdForCashier=null;
		 Long userIdForStoreManager = null;
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeId, casUser.getCustomerID())).thenReturn(store);
		 Mockito.when(storeService.deleteStoreById(storeId)).thenReturn(3);
		 ResponseEntity<Object> response = storeController.deleteStoreById(storeId,casUser);
		 assertNotNull(response);
		 SuccessResponse successResponse = (SuccessResponse) response.getBody();
		 assertEquals(AppConstants.SUCCESS_STATUS,
				  successResponse.getStatusCode());
	 }
	 
	 @Test
	 void testDeleteStoreIdForMerchantDeletingOtherStores() {
		 CASUser casUser = CASUser.builder().customerLevel(Code.CUSTOMER).customerID(1l).build();
		 Long storeId=1l;
		 Stores store = new Stores();
		 store.setStoreId(1l);
		 store.setStoreName("abc");
		 Long userIdForCashier=null;
		 Long userIdForStoreManager = null;
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeId, casUser.getCustomerID())).thenReturn(null);
		
		assertThrows(PermissionException.class,
                () ->storeController.deleteStoreById(storeId,casUser));
	 }
	 
	 @Test
	 void testDeleteStoreIdForStoreManager() {
		 CASUser casUser = CASUser.builder().customerLevel(Code.CUSTOMER).customerID(1l).build();
		 Long storeId=1l;
		 Stores store = new Stores();
		 store.setStoreId(1l);
		 store.setStoreName("abc");
		 Long userIdForCashier=null;
		 Long userIdForStoreManager = 1l;
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		
		
		 assertThrows(PermissionException.class,
	                () ->storeController.deleteStoreById(storeId,casUser));
	 }
	 
	 @Test
	 void testDeleteStoreIdForCashier() {
		 CASUser casUser = CASUser.builder().customerLevel(Code.CUSTOMER).customerID(1l).build();
		 Long storeId=1l;
		 Stores store = new Stores();
		 store.setStoreId(1l);
		 store.setStoreName("abc");
		 Long userIdForCashier=1l;
		 Long userIdForStoreManager = null;
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class,
                () ->storeController.deleteStoreById(storeId,casUser));
	 }
	 
	 @Test
	 void testDeleteStoreByIdThrowInternalServerError() {
		 Long storeId=1l;
		 Stores store = null;
		
			Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
		
			assertThrows(NotFoundExceptions.class,
	                () ->storeController.deleteStoreById(storeId,null));
		 
	 }
	 
	 @Test
	 void testDeleteStoreByIdNotFound() {
		 Long storeId=1l;
		 Stores stores = null;
			Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(stores);
			assertThrows(NotFoundExceptions.class,
	                () ->storeController.deleteStoreById(storeId,null));
		 
	 }
	 
	 @Test
	 void fetchStoresWithOutPagination() {
		 CASUser casUser = CASUser.builder().customerID(1l).build();
		 String xCountryCode = "ZMB";
		 List<Stores> storesList =  new ArrayList<>(); 
		 Stores stores  =  new Stores(1l, 1l, "Stores", "waka", "waka", null, "AFG", "1234", 1,null);
		 storesList.add(stores);
		 SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, storesList);
			ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		
		 Mockito.when(storeService.fetchStores(casUser,xCountryCode)).thenReturn((ResponseEntity<Object>) myResponse);
		 ResponseEntity<Object> SuccessResponse = storeController.getStoresWithoutPagination(xCountryCode,casUser);
		assertNotNull(myResponse);
	 }
	 
	 @Test
	 void testGetStoresCounters() {
		 CASUser casUser = CASUser.builder().customerID(1l).build();
		 String role ="1mnf";
		 SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, null);
		 ResponseEntity<Object> entityObject = new ResponseEntity<Object>(response,HttpStatus.OK);
		 Mockito.when(storeService.fetchStoresAndCounter(casUser, role)).thenReturn(entityObject);
		 ResponseEntity<Object> result = storeController.getStoresCounters(role, casUser);
		 assertNotNull(result);
		 
	 }
	 

}
