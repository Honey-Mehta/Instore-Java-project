package com.cellulant.instore.dto;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestSystemconfigurationRequest {
	
	@InjectMocks
	private SystemConfigurationRequest systemConfigurationRequest;
	
	@Test
	void testBean() {
		SystemConfigurationRequest systemConfigurationRequest = new SystemConfigurationRequest();
		SystemConfigurationRequest allArgsSystemConfigurationRequest = new SystemConfigurationRequest(1l, 1l, "abc", "abc");
		systemConfigurationRequest.setClientId(1l);
		systemConfigurationRequest.setSystemConfigurationId(1l);
		systemConfigurationRequest.setConfigKey("abc");
		systemConfigurationRequest.setConfigValue("abc");
		
		assertEquals(1l, systemConfigurationRequest.getClientId());
		assertEquals(1l, systemConfigurationRequest.getSystemConfigurationId());
		assertEquals("abc", systemConfigurationRequest.getConfigKey());
		assertEquals("abc", systemConfigurationRequest.getConfigValue());
	}
	
	@Test
	void testToString() {
		assertNotNull(systemConfigurationRequest.toString());
	}

}
