package com.cellulant.instore.request;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoreDto {

	@InjectMocks
	private StoreDto storeDto;
	
	@Test
	void testBean() {
		
		StoreDto storeDto = new StoreDto();
		StoreDto allArgsStoreDto = new StoreDto(1l, "abc", "abc", "abc", "abc", "abc", 1, "abc");
		storeDto.builder().active(1).build();
		
		storeDto.setStoreId(1l);
		
		storeDto.setCity("abc");
		storeDto.setCountryID("abc");
		storeDto.setAddress("abc");
		storeDto.setDescription("abc");
		storeDto.setStoreName("abc");
		storeDto.setActive(1);
		storeDto.setStoreCode("abc");
		
		assertEquals(1l, storeDto.getStoreId());
		
		assertEquals("abc", storeDto.getCity());
		assertEquals("abc", storeDto.getCountryID());
		assertEquals("abc", storeDto.getAddress());
		assertEquals("abc", storeDto.getDescription());
		assertEquals("abc", storeDto.getStoreName());
		assertEquals("abc", storeDto.getStoreCode());
		assertEquals(1, storeDto.getActive());
	}
	
	@Test
	void testToString() {
		
		assertNotNull(storeDto.toString());
	}
}
