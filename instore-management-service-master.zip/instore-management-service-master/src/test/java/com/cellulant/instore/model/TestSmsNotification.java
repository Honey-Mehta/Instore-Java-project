package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestSmsNotification {

	@InjectMocks
	SmsNotification smsNotification;

	@Test
    void testBean() {
		
		SmsNotification smsNotification = new SmsNotification();

		SmsNotification allArgsSmsNotification = new SmsNotification(1l, 1l, "abc", "abc", "abc", 1, 1, "abc", "abc", "abc", 1);
		
		smsNotification.setSmsNotificationId(1l);
		smsNotification.setMerchantNotificationId(1l);
		smsNotification.setMsisdn("abc");
		smsNotification.setSourceAddress("abc");
		smsNotification.setMessage("abc");
		smsNotification.setNumberOfsends(1);
		smsNotification.setStatus(1);
		smsNotification.setStatusHistory("abc");
		smsNotification.setRequestPayload("abc");
		smsNotification.setResponsePayload("abc");
		smsNotification.setActive(1);
	
		assertEquals(1l, (long)smsNotification.getSmsNotificationId());
		assertEquals(1l, (long)smsNotification.getMerchantNotificationId());
		assertEquals("abc",smsNotification.getMsisdn());
		assertEquals("abc",smsNotification.getSourceAddress());
		assertEquals("abc",smsNotification.getMessage());
		assertEquals(1, (int)smsNotification.getNumberOfsends());
		assertEquals(1, (int)smsNotification.getStatus());
		assertEquals("abc",smsNotification.getStatusHistory());
		assertEquals("abc",smsNotification.getRequestPayload());
		assertEquals("abc",smsNotification.getResponsePayload());
		assertEquals(1, (int)smsNotification.getActive());
		
		smsNotification.equals(allArgsSmsNotification);
		smsNotification.hashCode();

	}
	
	@Test
	void onCreate() {
		smsNotification.onCreate();
	}

	@Test
	void onUpdate() {
		smsNotification.onUpdate();
		
	}

	@Test
	void testToString() {
		smsNotification.toString();
		assertNotNull(smsNotification.toString());
	}
}
