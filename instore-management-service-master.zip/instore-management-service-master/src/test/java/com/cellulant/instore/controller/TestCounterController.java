package com.cellulant.instore.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.dto.DeviceIdDto;
import com.cellulant.instore.dto.UpdateCounterDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CountersDto;
import com.cellulant.instore.response.StoreCountersDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.service.CounterService;
import com.cellulant.instore.utils.AppConstants;
import com.itextpdf.text.DocumentException;

@ExtendWith(MockitoExtension.class)
 class TestCounterController {
	
	@InjectMocks
	private CounterController  counterController;
	
	@Mock
	private CounterService  counterService;
	
	@Mock
	private StoreRepository storeRepository;
	
	@Mock
	private CounterRepository counterRepository;
	
	@Mock
	private UserRepository userRepository;
	
	
	@Test
	void testGetCounters() {
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto counter =  new CountersDto();
		counter.setCounterName("payment");
		counter.setActive(1);
		counterList.add(counter);
		CASUser casUser= CASUser.builder().customerID(1l).build();
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.SUCCESS_MESSAGE, null);
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(counterService.getCounters(casUser)).thenReturn(responseEntity);
		ResponseEntity<Object> response2 = counterController.getCounters(casUser);
		assertNotNull(response2);
		
	}
	

	


	@Test
	void getStoreCounter() throws PermissionException, IOException, DocumentException {
		CASUser casUser = CASUser.builder().userID(1l).customerID(1l).build();
		Long storeId=1l;
		int page=1;
		String searchCounters="abc";
		int size=10;
		 Stores stores = new Stores();
		 stores.setActive(1);
		 stores.setStoreId(1l);
		 stores.setStoreCode("123");
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(stores);
		List<StoreCountersDto> storeCounters = new ArrayList<>();
		StoreCountersDto storeCountersDto = new StoreCountersDto();

		storeCountersDto.setCounterName("java");
		storeCounters.add(storeCountersDto);
		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, null);
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(response,HttpStatus.OK);

	 Mockito.when(counterService.findCountersByStoreId(storeId,searchCounters,page,size,casUser)).thenReturn(responseEntity);

			ResponseEntity<Object> reponse = counterController.getStoreCounter(storeId,searchCounters,page,size,casUser);
				 assertNotNull(reponse);
	}

	

	
	@Test
	void getStoreCounterthrowStorIdNotFound() throws NotFoundExceptions {
		CASUser casUser = CASUser.builder().userID(1l).customerID(1l).build();
		Long storeId=-25l;
		int page=1;
		String searchCounters="abc";
		int size=10;
		
		
		List<StoreCountersDto> storeCounters = new ArrayList<>();
		StoreCountersDto storeCountersDto = null;
		storeCounters.add(storeCountersDto);

		 
		 assertThrows(NotFoundExceptions.class,
	                () -> counterController.getStoreCounter(storeId,searchCounters,page,size,casUser));
	}
	
	
//	@Test
//	void testCreateCounter() throws Exception {
//		CASUser casUser = CASUser.builder().customerID(1l).build();
//		List<CounterDto> counterDtoList = new ArrayList<>();
//		String xCountryCode= "AFG";
//		CounterDto counterDto =  new CounterDto();
//		counterDto.setStoreId(1l);
//		counterDto.setCounterName("amazon");
//		counterDtoList.add(counterDto);
//		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, counterDto);
//		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
//		Mockito.when(counterService.createCounters(counterDtoList,casUser,xCountryCode)).thenReturn((ResponseEntity<Object>) myResponse);
//		ResponseEntity<Object> success = counterController.saveCounter(counterDtoList, xCountryCode,casUser);
//		assertNotNull(success);
//	
//	}
	


	@Test
	void TestupdateDeviceIdOnCounters() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
     	CASUser casUser = CASUser.builder().customerID(1l).build();
     	SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, deviceIdDto);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
     	Mockito.when(counterService.updateDeviceId(deviceIdDto,casUser)).thenReturn((ResponseEntity<Object>) myResponse);
     	ResponseEntity<Object> reponse = counterController.updateDeviceIdOnCounters(deviceIdDto, casUser);
		assertNotNull(response);

	}
	
	@Test
	void testUpdateCounter() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long clientId=12l;
		String country = "KEN";
		String counterCode = "12l";
		Counters counter = new Counters(1l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		UpdateCounterDto counterDto = new UpdateCounterDto();
		counterDto.setCounterId("12l");
		counterDto.setCounterName("java");
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, clientId);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,country)).thenReturn(counter);
		Mockito.when(counterService.updateCounter(counterDto,casUser,counter)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = counterController.updateCounterInfo(counterDto,country, casUser);
		assertNotNull(success);
	}
	
	
	@Test
	void testDeleteCounter() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String counterCode = "12l";
		String country = "KEN";
	
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
		ResponseEntity<Object> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,country)).thenReturn(counter);
		Mockito.when(counterService.deleteCounter(counterCode,casUser,counter)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = counterController.deleteCounterByCounterCode(counterCode,country, casUser);
		assertNotNull(success);
		
	}
	
	@Test
	void testDeleteCounterWhenCounterNotFound() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String counterCode = "12l";
		String country = "KEN";
		Counters counter = null;
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
		ResponseEntity<Object> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,country)).thenReturn(counter);
		assertThrows(NotFoundExceptions.class,
	             () -> counterController.deleteCounterByCounterCode(counterCode,country, casUser));
		
		
	}
	
	@Test
	void testCashierDetail() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long counterCode=12l;
		String role = "cashier";
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
		ResponseEntity<Object> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(counterService.fetchCashierDetail(role,casUser)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = counterController.getCashierDetail(role, casUser);
		assertNotNull(success);
	}
	
	
	@Test
	void testFetchCounterById() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String counterId="12l";
	String country ="KEN";

		Counters counter = new Counters(1l, 1l, "78484747", "sbh", 1, "des", null, 123l, null,null);

		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterId,country)).thenReturn(counter);
	    ResponseEntity<Object> reponse= counterController.getCounterById(counterId,country, casUser);
		assertNotNull(counterId);
		
	}
	
	@Test
	void testFetchCounterByIdThrowCounterNotFound()  {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String counterId="12l";
		String country ="KEN";

	
	 assertThrows(NotFoundExceptions.class,
             () -> counterController.getCounterById(counterId,country, casUser));

	}


}
