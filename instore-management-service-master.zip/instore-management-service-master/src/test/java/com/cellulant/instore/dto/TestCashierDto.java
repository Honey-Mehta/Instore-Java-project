package com.cellulant.instore.dto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cellulant.instore.dto.CashierDto;

@ExtendWith(MockitoExtension.class)
 class TestCashierDto {
	
	@InjectMocks
	private CashierDto cashierDto;
	
	
	@Test
	void testBean() {
		CashierDto cashierDto = new CashierDto();
		CashierDto allArgscashierDto = new CashierDto("abc", "abc", "1", "abc", "abc", "123456",1,1l);
		
		cashierDto.setCounterCode("1");
		cashierDto.setEmailAddress("abc");
		cashierDto.setFullName("abc");
		cashierDto.setIdNumber("123456");
		cashierDto.setMsisdn("123456");
		cashierDto.setUsername("abc");
		
		assertEquals("abc", cashierDto.getEmailAddress());
		assertEquals("abc", cashierDto.getFullName());
		assertEquals("123456", cashierDto.getIdNumber());
		assertEquals("1", cashierDto.getCounterCode());
		assertEquals("abc", cashierDto.getUsername());
		assertEquals("123456", cashierDto.getMsisdn());
		
	}
	
	@Test
	void testToString() {
		cashierDto.toString();
		assertNotNull(cashierDto.toString());
	}
	

}
