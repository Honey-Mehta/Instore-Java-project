package com.cellulant.instore.request;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestSystemConfigurationDto {

	@InjectMocks
	private SystemConfigurationDto  systemConfigurationDto;
	
	@Test
	void testBean() {
		SystemConfigurationDto  systemConfigurationDto = new SystemConfigurationDto();
		SystemConfigurationDto  allArgsSystemConfigurationDto = new SystemConfigurationDto(1l, 1, "abc", "abc", 1, "abc", "abc");
		
		systemConfigurationDto.setSystemConfigurationId(1l);
		systemConfigurationDto.setClientId(1);
		systemConfigurationDto.setConfigKey("abc");
		systemConfigurationDto.setConfigValue("abc");
		systemConfigurationDto.setActive(1);
		systemConfigurationDto.setCreatedBy("abc");
		systemConfigurationDto.setModifiedBy("abc");
		
		assertEquals(1l, systemConfigurationDto.getSystemConfigurationId());
		assertEquals(1, systemConfigurationDto.getClientId());
		assertEquals(1, systemConfigurationDto.getActive());
		assertEquals("abc", systemConfigurationDto.getConfigKey());
		assertEquals("abc", systemConfigurationDto.getConfigValue());
		assertEquals("abc", systemConfigurationDto.getCreatedBy());
		assertEquals("abc", systemConfigurationDto.getModifiedBy());

	}
	
	
	@Test
	void testToString() {
		systemConfigurationDto.toString();
		assertNotNull(systemConfigurationDto.toString());
	}
}
