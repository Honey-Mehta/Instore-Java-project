package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestCountersDto {

	@InjectMocks
	private CountersDto countersDto;
	
	@Test
	void testBean() {
		
		CountersDto countersDto =  new CountersDto();
		CountersDto allArgsCountersDto =  new CountersDto(1l,"1", "abc", "abc", 1, "abc", 1l, null);
		
		
		countersDto.setStoreId(1l);
		countersDto.setCounterCode("123");
		countersDto.setCounterName("abc");
		countersDto.setDescription("abc");
		countersDto.setMsisdn("abc");
		countersDto.setActive(1);
        
       
        assertEquals("abc", countersDto.getDescription());
        assertEquals("abc", countersDto.getCounterName());
        assertEquals("abc", countersDto.getMsisdn());
        assertEquals(1l,countersDto.getStoreId());
        assertEquals("123", countersDto.getCounterCode());
        assertEquals(1,(int) countersDto.getActive());
	}
	
	@Test
	void testToString() {
		countersDto.toString();
		assertNotNull(countersDto.toString());
	}
	
}
