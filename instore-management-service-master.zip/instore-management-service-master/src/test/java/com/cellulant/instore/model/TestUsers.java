package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestUsers {
	@InjectMocks
	Users users;

	@Test
    void testBean() {
		
		Users users = new Users();
	//	Users allArgsUsers = new Users(1l, 1l, 1, "abc", "abc","abc", "123");
		
		users.setUserId(1l);
		users.setClientId(1l);
		users.setRoleId(1);
		users.setEmailAddress("abc");
		users.setUsername("abc");
		users.setMsisdn("123");
	
		assertEquals(1l, (long)users.getUserId());
		assertEquals(1l, (long)users.getClientId());
		assertEquals("abc",users.getEmailAddress());
		assertEquals("abc",users.getUsername());
		assertEquals("123",users.getMsisdn());
		assertEquals(1, (int)users.getRoleId());
		
		
		users.hashCode();

	}
	
	@Test
	void onCreate() {
		users.onCreate();
	}

	@Test
	void onUpdate() {
		users.onUpdate();
	}

	@Test
	void testToString() {
		users.toString();
		assertNotNull(users.toString());
	}

}
