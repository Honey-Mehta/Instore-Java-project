package com.cellulant.instore.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestApplicationProperties {
	
	@InjectMocks
	ApplicationProperties applicationProperties;
	
	@Test
	void testBeans() {
		ApplicationProperties applicationProperties =  new ApplicationProperties();
		
		applicationProperties.setCashierUrl("abc");
		
		assertEquals("abc", applicationProperties.getCashierUrl());
		
		
		
	}

}
