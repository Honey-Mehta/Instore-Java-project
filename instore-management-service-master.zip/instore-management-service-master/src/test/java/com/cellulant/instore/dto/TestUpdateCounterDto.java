package com.cellulant.instore.dto;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestUpdateCounterDto {
	
	@InjectMocks
	private UpdateCounterDto updateCounterDto;
	
	@Test
	void testBeans() {
		UpdateCounterDto updateCounterDto =  new UpdateCounterDto();
		UpdateCounterDto allArgsUpdateCounterDto =  new UpdateCounterDto("1l", "abc", "abc", null);
		
		updateCounterDto.setCounterId("1l");
		updateCounterDto.setCounterName("abc");
		updateCounterDto.setMsisdn("abc");
		
		assertEquals("1l", updateCounterDto.getCounterId());
		assertEquals("abc", updateCounterDto.getCounterName());
		assertEquals("abc" ,updateCounterDto.getMsisdn());
	}

	@Test
	void testToString() {
		assertNotNull(updateCounterDto.toString());
	}
}
