package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoreCountersDto {

	
	@InjectMocks
	StoreCountersDto storeCountersDto;
	
	@Test
	void testBeans() {
		StoreCountersDto storeCountersDto =  new StoreCountersDto();
		StoreCountersDto allArgsStoreCountersDto = new StoreCountersDto(1l, "abc", "123", "abc", "abc", "1", null);
		StoreCountersDto storeCounter = storeCountersDto.builder().counterCode("1").counterName("abc").build();
		
		storeCountersDto.setCounterCode("1");
		
		storeCountersDto.setCounterName("abc");
		storeCountersDto.setMsisdn("123");
		storeCountersDto.setStoreName("abc");
		storeCountersDto.setUsername("abc");
		
		assertEquals("1", storeCountersDto.getCounterCode());
		
		assertEquals("abc", storeCountersDto.getCounterName());
		assertEquals("123", storeCountersDto.getMsisdn());
		assertEquals("abc", storeCountersDto.getStoreName());
		assertEquals("abc", storeCountersDto.getUsername());
	}
	
	@Test
	void testToString() {
	   storeCountersDto.toString();
	   assertNotNull(storeCountersDto.toString());
	}
	
}
