package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestErrorResponse {

	@InjectMocks
	ErrorResponse errorResponse;
	
	@Test
	void testBeans() {
		ErrorResponse errorResponse =  new ErrorResponse();
		ErrorResponse allArgsErrorResponse = new ErrorResponse(true, 500, "Failed", null, errorResponse);
		
	    ErrorResponse response= errorResponse.builder().message("failed").statusCode(123).build();
		
		errorResponse.setSuccess(false);
		errorResponse.setStatusCode(500);
		errorResponse.setData(errorResponse);
		errorResponse.setMessage("Failed");
		
		assertEquals(false, errorResponse.getSuccess());
		assertEquals("Failed", errorResponse.getMessage());
		assertEquals(500, errorResponse.getStatusCode());
		assertEquals(errorResponse, errorResponse.getData());
		
	}
	
	@Test
	void testToString() {
		assertNotNull(errorResponse.toString());
	}
}
