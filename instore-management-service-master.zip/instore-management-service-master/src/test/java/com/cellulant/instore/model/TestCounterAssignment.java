package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TestCounterAssignment {

	@InjectMocks
	CounterAssignment counterAssignment;

	
	
	
	@Test
    void testBean() {
		
		CounterAssignment counterAssignment = new  CounterAssignment();
		CounterAssignment allArgsCounterAssignment = new CounterAssignment(1l, 1, 1l, 1l);
		
	    counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setActive(1);
		counterAssignment.setCounterId(1l);
		counterAssignment.setUserId(1l);
		
		
		assertEquals(1l, (long)counterAssignment.getCounterAssignmentId());
		assertEquals(1l, (long)counterAssignment.getCounterId());
		assertEquals(1l, (long)counterAssignment.getUserId());
		assertEquals(1, (int)counterAssignment.getActive());
		counterAssignment.equals(allArgsCounterAssignment);
		counterAssignment.hashCode();

	}
	
	@Test
	void onCreate() {
		counterAssignment.onCreate();
	}

	@Test
	void onUpdate() {
		counterAssignment.onUpdate();
	}

	@Test
	void testToString() {
		counterAssignment.toString();
		assertNotNull(counterAssignment.toString());
	}

	
}
