package com.cellulant.instore.dto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestDeviceIdDto {

	@InjectMocks
	private DeviceIdDto deviceIdDto;
	
	@Test
	void testBean() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		DeviceIdDto allArgsdeviceIdDto = new DeviceIdDto("abc", 1l);
		
		deviceIdDto.setDeviceID("abc");
		deviceIdDto.setUserId(1l);
		
		assertEquals(1l, (long) deviceIdDto.getUserId());
		assertEquals("abc", deviceIdDto.getDeviceID());
		
		
	}
	
	@Test
	void testToString() {
		deviceIdDto.toString();
		assertNotNull(deviceIdDto.toString());
	}
	
}
