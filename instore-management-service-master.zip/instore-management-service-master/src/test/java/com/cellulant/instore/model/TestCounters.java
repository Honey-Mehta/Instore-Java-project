package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestCounters {
	
	@InjectMocks
	Counters counters;

	
	
	
	@Test
    void testBean() {
		
		Counters counters = new Counters();
		Counters allArgsStores = new Counters(1l, 1l,"123456", "aaabbc", 1, "aaabbc", IsReference.YES,1l,"abc",null);
		
		counters.setCounterId(1l);
		counters.setCounterCode(1l);
		counters.setMsisdn("123456");
		counters.setCounterName("aaabbc");
		counters.setActive(1);
		counters.setDescription("aaabbc");
		counters.setIsReference(IsReference.YES);
		counters.setStoreId(1l);
		
		
		assertEquals(1l, (long)counters.getCounterId());
		assertEquals(1l, (long)counters.getCounterCode());
		assertEquals("123456",counters.getMsisdn());
		assertEquals("aaabbc", counters.getCounterName());
		assertEquals(IsReference.YES, counters.getIsReference());
		assertEquals(1l, (long)counters.getStoreId());
		assertEquals("aaabbc", counters.getDescription());
		assertEquals(1, (int)counters.getActive());
		counters.equals(allArgsStores);
		counters.hashCode();

	}
	
	@Test
	void onCreate() {
		counters.onCreate();
	}

	@Test
	void onUpdate() {
		counters.onUpdate();
	}

	@Test
	void testToString() {
		counters.toString();
		assertNotNull(counters.toString());
	}


}
