package com.cellulant.instore.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.instore.dto.DeviceIDRequest;
import com.cellulant.instore.dto.SystemConfigurationDto;
import com.cellulant.instore.dto.SystemConfigurationRequest;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.service.SystemConfigurationService;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;

import javassist.NotFoundException;

@ExtendWith(MockitoExtension.class)
 class TestSystemConfigurationController {

	@InjectMocks
	private SystemConfigurationController systemConfigurationController;
	
	@Mock
	private SystemConfigurationService systemConfigurationService;
	
	@Mock
	private SystemConfigurationRepository repository;
	
	@Mock
	private ApplicationProperties applicationProperties;
	
	@Mock
	private UserRepository userRepository;
	
	@Mock
	Utility utility;
	
	
	@Test
	void testAddSystemConfiguration() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.SYSTEM_CONFIGURATION_ADDED_SUCCESSFULLY, null);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(systemConfigurationService.saveSystemConfiguration(systemConfigurationRequest, casUser)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success =systemConfigurationController.addSystemConfiguration(systemConfigurationRequest, casUser);
		assertNotNull(success);
	}
	

	
	@Test
	void testDeleteSystemConfiguration() throws NotFoundExceptions, NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long systemConfigurationId = 1l;
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.SYSTEM_CONFIGURATION_ADDED_SUCCESSFULLY, null);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(systemConfigurationService.removeSystemConfigurationById(systemConfigurationId, casUser)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success =systemConfigurationController.deleteSystemConfiguration(systemConfigurationId, casUser);
		assertNotNull(success);
	}
	
	@Test
	void testFetchSystemConfigurationForAdmin() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		List<SystemConfiguration> systemConfigurationList  = new ArrayList<>();
		SystemConfiguration systemConfiguration =  new SystemConfiguration();
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("isCallBack");
		systemConfiguration.setConfigValue("true");
		systemConfigurationList.add(systemConfiguration);
		
		Mockito.when(repository.getMerchanthasConfigValueOrNot(merchantId)).thenReturn(systemConfigurationList);
		Page<SystemConfiguration> pagingData = new PageImpl(systemConfigurationList);
		Mockito.when(systemConfigurationService.getSystemConfiguration(casUser, page, size, merchantId)).thenReturn(pagingData);
		ResponseEntity<Object> success =systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser);
		assertNotNull(success);
	}
	
	@Test
	void testFetchSystemConfigurationForMerchant() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		List<SystemConfiguration> systemConfigurationList  = new ArrayList<>();
		SystemConfiguration systemConfiguration =  new SystemConfiguration();
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("isCallBack");
		systemConfiguration.setConfigValue("true");
		systemConfigurationList.add(systemConfiguration);
		Long userIdForCashier = null;
		Long userIdForStoreManager =null ;
		Mockito.when(repository.getMerchanthasConfigValueOrNot(merchantId)).thenReturn(systemConfigurationList);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		Page<SystemConfiguration> pagingData = new PageImpl(systemConfigurationList);
		Mockito.when(systemConfigurationService.getSystemConfiguration(casUser, page, size, merchantId)).thenReturn(pagingData);
		ResponseEntity<Object> success =systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser);
		assertNotNull(success);
	}
	
	@Test
	void testFetchSystemConfigurationForStoreManager() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		List<SystemConfiguration> systemConfigurationList  = new ArrayList<>();
		SystemConfiguration systemConfiguration =  new SystemConfiguration();
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("isCallBack");
		systemConfiguration.setConfigValue("true");
		systemConfigurationList.add(systemConfiguration);
		Long userIdForCashier = null;
		Long userIdForStoreManager =1l ;
		Mockito.when(repository.getMerchanthasConfigValueOrNot(merchantId)).thenReturn(systemConfigurationList);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
	
		assertThrows(PermissionException.class,
                () ->systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser));
		
	}
	
	@Test
	void testFetchSystemConfigurationForCashier() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		List<SystemConfiguration> systemConfigurationList  = new ArrayList<>();
		SystemConfiguration systemConfiguration =  new SystemConfiguration();
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("isCallBack");
		systemConfiguration.setConfigValue("true");
		systemConfigurationList.add(systemConfiguration);
		Long userIdForCashier = 1l;
		Long userIdForStoreManager =null;
		Mockito.when(repository.getMerchanthasConfigValueOrNot(merchantId)).thenReturn(systemConfigurationList);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class,
                () -> systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser));
	}
	
	@Test
	void testFetchSystemConfigurationForMerchantAccessAnothermerchantDetail() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		int page = 1;
		int size = 1;
		Long merchantId = 5l;
		List<SystemConfiguration> systemConfigurationList  = new ArrayList<>();
		SystemConfiguration systemConfiguration =  new SystemConfiguration();
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("isCallBack");
		systemConfiguration.setConfigValue("true");
		systemConfigurationList.add(systemConfiguration);
		Long userIdForCashier = null;
		Long userIdForStoreManager =null ;
		Mockito.when(repository.getMerchanthasConfigValueOrNot(merchantId)).thenReturn(systemConfigurationList);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		Page<SystemConfiguration> pagingData = new PageImpl(systemConfigurationList);
		assertThrows(PermissionException.class,
                () -> systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser));
	}
	
	@Test
	void testFetchSystemConfigurationExceptions() throws NotFoundExceptions {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		List<SystemConfiguration> systemConfigurationList  =null;
		Mockito.when(repository.getMerchanthasConfigValueOrNot(merchantId)).thenReturn(systemConfigurationList);
		assertThrows(NotFoundException.class,
                () -> systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser));
	}
	
	@Test
	void testFetchSystemConfigurationNotFoundExceptions() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		assertThrows(NullPointerException.class,
                () -> systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser));	}
	

	@Test
	void testFetchSystemConfigurationUserNotAdminNotCustomer() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		int page = 1;
		int size = 1;
		Long merchantId = 1l;
		assertThrows(PermissionException.class,
                () -> systemConfigurationController.fetchSystemConfiguration(page, merchantId, size, casUser));
	}
	
	
	@Test
	void testAddDeviceId() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		DeviceIDRequest request = new DeviceIDRequest();
		request.setDeviceID("Hahahaha");
		request.setRole("merchant-admin");

		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, null);
		ResponseEntity<Object> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(systemConfigurationService.saveDeviceId(request, casUser)).thenReturn(myResponse);
		assertDoesNotThrow(()-> systemConfigurationController.addDeviceId(request, casUser));
	}
	
}
