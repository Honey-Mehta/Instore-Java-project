package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoreCounterDetail {

	@InjectMocks
	StoreCounterDetail storeCounterDetail;
	
	@Test
	void testBeans() {
		StoreCounterDetail storeCounterDetail =  new StoreCounterDetail();
		StoreCounterDetail allArgsStoreCounterDetail =  new StoreCounterDetail(1l, "abc", "abc", null);
		StoreCounterDetail storeCounter =  storeCounterDetail.builder().mobile("123").storeName("amazon").build();
		
		storeCounterDetail.setMobile("123");
		storeCounterDetail.setStoreName("abc");
		storeCounterDetail.setStoreId(1l);
		
		assertEquals("123", storeCounterDetail.getMobile());
		assertEquals("abc", storeCounterDetail.getStoreName());
		assertEquals(1l, storeCounterDetail.getStoreId());
	}
	
	@Test
	void testToString() {
		storeCounterDetail.toString();
		assertNotNull(storeCounterDetail.toString());
	}
}
