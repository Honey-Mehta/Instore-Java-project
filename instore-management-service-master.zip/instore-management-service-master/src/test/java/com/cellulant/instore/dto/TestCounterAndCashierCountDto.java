package com.cellulant.instore.dto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestCounterAndCashierCountDto {

	
	@InjectMocks
	private CounterAndCashierCountDto counterAndCashierCountDto;
	
	@Test
	void testBean() {
		CounterAndCashierCountDto counterAndCashierCountDto = new CounterAndCashierCountDto();
		CounterAndCashierCountDto allArgscounterAndCashierCountDto = new CounterAndCashierCountDto(1l, 1l);
		
		counterAndCashierCountDto.setCashierCount(1l);
		counterAndCashierCountDto.setCounterCount(1l);
		assertEquals(1l, (long)counterAndCashierCountDto.getCashierCount());
		
		assertEquals(1l,(long) counterAndCashierCountDto.getCounterCount());
		
		
	}
	
	@Test
	void testToString() {
		counterAndCashierCountDto.toString();
		assertNotNull(counterAndCashierCountDto.toString());
	}
	
	
}
