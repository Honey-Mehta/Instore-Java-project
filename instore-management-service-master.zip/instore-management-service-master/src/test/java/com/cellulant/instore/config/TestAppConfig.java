package com.cellulant.instore.config;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestAppConfig {

	@InjectMocks
	AppConfig appConfig;
	
	
	
	@Test
	void testObjectMapper() {
	assertNotNull(appConfig.objectMapper());	
	}
}
