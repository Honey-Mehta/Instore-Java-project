package com.cellulant.instore.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.eq;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.instore.dto.CounterCodesDetail;
import com.cellulant.instore.dto.NigeriaDto;
import com.cellulant.instore.dto.QRCode;
import com.cellulant.instore.dto.ServiceInfo;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.CounterCodes;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CounterResponseDto;
import com.cellulant.instore.response.CountersDto;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

@ExtendWith(MockitoExtension.class)
class TestCreateCounterForNigeria {

	@InjectMocks
	private CreateCounterForNigeria createCounterForNigeria;

	@Mock
	private UserRepository userRepository;

	@Mock
	private StoreRepository storeRepository;

	@Mock
	private CounterRepository counterRepository;
	@Mock
	private Gson gson;
	@Mock
	private ApplicationProperties applicationProperties;
	@Mock
	private CounterCodesRepository counterCodesRepository;
	@Mock
	private RestTemplate restTemplate;

	Stores store;

	@BeforeEach
	void setup() {
		store = new Stores();
		store.setStoreId(1l);
		store.setClientID(2155l);
	}

	@Test
	void testSaveCounterThrowError() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		List<Stores> storeList = new ArrayList<>();
		Stores store = new Stores();
		store.setStoreId(1l);
		store.setClientID(2155l);
		storeList.add(store);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		Counters counter = new Counters();
		String reference = (counterDto.getIsReference()).replaceAll("\\s", "");
		counter.setIsReference(reference.equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO);
		counter.setActive(applicationProperties.getActiveStatus());
		counter.setCounterName(counterDto.getCounterName());
		listOfCounter.add(counter);
		Integer maxCounter = 4;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);

		assertThrows(NullPointerException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testSaveCounterForAdmin() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		assertThrows(PermissionException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));
	}

	@Test
	void testSaveCounterUnAuth() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		assertThrows(PermissionException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testSaveCounterForCashier() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		List<CounterDto> counterDtoList = new ArrayList<>();
		String xCountryCode = "AFG";
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testSaveCounterThrowPhoneConstraint() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		counterPhoneList.add(countersDto);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");

		counterDto.setMsisdn("5985698");
		counterDtoList.add(counterDto);

		assertThrows(NullPointerException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testSaveCounterThrowCounterNameConstraint() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		counterPhoneList.add(countersDto);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");

		counterDto.setMsisdn("5985698");
		counterDtoList.add(counterDto);

		assertThrows(NullPointerException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testSaveCounterThrowException() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		CounterDto counterDto = new CounterDto();

		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDtoList.add(counterDto);
		Counters counter = new Counters();
		counter.setActive(1);
		counter.setCounterName(counterDto.getCounterName());
		listOfCounter.add(counter);
		Integer maxCounter = 4;
		List<Stores> storeList = new ArrayList<>();
		Stores stores = new Stores();
		stores.setStoreId(1l);
		storeList.add(stores);

		assertThrows(RuntimeException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testSaveCounterThrowStoreNotFound() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		CounterDto counterDto = new CounterDto();
		String xCountryCode = "AFG";
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDtoList.add(counterDto);
		Counters counter = new Counters();
		counter.setActive(1);
		counter.setCounterName(counterDto.getCounterName());
		listOfCounter.add(counter);
		Integer maxCounter = 4;
		assertThrows(NullPointerException.class,
				() -> createCounterForNigeria.createCounter(counterDtoList, casUser, "NGA"));

	}

	@Test
	void testupdateCounterCodeForNigeria() {
		CounterDto counterDto = new CounterDto("The Desc", 1l, "counter", "884152525", "Yes", 1, "test", 1l, "1");
		Stores store = new Stores(1l, 2155l, "test", "test", "test", "test", "1", "test", 1, "12");
		String JogoResponse = "{\"accountnumber\":\"123456789\",\"accountname\":\"test\",\"bankname\":\"test\"}";
		ResponseEntity<String> setupResponse = new ResponseEntity("	{\r\n" + "    \"data\": {\r\n"
				+ "        \"2155\": {\r\n" + "            \"customerID\": 2155,\r\n"
				+ "            \"customerName\": \"Azam\",\r\n" + "            \"customerCode\": \"AzamTechEnt.\",\r\n"
				+ "            \"customerLogo\": \"a8102d43-55a1-4e9e-b02c-c1bcfbd097be\",\r\n"
				+ "            \"mapping\": null,\r\n" + "            \"onboardingLevel\": {\r\n"
				+ "                \"onboardingLevelID\": 5,\r\n"
				+ "                \"onboardingLevelCode\": \"registration-approved\",\r\n"
				+ "                \"onboardingLevelName\": \"Registration Approved\"\r\n" + "            }\r\n"
				+ "        }\r\n" + "    },\r\n" + "    \"message\": \"Customers mapped successfuly\",\r\n"
				+ "    \"success\": true,\r\n" + "    \"statusCode\": 200\r\n" + "}", HttpStatus.OK);
		Mockito.when(restTemplate.getForEntity(Mockito.anyString(), eq(String.class))).thenReturn(setupResponse);

		assertThrows(ClassCastException.class, () -> createCounterForNigeria.updateCounterCodeForNigeria(store, "NGA"));

	}

	@Test
	void testGetServiceCode() {

		ResponseEntity<String> setupResponse = new ResponseEntity(
				"		{\n" + "		    \"data\": [\n" + "		        {\n"
						+ "		            \"serviceID\": 2079,\n" + "		            \"serviceCode\": \"test.\",\n"
						+ "		            \"serviceName\": \"test.\",\n" + "		            \"createdAt\": [\n"
						+ "		                2021,\n" + "		                5,\n"
						+ "		                27,\n" + "		                9,\n" + "		                23,\n"
						+ "		                56,\n" + "		                127000000\n"
						+ "		            ],\n" + "		            \"serviceOwnerID\": null,\n"
						+ "		            \"mapping\": {\n" + "		                \"id\": 1,\n"
						+ "		                \"code\": \"test.\"\n" + "		            }\n" + "		        }\n"
						+ "		    ],\n" + "		    \"message\": \"Customer's services fetched successfuly\",\n"
						+ "		    \"success\": true,\n" + "		    \"statusCode\": 200\n" + "		}",
				HttpStatus.OK);
		Mockito.when(restTemplate.getForEntity(applicationProperties.getServiceId() + 2155 + "/services" + "?mapping="
				+ "KEN" + "&paymentChannelCode=" + applicationProperties.getPaymentChannelCode(), String.class))
				.thenReturn(setupResponse);
		ServiceInfo code = createCounterForNigeria.getServiceCode(2155l, "KEN");
		assertNotNull(code);
	}

	@Test
	void testGetCounterCode() {
		String accountNUmber = "{\r\n" + "    \"success\": true,\r\n"
				+ "    \"statusMessage\": \"Data fetched successfully\",\r\n" + "    \"data\": {\r\n"
				+ "        \"wema\": [\r\n" + "            {\r\n"
				+ "                \"accountNumber\": \"7517220576\",\r\n"
				+ "                \"accountState\": \"ISSUED\",\r\n" + "                \"issuedTo\": \"test\",\r\n"
				+ "                \"dateCreated\": \"2022-05-02T03:38:47.504908\",\r\n"
				+ "                \"dateUpdated\": \"2022-05-02T03:38:47.504918\",\r\n"
				+ "                \"dateIssued\": \"2022-05-02T03:38:47.504882\"\r\n" + "            }\r\n"
				+ "        ]\r\n" + "    }\r\n" + "}";

		HttpHeaders headers = new HttpHeaders();
		headers.set("content-type", "application/json");
		List<String> list = new ArrayList<>();
		list.add("wema");
		NigeriaDto request = new NigeriaDto();

		HttpEntity<Object> http = new HttpEntity<>(request, headers);
		Mockito.when(restTemplate.postForObject(applicationProperties.getNigeriaUrl(), http, String.class))
				.thenReturn(accountNUmber);

		String countercode = createCounterForNigeria.getCounterCode(request);
		assertNull(countercode);
	}

	@Test
	void formulateResponse() {
		CounterDto dto = new CounterDto();
		CounterCodes codeDto = new CounterCodes();
		codeDto.setActive(1);
		codeDto.setCounterCode("1");
		codeDto.setCounterId(1l);
		dto.setCounterName("test");
		dto.setMsisdn("1234567876");
		dto.setStoreId(1l);
		dto.setCounterCodeTypeName("wema");
		QRCode qr = new QRCode();
		qr.setPdf("test");

		List<CounterCodesDetail> list = new ArrayList<>();

		CounterResponseDto countercode = createCounterForNigeria.formulateResponse(dto, codeDto);
		assertNotNull(countercode);
	}

	@Test
	void testFindCounterCodeTypeID() {
		int counterCodeTypeId = 1;
		Mockito.when(counterCodesRepository.findCounterCodeTypeName("wema")).thenReturn(counterCodeTypeId);
		int response = createCounterForNigeria.findCounterCodeTypeID("wema");

		assertNotNull(response);

	}

	@Test
	public void setCounterCodeInfo() {

		CounterCodes counterCodesDto = new CounterCodes();
		Counters counters = new Counters();
		counters.setCounterId(1l);
		Stores store = new Stores();
		store.setCountry("KEN");
		store.setCreatedBy(2155l);
		store.setModifiedBy(2155l);
		counterCodesDto.setActive(1);
		String counterCode = "123";
		int counterCodeTypeId = 3;
		CounterCodes response = createCounterForNigeria.setCounterCodeInfo(counters, store, counterCode,
				counterCodeTypeId);
		assertNotNull(response);

	}

}
