package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import com.cellulant.instore.response.MerchantDetail;

@ExtendWith(MockitoExtension.class)
 class TestMerchantDetail {
	
	@InjectMocks
	MerchantDetail merchantDetail;
	
	@Test
	void testBeans() {
		
		MerchantDetail merchantDetail =  new MerchantDetail();
		MerchantDetail allArgsMerchantDetail =  new MerchantDetail("amazon", "payment", "1",1l,"abc",1l,null,"Afg");
		
		MerchantDetail merchant = merchantDetail.builder().counterCode("1").storeName("amazon").build();
		
		merchantDetail.setCounterCode("1");
		merchantDetail.setCounterName("payment");
		merchantDetail.setStoreName("amazon");
		
		assertEquals("1", merchantDetail.getCounterCode());
		assertEquals("payment", merchantDetail.getCounterName());
		assertEquals("amazon", merchantDetail.getStoreName());
	}
	
	@Test
	void testToString() {
	assertNotNull(merchantDetail.toString())	;
	}

}
