package com.cellulant.instore.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.dto.StoreCounterCountDto;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.MerchantNotificationRepository;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.service.MerchantService;
import com.cellulant.instore.utils.AppConstants;

import javassist.NotFoundException;

@ExtendWith(MockitoExtension.class)
 class TestMerchantController {

	@InjectMocks
	private MerchantController merchantController;
	
	@Mock
	private CounterRepository  counterRepository;
	
	@Mock
	private MerchantService merchantService;
	
	@Mock
	private UserRepository userRepository;
	
	@Mock
	private MerchantNotificationRepository merchantNotificationRepository;;
	
	@Mock
	private StoreAssignmentRepository storeAssignmentRepository;
	
	@Test
	void testGetMerchantDetails() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String counterCode="12";
		String xcountry = "KEN";
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, counterCode);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(merchantService.getMerchantDetailByCounterCode(counterCode,xcountry)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = merchantController.getMerchantDetails(counterCode,xcountry, casUser);
		assertNotNull(success);
	}
	
	@Test
	void testGetMerchantNotification() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long clientId=12l;
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, clientId);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(merchantService.getMerchantDetailOnTheBasisOfClientId(clientId)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = merchantController.getMerchantNotification(clientId, casUser);
		assertNotNull(success);
	}
	
	@Test
	void testGetMerchantNotificationWithoutToken() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String counterCode="12";
		String xcountry = "KEN";
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, counterCode);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(merchantService.getCounterInfoByCounterCode(counterCode,xcountry)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = merchantController.getCounterInfo(counterCode,xcountry);
		assertNotNull(success);
	}
	
	@Test
	void testfetchStoresAndCountersCount() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long clientId=12l;
		Integer casUserId = 1;
		String xCountryCode = "ZMB";
		Long userId = null;
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, clientId);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
	
		Mockito.when(merchantService.getTotalCounterAndStoresofParticaularClient(casUser.getCustomerID(),casUser,xCountryCode)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = merchantController.fetchStoresAndCountersCount(xCountryCode,casUser);
		assertNotNull(success);
	}
	

	@Test
	void testFetchCountersAndCashiersCount() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long storeId=12l;
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, storeId);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(merchantService.getTotalCashierAndCounterOnTheBasisOfStoreId(storeId)).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = merchantController.fetchCountersAndCashiersCount(storeId,casUser);
		assertNotNull(success);
	}
	
	@Test
	void testFetchMerchantNotificationByUserId() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long userId=12l;
		String email ="email";
		Integer page =1;
		Integer size =10;
		Long counterCode = 123l;
		SuccessResponse response = new SuccessResponse(true, 200, AppConstants.COUNTER_ADDED_SUCCESSFULLY, userId);
		ResponseEntity<?> myResponse = new ResponseEntity<Object>(response,HttpStatus.OK);
		Mockito.when(merchantService.getMerchantDetailOnTheBasisOfEmail(email, page, size, counterCode,casUser,"ZMB")).thenReturn((ResponseEntity<Object>) myResponse);
		ResponseEntity<Object> success = merchantController.fetchMerchantNotificationByEmail(email,counterCode,page, size,"ZMB",casUser);
		assertNotNull(success);
	}
	

}
