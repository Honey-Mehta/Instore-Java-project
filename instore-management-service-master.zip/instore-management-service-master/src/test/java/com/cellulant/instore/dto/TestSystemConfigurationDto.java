package com.cellulant.instore.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestSystemConfigurationDto {

	@InjectMocks
	private SystemConfigurationDto systemConfigurationDto;
	
	@Test
	void testBeans() {
		SystemConfigurationDto systemConfigurationDto =  new SystemConfigurationDto();
		SystemConfigurationDto allArgssystemConfigurationDto = new SystemConfigurationDto("abc", "abc", "abc", "abc", 1l, "abc");
		
		systemConfigurationDto.setCallBackUrl("abc");
		systemConfigurationDto.setIsCallBack("abc");
		systemConfigurationDto.setRequestType("abc");
		assertEquals("abc", systemConfigurationDto.getCallBackUrl());
		assertEquals("abc", systemConfigurationDto.getIsCallBack());
		assertEquals("abc", systemConfigurationDto.getRequestType());
	}
}
