package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
 class TestStores {

	@InjectMocks
	Stores stores;

	
	
	
	@Test
    void testBean() {
		
		Stores stores = new  Stores();
		Stores allArgsStores = new Stores(1l, 1l, "flipkart", "Vienna Court", "nairobi", "kenya", "1bc", "abc", 1,null);
		
		stores.setStoreId(1l);
		stores.setClientID(1l);
		stores.setStoreName("flipkart");
		stores.setAddress("Vienna Court");
		stores.setCity("nairobi");
		stores.setCountry("kenya");
		stores.setStoreCode("abc");
		
		stores.setDescription("abc");
		stores.setActive(1);
		
		assertEquals(1l, (long)stores.getStoreId());
		assertEquals(1l, (long)stores.getClientID());
		assertEquals( "flipkart", stores.getStoreName());
		assertEquals("Vienna Court", stores.getAddress());
		assertEquals("nairobi", stores.getCity());
		assertEquals("kenya", stores.getCountry());
		assertEquals("abc", stores.getStoreCode());
		
		assertEquals("abc", stores.getDescription());
		assertEquals(1, (int)stores.getActive());
		stores.equals(allArgsStores);
		stores.hashCode();

	}
	
	@Test
	void onCreate() {
		stores.onCreate();
	}

	@Test
	void onUpdate() {
		stores.onUpdate();
	}

	@Test
	void testToString() {
		stores.toString();
		assertNotNull(stores.toString());
	}

	
	
}
