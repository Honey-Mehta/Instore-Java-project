package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestGenericPagedResponse {

	@InjectMocks
	private GenericPagedResponse<Object> genericPagedResponse;
	
	@Test
	void testBean() {
		
		GenericPagedResponse genericPagedResponse =  new GenericPagedResponse();
		GenericPagedResponse allArgsGenericPagedResponse =  new GenericPagedResponse<>(false, 123, "abc", 1l, 1l, 1l, 1, null);
		
		genericPagedResponse.setSuccess(false);
		genericPagedResponse.setStatusCode(123);
		genericPagedResponse.setTotalItems(1l);
		genericPagedResponse.setMessage("abc");
		genericPagedResponse.setSize(1l);
		genericPagedResponse.setTotalPages(1l);
		genericPagedResponse.setCurrentPage(1);
        
        assertEquals(1l,genericPagedResponse.getTotalItems());
        assertEquals("abc", genericPagedResponse.getMessage());
        assertEquals(1l, genericPagedResponse.getSize());
        assertEquals(1l, genericPagedResponse.getTotalPages());
		
	}
	
	@Test
	void testToString() {
		genericPagedResponse.toString();
		assertNotNull(genericPagedResponse.toString());
	}
}
