package com.cellulant.instore.request;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cellulant.instore.model.IsReference;

@ExtendWith(MockitoExtension.class)
class TestCounterDto {

	@InjectMocks
	private CounterDto counterDto;

	@Test
	void testBean() {

		CounterDto counterDto = new CounterDto();

		CounterDto allArgsCounterDto = new CounterDto("test", 1l, "test", "1234455676", "NO", 1, "test",1l, "22");

		counterDto.builder().counterName("abc").build();

		counterDto.setCounterName("amazon");

		counterDto.setDescription("abc");
		counterDto.setMsisdn("1234");

		assertEquals("amazon", counterDto.getCounterName());

		assertEquals("abc", counterDto.getDescription());
		assertEquals("1234", counterDto.getMsisdn());

	}

	@Test
	void testToString() {
		counterDto.toString();
		assertNotNull(counterDto.toString());
	}

}
