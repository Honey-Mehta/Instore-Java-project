package com.cellulant.instore.exception;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MissingServletRequestParameterException;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.GlobalExceptionHandler;
import com.cellulant.instore.exceptions.InvalidInputException;
import com.cellulant.instore.exceptions.MissingParameterException;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.response.ErrorResponse;
import com.cellulant.instore.response.Response;
import com.cellulant.instore.utils.AppConstants;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

@ExtendWith(MockitoExtension.class)
 class TestGlobalExceptionHandler {

	@InjectMocks
	GlobalExceptionHandler globalExceptionHandler;
	
	@Test
	void testHandlerException() {
		ErrorResponse error = ErrorResponse.builder().success(false).statusCode(AppConstants.NOT_FOUND)
				.message(AppConstants.STOREID_NOT_FOUND).data(null).build();
		ResponseEntity<Object> response= globalExceptionHandler.handlerException(new NotFoundExceptions("store Not Found"));
		assertNotNull(response);
	}
	
	
	@Test
	void testHandleAllExceptions() {
		Exception ex = new Exception();
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE, AppConstants.INTERNAL_SERVER_ERROR_MESSAGE, null, details);
		ResponseEntity<Object> responseEntity = globalExceptionHandler.handleAllExceptions(ex, null);
		assertNotNull(responseEntity);
	}
	
	@Test
	void testHandleValidationException() {
		Exception ex = new Exception();
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.VALIDATION_FAILED, null, details);
		ResponseEntity<Object> responseEntity = globalExceptionHandler.handleValidationException(ex, null);
       assertNotNull(responseEntity);
	}
	
	@Test
	void testHandleMethodArgumentTypeMismatchException() {
		Exception ex = new Exception();
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = ErrorResponse.builder().statusCode(AppConstants.BAD_REQUEST_STATUS_CODE)
				.message(AppConstants.METHOD_ARGUMENT_MISMATCH).data(details).build();
		ResponseEntity<Object> responseEntity = globalExceptionHandler.handleMethodArgumentTypeMismatchException(ex, null);
	       assertNotNull(responseEntity);
	}
	
	@Test
	void testNoSuchProviderException()	
	{
	   NoSuchProviderException ex = new NoSuchProviderException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleNoSuchProviderException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testIOException()	
	{
		IOException ex = new IOException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleIOException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testJsonParseException()	
	{
		JsonParseException ex = new JsonParseException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleJsonParseException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testJsonSyntaxException()	
	{
		JsonSyntaxException ex = new JsonSyntaxException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleJsonSyntaxException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testIllegalArgumentException()	
	{
		IllegalArgumentException ex = new IllegalArgumentException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleIllegalArgumentException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testNumberFormatException()	
	{
		NumberFormatException ex = new NumberFormatException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleNumberFormatException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testMissingServletRequestParameterException()	
	{
		MissingServletRequestParameterException ex = new MissingServletRequestParameterException("test", "test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleMissingServletRequestParameter(ex, null, null, null);
       assertNotNull(responseEntity);
	
	}
	
	@Test
	void testNullPointerException()	
	{
		NullPointerException ex = new NullPointerException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handleNullPointerException(ex, null);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testhandlerPermissionException()	
	{
		PermissionException ex = new PermissionException("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handlerPermissionException(ex);
       assertNotNull(responseEntity);
	
	}
	@Test
	void testhandlerPhoneNumberAlreadyExistException()	
	{
		AlreadyExistExceptions ex = new AlreadyExistExceptions("test");
	   ResponseEntity<Object> responseEntity = globalExceptionHandler.handlerPhoneNumberAlreadyExistException(ex);
       assertNotNull(responseEntity);
	
	}
	
		
	@Test
     void missingParameterExceptionTest() {

        Response response = globalExceptionHandler.missingParameterExceptionHandler(
                new MissingParameterException("Aweosme")
        );

        assertThat(response).isNotNull();
        assertThat(response.isSuccess()).isFalse();
        assertThat(response.getMessage()).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(172);
    }
	
	 @Test
	  void onConstraintValidationException_Test() {
	        CASUser accessTokenRequest =CASUser.builder().customerID(1l).build();

	        Validator validator = (Validator) Validation.buildDefaultValidatorFactory().getValidator();

	        Set<ConstraintViolation<CASUser>> violations = validator.validate(accessTokenRequest);

	        ConstraintViolationException constraintViolationException = new ConstraintViolationException(violations);

	        Response apiResponse = globalExceptionHandler.onConstraintValidationException(constraintViolationException);
	        assertThat(apiResponse).isNotNull();
	        assertThat(apiResponse.isSuccess()).isFalse();

	    }
	 

	  @Test
	     void invalidInputExceptionHandlerTest() {

		  ResponseEntity<Object> response = globalExceptionHandler.invalidInputExceptionHandler(
	                new InvalidInputException("amazing")
	        );

	        assertThat(response).isNotNull();
	    }
	  
	  @Test
	     void handleHttpMessageNotReadableTest() {
	        String erorMessage = "Malformed JSON";
	        ResponseEntity<Object> response = globalExceptionHandler.
	                handleHttpMessageNotReadable(new HttpMessageNotReadableException(erorMessage), null, null,
	                        null);

	        Response apiResponse = (Response) response.getBody();
	        assertThat(apiResponse).isNotNull();
	        assertThat(apiResponse.isSuccess()).isFalse();
	        assertThat(apiResponse.getMessage()).isNotNull();

	    }
}
