package com.cellulant.instore.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.DeviceIDRequest;
import com.cellulant.instore.dto.SystemConfigurationDto;
import com.cellulant.instore.dto.SystemConfigurationRequest;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.MappingDeviceID;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.MappingDeviceIdRepository;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.utils.ApplicationProperties;

import javassist.NotFoundException;

@ExtendWith(MockitoExtension.class)
 class TestSystemConfigurationServiceImpl {

	@InjectMocks
	private SystemConfigurationServiceImpl systemConfigurationServiceImpl;
	
	@Mock
    private ApplicationProperties applicationProperties; 
	
	@Mock
	private SystemConfigurationRepository systemConfigurationRepository;
	
	@Mock
	private UserRepository userRepository;
	
	@Mock
	private MappingDeviceIdRepository mappingDeviceIdRepository;
	
	@Test
	void testSaveSystemConfiguration() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		systemConfiguration.setActive(applicationProperties.getActiveStatus());
		ResponseEntity<Object> response = systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser);
		assertNotNull(response);
	}
	
	@Test
	void testSaveSystemConfigurationAdmin() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		List<SystemConfiguration> systemConfigurationList = new ArrayList<>();
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		systemConfiguration.setActive(applicationProperties.getActiveStatus());
		systemConfigurationList.add(systemConfiguration);
		Mockito.when(systemConfigurationRepository.getMerchanthasConfigValueOrNot(systemConfigurationRequest.getClientId())).thenReturn(systemConfigurationList);
		ResponseEntity<Object> response = systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser);
		assertNotNull(response);
	}
	
	@Test
	void testSaveSystemConfigurationStoreManager() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		List<SystemConfiguration> systemConfigurationList = new ArrayList<>();
		Long userIdForCashier =null ;
		Long userIdForStoreManager = 1l;
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		systemConfiguration.setActive(applicationProperties.getActiveStatus());
		systemConfigurationList.add(systemConfiguration);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		 assertThrows(PermissionException.class,
	                () -> systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser));
	}
	
	@Test
	void testSaveSystemConfigurationmerchant() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		List<SystemConfiguration> systemConfigurationList = new ArrayList<>();
		Long userIdForCashier =null ;
		Long userIdForStoreManager = null;
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		systemConfiguration.setActive(applicationProperties.getActiveStatus());
		systemConfigurationList.add(systemConfiguration);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
	//	Mockito.when(systemConfigurationRepository.getMerchanthasConfigValueOrNot(systemConfigurationRequest.getClientId())).thenReturn(systemConfigurationList);
		ResponseEntity<Object> response = systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser);
		assertNotNull(response);
	}
	@Test
	void testSaveSystemConfigurationAdminUpdate() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		List<SystemConfiguration> systemConfigurationList = new ArrayList<>();
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		systemConfiguration.setActive(applicationProperties.getActiveStatus());
		systemConfigurationList.add(systemConfiguration);
		int value =1;
		Mockito.when(systemConfigurationRepository.getMerchanthasConfigValueOrNot(systemConfigurationRequest.getClientId())).thenReturn(systemConfigurationList);
		Mockito.when(systemConfigurationRepository.deactivateSystemConfigurationOnTheBasisOfClientId(systemConfigurationRequest.getClientId())).thenReturn(value);
		ResponseEntity<Object> response = systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser);
		
		assertNotNull(response);
	}
	
	@Test
	void testSaveSystemConfigurationAdminError() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		List<SystemConfiguration> systemConfigurationList = null;
		
		Mockito.when(systemConfigurationRepository.getMerchanthasConfigValueOrNot(systemConfigurationRequest.getClientId())).thenReturn(null);
		ResponseEntity<Object> response = systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser);
		assertNotNull(response);
		
	}
	
	@Test
	void testSaveSystemConfigurationNotAdminNotCustomer() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
		List<SystemConfiguration> systemConfigurationList = null;
	
		 assertThrows(PermissionException.class,
	                () -> systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser));
	}
	
	@Test
	void testSaveSystemConfigurationNotAdmin() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
	
		 assertThrows(PermissionException.class,
	                () -> systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser));
	}
	
	@Test
	void testSaveSystemConfigurationExceptions() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		SystemConfigurationDto systemConfigurationRequest = new SystemConfigurationDto("abc","abc", "abc", null, null, null);
	
		assertThrows(NullPointerException.class,
                () -> systemConfigurationServiceImpl.saveSystemConfiguration(systemConfigurationRequest, casUser));
	}
	

	
	@Test
	void testRemoveSystemConfiguration() throws NotFoundExceptions, NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long systemConfigurationId = 1l;
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		int i = 1;
		Mockito.when(systemConfigurationRepository.findSystemConfigurationById(systemConfigurationId)).thenReturn(systemConfiguration);
		Mockito.when(systemConfigurationRepository.deleteSystemConfigurationById(systemConfigurationId)).thenReturn(i);
		ResponseEntity<Object> response = systemConfigurationServiceImpl.removeSystemConfigurationById(systemConfigurationId, casUser);
		assertNotNull(response);
	}
	
	@Test
	void testRemoveSystemConfigurationNotUpdated() throws NotFoundExceptions, NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long systemConfigurationId = 1l;
		SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("true");
		int i = -1;
		Mockito.when(systemConfigurationRepository.findSystemConfigurationById(systemConfigurationId)).thenReturn(systemConfiguration);
		Mockito.when(systemConfigurationRepository.deleteSystemConfigurationById(systemConfigurationId)).thenReturn(i);
		ResponseEntity<Object> response = systemConfigurationServiceImpl.removeSystemConfigurationById(systemConfigurationId, casUser);
		assertNotNull(response);
	}
	
	@Test
	void testRemoveSystemConfigurationNotFound() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long systemConfigurationId = 1l;
		SystemConfiguration systemConfiguration = null;
		Mockito.when(systemConfigurationRepository.findSystemConfigurationById(systemConfigurationId)).thenReturn(systemConfiguration);
		assertThrows(NotFoundExceptions.class,
                () -> systemConfigurationServiceImpl.removeSystemConfigurationById(systemConfigurationId, casUser));
	}
	
	@Test
	void testRemoveSystemConfigurationNotAdmin() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		Long systemConfigurationId = 1l;
		SystemConfiguration systemConfiguration = null;
		ResponseEntity<Object> response = systemConfigurationServiceImpl.removeSystemConfigurationById(systemConfigurationId, casUser);
		assertNotNull(response);
	}
	
	 
	@Test
	void testRemoveSystemConfigurationThrowExceptions() throws NotFoundException {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		Long systemConfigurationId = 1l;
		SystemConfiguration systemConfiguration = null;

		 assertThrows(NullPointerException.class,
	                () -> systemConfigurationServiceImpl.removeSystemConfigurationById(systemConfigurationId, casUser));
	}
	
	@Test
	void testGetSystemConfiguration() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 Long merchantId = 1l;
		 int page = 1;
		 int size = 1;
		 Pageable paging = PageRequest.of(page-1, size);
		 List<SystemConfiguration> systemConfigurationList =  new ArrayList<>();
		 SystemConfiguration systemConfiguration = new  SystemConfiguration();
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("abc");
		systemConfiguration.setConfigValue("abc");
		systemConfigurationList.add(systemConfiguration);
		Page<SystemConfiguration> pageResponse = new PageImpl(systemConfigurationList);
		Mockito.when(systemConfigurationRepository.fetchSystemConfigurationByMerchantId(paging, merchantId)).thenReturn(pageResponse);
		Page<SystemConfiguration> Response = systemConfigurationServiceImpl.getSystemConfiguration(casUser, page, size, merchantId);
		assertNotNull(Response);
			
	}
	
	
	@Test
	void testAddDeviceIdForAdmin() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		DeviceIDRequest request =  new DeviceIDRequest();
		request.setDeviceID("Hahahahaha");
		request.setRole("Administrator");
		assertThrows(PermissionException.class,()-> systemConfigurationServiceImpl.saveDeviceId(request, casUser));
		
		
	}
	
	@Test
	void testAddDeviceIdForMerchant() {
		CASUser casUser = CASUser.builder().customerID(1l).userID(1l).customerLevel(Code.CUSTOMER).build();
	
	System.out.println("UserId "+casUser.getUserID());
		DeviceIDRequest deviceIDRequest =  new DeviceIDRequest();
		deviceIDRequest.setDeviceID("Hahahahaha");
		deviceIDRequest.setRole("merchant-Admin");
		MappingDeviceID mapping = new MappingDeviceID(1l, 2155l, "Hahahahaha", "merchant-Admin", 3145l, 1);
		Mockito.when(mappingDeviceIdRepository.findMappingByDeviceId(deviceIDRequest.getDeviceID(), casUser.getUserID(), deviceIDRequest.getRole())).thenReturn(mapping);
		assertDoesNotThrow(()-> systemConfigurationServiceImpl.saveDeviceId(deviceIDRequest, casUser));
		
	}
	
	@Test
	void testAddDeviceIdForMerchantNewDevice() {
		CASUser casUser = CASUser.builder().customerID(1l).userID(1l).customerLevel(Code.CUSTOMER).build();
	
	System.out.println("UserId "+casUser.getUserID());
		DeviceIDRequest deviceIDRequest =  new DeviceIDRequest();
		deviceIDRequest.setDeviceID("Hahahahaha");
		deviceIDRequest.setRole("merchant-Admin");
		MappingDeviceID mapping = null;
		MappingDeviceID deviceIdObject = new MappingDeviceID(1l, 2155l, "Hahahahaha", "merchant-Admin", 3145l, 1);
		Mockito.when(mappingDeviceIdRepository.findMappingByDeviceId(deviceIDRequest.getDeviceID(), casUser.getUserID(), deviceIDRequest.getRole())).thenReturn(mapping);
Mockito.when(mappingDeviceIdRepository.findMappingByDeviceIdWithAlternativeRole(deviceIDRequest.getDeviceID(), deviceIDRequest.getRole())).thenReturn(deviceIdObject);
		assertDoesNotThrow(()-> systemConfigurationServiceImpl.saveDeviceId(deviceIDRequest, casUser));
		
		
	}
	
	@Test
	void testAddDeviceIdForMerchantNewDeviceNull() {
		CASUser casUser = CASUser.builder().customerID(1l).userID(1l).customerLevel(Code.CUSTOMER).build();
	
	System.out.println("UserId "+casUser.getUserID());
		DeviceIDRequest deviceIDRequest =  new DeviceIDRequest();
		deviceIDRequest.setDeviceID("Hahahahaha");
		deviceIDRequest.setRole("merchant-Admin");
		MappingDeviceID mapping = null;
		MappingDeviceID deviceIdObject = null;
		Mockito.when(mappingDeviceIdRepository.findMappingByDeviceId(deviceIDRequest.getDeviceID(), casUser.getUserID(), deviceIDRequest.getRole())).thenReturn(mapping);
Mockito.when(mappingDeviceIdRepository.findMappingByDeviceIdWithAlternativeRole(deviceIDRequest.getDeviceID(), deviceIDRequest.getRole())).thenReturn(deviceIdObject);
		assertDoesNotThrow(()-> systemConfigurationServiceImpl.saveDeviceId(deviceIDRequest, casUser));
		
		
	}


}
