package com.cellulant.instore.dto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestStoreCounterCountDto {

	@InjectMocks
	private StoreCounterCountDto storeCounterCountDto;
	

	@Test
	void testBean() {
		StoreCounterCountDto storeCounterCountDto = new StoreCounterCountDto();
		StoreCounterCountDto allArgsStoreCounterCountDto = new StoreCounterCountDto(1l, 1l);
		
		storeCounterCountDto.setCounterCount(1l);
		storeCounterCountDto.setStoreCount(1l);
		
		assertEquals(1l, (long) storeCounterCountDto.getStoreCount());
		assertEquals(1l, (long) storeCounterCountDto.getCounterCount());
		
		
	}
	
	@Test
	void testToString() {
		storeCounterCountDto.toString();
		assertNotNull(storeCounterCountDto.toString());
	}
	
}
