package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.math.BigInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestSystemConfiguration {
	
	@InjectMocks
	SystemConfiguration systemConfiguration;

	
	
	
	@Test
    void testBean() {
		
		SystemConfiguration systemConfiguration = new SystemConfiguration();
		SystemConfiguration allArgsSystemConfiguration = new SystemConfiguration(1l, 1l, "aaabbc", "aaabbc", 1);
		
		systemConfiguration.setSystemConfigurationId(1l);
		systemConfiguration.setClientId(1l);
		systemConfiguration.setConfigKey("aaabbc");
		systemConfiguration.setConfigValue("aaabbc");
		systemConfiguration.setActive(1);
		
		
		
		assertEquals(1l, (long)systemConfiguration.getSystemConfigurationId());
		assertEquals(1l, (long)systemConfiguration.getClientId());
		assertEquals("aaabbc",systemConfiguration.getConfigKey());
		assertEquals("aaabbc", systemConfiguration.getConfigValue());
		assertEquals(1, (int)systemConfiguration.getActive());
		systemConfiguration.equals(allArgsSystemConfiguration);
		systemConfiguration.hashCode();

	}
	
	@Test
	void onCreate() {
		systemConfiguration.onCreate();
	}

	@Test
	void onUpdate() {
		systemConfiguration.onUpdate();
	}

	@Test
	void testToString() {
		systemConfiguration.toString();
		assertNotNull(systemConfiguration.toString());
	}
	

}
