package com.cellulant.instore.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.StoreDto;
import com.cellulant.instore.response.StoreDetail;
import com.cellulant.instore.response.StoresParam;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;

import javassist.NotFoundException;

@ExtendWith(MockitoExtension.class)
 class TestStoreServiceImpl {

	@InjectMocks
	private StoreServiceImpl storeServiceImpl;
	
	
	@Mock
	private StoreRepository storeRepository;
	
	@Mock
	private SystemConfigurationRepository systemConfigurationRepository;
	
	@Mock
	private ApplicationProperties applicationProperties;
	
	
	@Mock
	private StoreAssignmentRepository storeAssignmentRepository;
	
	@Mock
	private UserRepository userRepository;



	@Test
	void testFindStoreById() {
		Stores stores = new Stores();
		stores.setActive(1);
		stores.setClientID(1l);
		stores.setStoreId(1l);
		Long storeId =1l;

		assertNotNull(stores);
	}
	

	void testFindStoreDetail() throws NotFoundExceptions {

		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = null;
		Long userIdForCashier = null;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeId, casUser.getCustomerID())).thenReturn(new Stores(storeId, userIdForCashier, null, null, null, null, null, null, null,null));
		Mockito.when(storeRepository.fetchstoresById(storeId)).thenReturn(storeDetailList);
		ResponseEntity<Object> response = storeServiceImpl.findStoreDetail(storeId,casUser);
		assertNotNull(response);
		
	}
	
	@Test
	void testFindStoreDetailForStoreManger() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = 1l;
		Long userIdForCashier = null;
		Long storeIdFromStoreAssignment = 1l;
		Stores stores = new Stores(storeId, storeIdFromStoreAssignment, null, null, null, null, null, null, null,null);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userId);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeIdFromStoreAssignment);
		Mockito.when(storeRepository.findStoreById(storeIdFromStoreAssignment)).thenReturn(stores);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(stores.getStoreId(), casUser.getCustomerID())).thenReturn(stores);
		
		ResponseEntity<Object> response = storeServiceImpl.findStoreDetail(storeId,casUser);
		assertNotNull(response);
		
	}
	
	@Test
	void testFindStoreDetailForStoreMangerNotPermision() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = 1l;
		Long userIdForCashier = null;
		Long storeIdFromStoreAssignment = 1l;
		Stores stores = new Stores(storeId, storeIdFromStoreAssignment, null, null, null, null, null, null, null,null);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userId);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeIdFromStoreAssignment);
		Mockito.when(storeRepository.findStoreById(storeIdFromStoreAssignment)).thenReturn(stores);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(stores.getStoreId(), casUser.getCustomerID())).thenReturn(null);

		
		
		 assertThrows(PermissionException.class,
	                () -> storeServiceImpl.findStoreDetail(storeId,casUser));

		
	}
	
	@Test
	void testFindStoreDetailForStoreMangerNotNotFound() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = 1l;
		Long userIdForCashier = null;
		Long storeIdFromStoreAssignment = 1l;
		Stores stores = new Stores(storeId, storeIdFromStoreAssignment, null, null, null, null, null, null, null,null);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userId);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeIdFromStoreAssignment);
		Mockito.when(storeRepository.findStoreById(storeIdFromStoreAssignment)).thenReturn(null);

		assertThrows(NotFoundExceptions.class,
                () -> storeServiceImpl.findStoreDetail(storeId,casUser));

	}
	
	@Test
	void testFindStoreDetailForAdmin() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		
		Mockito.when(storeRepository.fetchstoresById(storeId)).thenReturn(storeDetailList);
		ResponseEntity<Object> response = storeServiceImpl.findStoreDetail(storeId,casUser);
		assertNotNull(response);
		
	}
	
	@Test
	void testFindStoreDetailForCashier() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = null;
		Long userIdForCashier = 1l;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userId);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);

		 assertThrows(PermissionException.class,
	                () -> storeServiceImpl.findStoreDetail(storeId,casUser));

		
	}
	
	
	@Test
	void testFindStoreDetailError() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = null;
		Long userIdForCashier = 1l;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenThrow(new RuntimeException());

		 assertThrows(RuntimeException.class,
	                () -> storeServiceImpl.findStoreDetail(storeId,casUser));

		
	}
	
	@Test
	void testFindStoreDetailUnAuth() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = null;
		Long userIdForCashier = 1l;

		 assertThrows(PermissionException.class,
	                () -> storeServiceImpl.findStoreDetail(storeId,casUser));
		
	}
	

	@Test
	void testFindStoreDetailNot() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = null;
		Long userIdForCashier = null;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeId, casUser.getCustomerID())).thenReturn(new Stores(storeId, userIdForCashier, null, null, null, null, null, null, null,null));

		Mockito.when(storeRepository.fetchstoresById(storeId)).thenThrow(new NotFoundExceptions(AppConstants.STORE_NOT_FOUND));
		 assertThrows(NotFoundExceptions.class,
	                () ->  storeServiceImpl.findStoreDetail(storeId,casUser));

		
	}
	
	@Test
	void testFindStoreDetailForMerchantUnAuth() {
		Long storeId = 1l;
		List<StoreDetail> storeDetailList =  new ArrayList<>();
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		StoreDetail storeDetail= new StoreDetail();
		storeDetail.setCounterMsisdn("123456");
		storeDetail.setCounterName("amazon");
		storeDetail.setStoreId(1l);
		storeDetailList.add(storeDetail);
		Long userId = null;
		Long userIdForCashier = null;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);

		  assertThrows(PermissionException.class,
	                () -> storeServiceImpl.findStoreDetail(storeId,casUser));
		
	}
	
	
	
	@Test
	void testDeleteStoreById() {
		
		Long storeId=1l;
		Mockito.when(storeRepository.deleteStoreById(storeId)).thenReturn(1);
		int value = storeServiceImpl.deleteStoreById(storeId);
		assertNotNull(storeId);
	}
	


	 
	 @Test
	 void testCreateStores() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());
		 List<Stores> storesList= new ArrayList<>();
		 List<SystemConfiguration> systemConfigurationList= new ArrayList<>();
		 SystemConfiguration systemConfiguration =  new SystemConfiguration();
		 Stores store = new Stores();
		 Long userIdForCashier = null;
			Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		 Mockito.when(storeRepository.findByStoreName(storeDto.getStoreName(),casUser.getCustomerID())).thenReturn(storesList);
		 Mockito.when(systemConfigurationRepository.getMerchanthasConfigValueOrNot(casUser.getCustomerID())).thenReturn(systemConfigurationList);
           ResponseEntity<Object> response = storeServiceImpl.createStores(storeDto,casUser);
 		 assertNotNull(response);
 	       
	 }
	 
	 @Test
	 void testCreateStoresForAdmin() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());

           assertThrows(PermissionException.class,
                   () ->storeServiceImpl.createStores(storeDto,casUser));

 	       
	 }
	 
	 
	 @Test
	 void testCreateStoresForStoreManager() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());
		 Long userIdForCashier = null;
			Long userIdForStoreManager = 1l;
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		
         
           assertThrows(PermissionException.class,
                   () -> storeServiceImpl.createStores(storeDto,casUser));

 	       
	 }
	 
	 @Test
	 void testCreateStoresUnAuth() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());

		 assertThrows(PermissionException.class,
	                () ->storeServiceImpl.createStores(storeDto,casUser));

 	       
	 }
	 
	 @Test
	 void testCreateStoresForCashier() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());
		 Long userIdForCashier = 1l;
			Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);


           assertThrows(PermissionException.class,
                   () -> storeServiceImpl.createStores(storeDto,casUser));

 	       
	 }
	 
	 
	 @Test
	 void testCreateStoresStoreName() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());
		 List<Stores> storesList= new ArrayList<>();
		 List<SystemConfiguration> systemConfigurationList= new ArrayList<>();
		 SystemConfiguration systemConfiguration =  new SystemConfiguration();
		 Stores store = new Stores();
		 store.setActive(1);
		 store.setStoreId(1l);
		 store.setStoreName("abc-abc");
		 storesList.add(store);
		 Long userIdForCashier = null;
			Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		 Mockito.when(storeRepository.findByStoreName(storeDto.getStoreName(),casUser.getCustomerID())).thenReturn(storesList);


           assertThrows(AlreadyExistExceptions.class,
                   () -> storeServiceImpl.createStores(storeDto,casUser));

 	       
	 }
	 
	 @Test
	 void testCreateStoresthrowExceptiom() {
		 CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 StoreDto storeDto= new StoreDto();
		 storeDto.setStoreName("amazon");
		 storeDto.setActive(applicationProperties.getActiveStatus());
		 List<Stores> storesList= new ArrayList<>();
		 List<SystemConfiguration> systemConfigurationList= new ArrayList<>();
		 SystemConfiguration systemConfiguration =  new SystemConfiguration();
		 Stores store = new Stores();
		 store.setActive(1);
		 store.setStoreId(1l);
		 store.setStoreName("abc-abc");
		 storesList.add(store);
		 Long userIdForCashier = null;
			Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		 Mockito.when(storeRepository.findByStoreName(storeDto.getStoreName(),casUser.getCustomerID())).thenThrow(new RuntimeException());

           assertThrows(RuntimeException.class,
                   () -> storeServiceImpl.createStores(storeDto,casUser));

 	       
	 }
	 

	
	 
	 @Test
	 void updateStores() throws NotFoundException {

		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
	     List<Stores> storeList = new ArrayList<>();
	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1,null);
	     storeList.add(store);
	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1,null);
	     Long userIdForCashier =null;
	     Long userIdForStoreManager = null;
	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
	     Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(store);
	     Mockito.when(storeRepository.findByStoreId(storeDto.getStoreId())).thenReturn(storeList);
	     Mockito.when(storeRepository.findStoreById(storeDto.getStoreId())).thenReturn(store);

	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
	     assertNotNull(response);
	 }
	 
//	 @Test
//
//	 void updateStoresForAdmin() throws NotFoundException {
//
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }
	 

//	 
//	 @Test
//	 void updateStoresForUNAuth() throws NotFoundException {
//
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }
	 
	
	 
//	 @Test
//	 void updateStoresError() {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenThrow(new RuntimeException());
//	   
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }
	 
	 
//	 @Test
//	 void updateStoresForStoremangerUnAuth() {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = 1l;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	   
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }
	 
//	 @Test
//	 void updateStoresForStoremanger() {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = 1l;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	   Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(storeDbData);
//	    
//
//	     assertThrows(PermissionException.class,
//	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	 }
//	 
	 @Test
	 void updateStoresPermissionDeneid() throws NotFoundException {
		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
	     List<Stores> storeList = new ArrayList<>();
	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1,null);
	     storeList.add(store);
	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1,null);
	     Long userIdForCashier =null;
	     Long userIdForStoreManager = null;
	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
	     Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(null);
	     assertThrows(PermissionException.class,
	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
	 }
//	 
//	 @Test
//	 void updateStoresError() throws NotFoundException {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenThrow(new RuntimeException());
//	     assertThrows(RuntimeException.class,
//	                () ->storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	 }
//	 
//	 
//	 @Test
//	 void updateStoresForStoremangerUnAuth() throws NotFoundException {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = 1l;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	     assertThrows(PermissionException.class,
//	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	 }
//	 
//	 @Test
//	 void updateStoresForStoremanger() throws NotFoundException {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     storeList.add(store);
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = 1l;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	   Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(storeDbData);
//	     assertThrows(NotFoundExceptions.class,
//	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	     
//	 }
//	 
//	 
//	 @Test
//	 void updateStoresNotFound() throws NotFoundException {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	    
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	     Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(store);
//	     Mockito.when(storeRepository.findByStoreId(storeDto.getStoreId())).thenReturn(storeList);	   
//	     assertThrows(NotFoundExceptions.class,
//	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	 }
	 
//	 @Test
//	 void updateStoresForCashier() throws NotFoundException {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	    
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =1l;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	     assertThrows(PermissionException.class,
//	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	 }
	 
//	 @Test
//	 void updateStoresException() throws NotFoundException {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	    
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	     Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(store);
//	     Mockito.when(storeRepository.findByStoreId(storeDto.getStoreId())).thenThrow(new NotFoundExceptions(AppConstants.STORE_NOT_FOUND));
//	 
//	     assertThrows(NotFoundExceptions.class,
//	                () -> storeServiceImpl.updateStoresInfo(storeDto, casUser));
//	 }

	 
	
	 
//	 @Test
//	 void testFindStoreByIdTest() {
//		 Long storeId =1l;
//		 Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//		
//		 Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
//		 Stores response = storeServiceImpl.findStoreById(storeId);
//		 assertNotNull(response);
//	 }
//	 
//	 @Test
//	 void testGetStoresForStoreManager() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		
//		 Mockito.when(storeRepository.fetchStoresForAdminWithOutxCountryCode(paging)).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 
//	 @Test
//	 void testGetStoresNoAuth() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		
//		 assertThrows(PermissionException.class,
//	                () -> storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//	    					xCountryCode,casUserId));
//	 }
	 
//	 @Test
//	 void testGetStoresForYesStoreManager() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//			Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userId);
//			Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 
//		@Test
//		void testGetStoresForNoStoreManager() {
//			String searchStores = "";
//			int page = 1;
//			int size = 1;
//			Long casUserId = 1l;
//			String xCountryCode = "";
//			Long userId = 1l;
//			Long storeId = 1l;
//			Long userIdForCashier = null;
//			Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//			CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//			List<StoresParam> storeParamList = new ArrayList<>();
//			StoresParam storeParam = new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l, "abc");
//			storeParamList.add(storeParam);
//			Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//			Pageable paging = PageRequest.of(page - 1, size);
//
//			Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
//					.thenReturn(userId);
//			Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
//					.thenReturn(userIdForCashier);
//			Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeId);
//			Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(stores);
//			Mockito.when(storeRepository.findStoresForStoresManager(paging,
//								storeId)).thenReturn(pagingRequest);
//			ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores, page, size,
//					casUser, xCountryCode, casUserId);
//			assertNotNull(response);
//		}
	
	 
//	 @Test
//	 void testGetStoresThrowExceptions() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "zmb";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenThrow(new RuntimeException());
//
//		 assertThrows(RuntimeException.class,
//	                () ->storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//	    					xCountryCode,casUserId));
//
//	 }
//	 
	 
//	 @Test
//	 void updateStoresNotFound() {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	    
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	     Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(store);
//	     Mockito.when(storeRepository.findByStoreId(storeDto.getStoreId())).thenReturn(storeList);
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }
	 
//	 @Test
//	 void updateStoresForCashier() {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	    
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =1l;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }
	 
//	 @Test
//	 void updateStoresException() {
//		 StoreDto storeDto = new StoreDto(1l, "abc", "123", null, null, null, null, null);
//	     CASUser casUser= CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//	     List<Stores> storeList = new ArrayList<>();
//	     Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	    
//	     Stores storeDbData = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//	     Long userIdForCashier =null;
//	     Long userIdForStoreManager = null;
//	     Mockito.when(userRepository.findCashier(casUser.getUserID(),
//					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//	     Mockito.when(userRepository.findCasUser(casUser.getUserID(),
//					applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
//	     Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(), casUser.getCustomerID())).thenReturn(store);
//	     Mockito.when(storeRepository.findByStoreId(storeDto.getStoreId())).thenThrow(new RuntimeException());
//	     ResponseEntity<Object> response = storeServiceImpl.updateStoresInfo(storeDto, casUser);
//	     assertNotNull(response);
//	 }

	 
	
	 
//	 @Test
//	 void testFindStoreByIdTest() {
//		 Long storeId =1l;
//		 Stores store = new Stores(1l, 1l, "abc", null, null, null, null, null, 1);
//		
//		 Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(store);
//		 Stores response = storeServiceImpl.findStoreById(storeId);
//		 assertNotNull(response);
//	 }
	 
	 @Test
	 void testGetStoresForStoreManager() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = 1l;
		 String xCountryCode = "";
		 Long userId = 1l;
		 Long storeId = 1l;
		 Long userIdForCashier = 1l;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		
		 Mockito.when(storeRepository.fetchStoresForAdminWithOutxCountryCode(paging)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
//	 @Test
//	 void testGetStoresNoAuth() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		
//		
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 
	 @Test
	 void testGetStoresForYesStoreManager() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = 1l;
		 String xCountryCode = "";
		 Long userId = 1l;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
			Mockito.when(userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole())).thenReturn(userId);
			Mockito.when(userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
		@Test
		void testGetStoresForNoStoreManager() {
			String searchStores = "";
			int page = 1;
			int size = 1;
			Long casUserId = 1l;
			String xCountryCode = "";
			Long userId = 1l;
			Long storeId = 1l;
			Long userIdForCashier = null;
			Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
			CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
			List<StoresParam> storeParamList = new ArrayList<>();
			StoresParam storeParam = new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l, "abc");
			storeParamList.add(storeParam);
			Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
			Pageable paging = PageRequest.of(page - 1, size);

			Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
					.thenReturn(userId);
			Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
					.thenReturn(userIdForCashier);
			Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeId);
			Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(stores);
			Mockito.when(storeRepository.findStoresForStoresManager(paging,
								storeId)).thenReturn(pagingRequest);
			ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores, page, size,
					casUser, xCountryCode, casUserId);
			assertNotNull(response);
		}
	
	 
//	 @Test
//	 void testGetStoresThrowExceptions() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "zmb";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenThrow(new RuntimeException());
//		
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	 
	 
//	 @Test
//	 void testGetStoresForCashier() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	 
//	 @Test
//	 void testGetStoresForStoreManagerThrowNotNull() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "zmb";
//		 Long userId = 1l;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 
//	 @Test
//	 void testGetStoresForAdmin() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(storeRepository.fetchStoresForAdminWithCasId(paging,xCountryCode,casUserId)).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	 
//	 @Test
//	 void testGetStoresForAdminForCasUserIdNull() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(storeRepository.fetchStoresForAdmin(paging,xCountryCode)).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 
	 
//	 @Test
//	 void testGetStoresForAdminXCountryCodeIsNull() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 

	 
//	 @Test
//	 void testGetStoresForAdminButSearchIsNotEmptyAndCasUserIdIsEmpty() {
//		 String searchStores = "ABC";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
//	 
//	 @Test
//	 void testGetStoresForAdminButSearchIsNotEmptyAndXcountryCodeIsEmpty() {
//		 String searchStores = "ABC";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(storeRepository.fetchStoresByFilterForAdminWithoutXcountryCode(searchStores, paging)).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	 
//	 @Test
//	 void testGetStoresForMerchantButSearchIsEmpty() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "Zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 Mockito.when(storeRepository.fetchStores(casUser.getCustomerID(),paging,xCountryCode )).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	
	 
	 @Test
	 void testGetStoresForMerchantButSearchIsEmptyAndXCountryCodeIsEmpty() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStoresWithoutXcountryCode(casUser.getCustomerID(),paging )).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 
//	 @Test
//	 void testGetStoresForMerchantButSearchIsNotEmpty() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 Mockito.when(storeRepository.fetchStoresByFilter(searchStores, casUser.getCustomerID(),paging,xCountryCode)).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	 
//	 @Test
//	 void testGetStoresForMerchantButSearchIsNotEmptyAndCountryCodeIsEmpty() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 Mockito.when(storeRepository.fetchStoresByFilterWithoutXcountryCode(searchStores, casUser.getCustomerID(),paging)).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }

//	 @Test
//	 void fetchStoresUnAuth() {
//		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
//		 Long userId = 1l;
//		 Long userIdForCashier = null;
//		 Long storeId = 1l;
//		 List<StoresParam> storeParamList = new ArrayList<>();
//		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
//		 storeParamList.add(storesParam);
//		
//		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList); 
//		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser);
//		assertNotNull(success);
//		
//	 }
//	 
	 
//	 @Test
//	 void fetchStoresForStoreManager() {
//		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 Long userId = 1l;
//		 Long userIdForCashier = null;
//		 Long storeId = 1l;
//		 List<StoresParam> storeParamList = new ArrayList<>();
//		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
//		 storeParamList.add(storesParam);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when( userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeId);
//		Mockito.when(storeRepository.findStoresForStoresManagerWithoutPagination(storeId)).thenReturn(storeParamList);
//		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList); 
//		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser);
//		assertNotNull(success);
//		
//	 }
	 
//	 @Test
//	 void fetchStoresForCashier() {
//		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 Long userId = null;
//		 Long userIdForCashier = 1l;
//		 Long storeId = 1l;
//		 List<StoresParam> storeParamList = new ArrayList<>();
//		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
//		 storeParamList.add(storesParam);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when( userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		SuccessResponse response =  new SuccessResponse(true, AppConstants.NOT_AUTHORIZED, AppConstants.PERMISSION_FAILED,
//				null); 
//		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser);
//		assertNotNull(success);
//		
//	 }
//	 
//	 @Test
//	 void fetchStoresForAdmin() {
//		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
//		 Long userId = null;
//		 Long userIdForCashier = null;
//		 Long storeId = 1l;
//		 List<StoresParam> storeParamList = new ArrayList<>();
//		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
//		 storeParamList.add(storesParam);
//
//		 Mockito.when(storeRepository.fetchStoresForAdminWithoutPagination()).thenReturn(storeParamList);
//		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList);
//		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser);
//		assertNotNull(success);
//		
//	 }
	 
//	 @Test
//	 void fetchStoresForMerchant() {
//		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 Long userId = null;
//		 Long userIdForCashier = null;
//		 Long storeId = 1l;
//		 List<StoresParam> storeParamList = new ArrayList<>();
//		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
//		 storeParamList.add(storesParam);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when( userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 Mockito.when(storeRepository.fetchStoresForCustomerWithoutPagination(casUser.getCustomerID())).thenReturn(storeParamList);
//		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList);
//		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser);
//		assertNotNull(success);
//		
//	 }
	 
//	 @Test
//	 void fetchStoresThrowMerchant() {
//		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 Long userId = null;
//
//	 void testGetStoresForCashier() {
//		 String searchStores = "abc";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = 1l;
//		 String xCountryCode = "zmb";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = 1l;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 assertThrows(PermissionException.class,
//	                () -> storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//	    					xCountryCode,casUserId));
//	 }
	 
	 @Test
	 void testGetStoresForStoreManagerThrowNotNull() {
		 String searchStores = "abc";
		 int page = 1;
		 int size = 1;
		 Long casUserId = 1l;
		 String xCountryCode = "zmb";
		
		 Long storeId = 1l;
				 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 
		Mockito.when(storeRepository.fetchStoresByFilterForAdminWithCasUserId(searchStores, paging, xCountryCode, casUserId)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForAdminWithFilter() {
		 String searchStores = "abc";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "zmb";
		
		 Long storeId = 1l;
				 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 
		Mockito.when(storeRepository
				.fetchStoresByFilterForAdmin(searchStores, paging, xCountryCode)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForAdminWithoutFilter() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "zmb";
		
		 Long storeId = 1l;
				 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 
		Mockito.when(storeRepository.fetchStoresForAdmin(paging, xCountryCode)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForAdmin() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = 1l;
		 String xCountryCode = "zmb";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(storeRepository.fetchStoresForAdminWithCasId(paging,xCountryCode,casUserId)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForAdminForCasUserIdNull() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "zmb";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStores(casUser.getCustomerID(), paging,
					xCountryCode)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 
	 @Test
	 void testGetStoresForAdminXCountryCodeIsNull() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);

		 assertThrows(NullPointerException.class,
	                () -> storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
	    					xCountryCode,casUserId));
	 }
	 

	 
	 @Test
	 void testGetStoresForAdminButSearchIsNotEmptyAndCasUserIdIsEmpty() {
		 String searchStores = "ABC";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "zmb";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStoresByFilter(searchStores,
					casUser.getCustomerID(), paging, xCountryCode)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForAdminButSearchIsNotEmptyAndXcountryCodeIsEmpty() {
		 String searchStores = "ABC";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(storeRepository.fetchStoresByFilterForAdminWithoutXcountryCode(searchStores, paging)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForMerchantButSearchIsEmpty() {
		 String searchStores = "";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "Zmb";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStores(casUser.getCustomerID(),paging,xCountryCode )).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	
	 
//	 @Test
//	 void testGetStoresForMerchantButSearchIsEmptyAndXCountryCodeIsEmpty() {
//		 String searchStores = "";
//		 int page = 1;
//		 int size = 1;
//		 Long casUserId = null;
//		 String xCountryCode = "";
//		 Long userId = null;
//		 Long storeId = 1l;
//		 Long userIdForCashier = null;
//		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1);
//		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
//		 List<StoresParam> storeParamList =  new ArrayList<>();
//		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
//		 storeParamList.add(storeParam);
//		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
//		 Pageable paging = PageRequest.of(page-1, size);
//		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
//		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
//		 Mockito.when(storeRepository.fetchStoresWithoutXcountryCode(casUser.getCustomerID(),paging )).thenReturn(pagingRequest);
//		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
//					xCountryCode,casUserId);
//		 assertNotNull(response);
//	 }
	 
	 
	 @Test
	 void testGetStoresForMerchantButSearchIsNotEmpty() {
		 String searchStores = "abc";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "zmb";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStoresByFilter(searchStores, casUser.getCustomerID(),paging,xCountryCode)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }
	 
	 @Test
	 void testGetStoresForMerchantButSearchIsNotEmptyAndCountryCodeIsEmpty() {
		 String searchStores = "abc";
		 int page = 1;
		 int size = 1;
		 Long casUserId = null;
		 String xCountryCode = "";
		 Long userId = null;
		 Long storeId = 1l;
		 Long userIdForCashier = null;
		 Stores stores = new Stores(1l, 1l, "abc", "abc", "abc", "AFG", "1234", "abc", 1,null);
		 CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 List<StoresParam> storeParamList =  new ArrayList<>();
		 StoresParam storeParam =  new StoresParam(1l, "abc", "abc", "abc", "abc", "abc", 1l,"abc");
		 storeParamList.add(storeParam);
		 Page<StoresParam> pagingRequest = new PageImpl(storeParamList);
		 Pageable paging = PageRequest.of(page-1, size);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when(userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStoresByFilterWithoutXcountryCode(searchStores, casUser.getCustomerID(),paging)).thenReturn(pagingRequest);
		 ResponseEntity<Object> response = storeServiceImpl.fetchStoresWithPagination(searchStores,page,size,casUser,
					xCountryCode,casUserId);
		 assertNotNull(response);
	 }

	 @Test
	 void fetchStoresUnAuth() {
		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		 Long userId = 1l;
		 Long userIdForCashier = null;
		 String xCountryCode ="ZMB";
		 Long storeId = 1l;
		 List<StoresParam> storeParamList = new ArrayList<>();
		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
		 storeParamList.add(storesParam);
		
		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList); 

		 assertThrows(PermissionException.class,
	                () ->storeServiceImpl.fetchStores(casUser,xCountryCode));
		
	 }
	 
	 
	 @Test
	 void fetchStoresForStoreManager() {
		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 String xCountryCode ="ZMB";
		 Long userId = 1l;
		 Long userIdForCashier = null;
		 Long storeId = 1l;
		 List<StoresParam> storeParamList = new ArrayList<>();
		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
		 storeParamList.add(storesParam);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when( userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(storeAssignmentRepository.findStoreId(userId)).thenReturn(storeId);
		Mockito.when(storeRepository.findStoresForStoresManagerWithoutPagination(storeId,xCountryCode)).thenReturn(storeParamList);
		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList); 
		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser,xCountryCode);
		assertNotNull(success);
		
	 }
	 
	 @Test
	 void fetchStoresForCashier() {
		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 String xCountryCode ="ZMB";
		 Long userId = null;
		 Long userIdForCashier = 1l;
		 Long storeId = 1l;
		 List<StoresParam> storeParamList = new ArrayList<>();
		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
		 storeParamList.add(storesParam);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when( userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 assertThrows(PermissionException.class,
	                () -> storeServiceImpl.fetchStores(casUser,xCountryCode));
		
	 }
	 
	 @Test
	 void fetchStoresForAdmin() {
		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		 Long userId = null;
		 String xCountryCode ="ZMB";
		 Long userIdForCashier = null;
		 Long storeId = 1l;
		 List<StoresParam> storeParamList = new ArrayList<>();
		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
		 storeParamList.add(storesParam);


		 Mockito.when(storeRepository.fetchStoresForAdminWithoutPagination(xCountryCode)).thenReturn(storeParamList);
		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList);
		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser,xCountryCode);
		assertNotNull(success);
		
	 }
	 
	 @Test
	 void fetchStoresForMerchant() {
		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 String xCountryCode ="ZMB";
		 Long userId = null;
		 Long userIdForCashier = null;
		 Long storeId = 1l;
		 List<StoresParam> storeParamList = new ArrayList<>();
		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
		 storeParamList.add(storesParam);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenReturn(userId);
		 Mockito.when( userRepository.findCashier(casUser.getUserID(),applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		 Mockito.when(storeRepository.fetchStoresForCustomerWithoutPagination(casUser.getCustomerID(),xCountryCode)).thenReturn(storeParamList);

		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList);
		ResponseEntity<Object> success =  storeServiceImpl.fetchStores(casUser,xCountryCode);
		assertNotNull(success);
		
	 }

	 
	 @Test
	 void fetchStoresThrowMerchant() {
		 CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		 Long userId = null;
		 String xCountryCode ="ZMB";
		 Long userIdForCashier = null;
		 Long storeId = 1l;
		 List<StoresParam> storeParamList = new ArrayList<>();
		 StoresParam storesParam  =  new StoresParam(1l, "abc", "abc", "address", "456879123", "AFG", 1l, "User");
		 storeParamList.add(storesParam);
		 Mockito.when(userRepository.findCasUser(casUser.getUserID(),applicationProperties.getStoreManagerRole())).thenThrow(new RuntimeException());
		
		SuccessResponse response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, storeParamList);
		 assertThrows(RuntimeException.class,
	                () -> storeServiceImpl.fetchStores(casUser,xCountryCode));
		
	 }

}
