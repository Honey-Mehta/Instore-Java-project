package com.cellulant.instore.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.instore.dto.DeviceIdDto;
import com.cellulant.instore.dto.UpdateCounterDto;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.CounterAssignment;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.model.Users;
import com.cellulant.instore.repository.CounterAssignmentRepository;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CountersDto;
import com.cellulant.instore.response.MerchantDetail;
import com.cellulant.instore.response.StoreCountersDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.itextpdf.text.DocumentException;

@ExtendWith(MockitoExtension.class)
class TestCounterServiceImpl {

	@InjectMocks
	private CounterServiceImpl counterServiceImpl;

	@Mock
	private CounterRepository counterRepository;

	@Mock
	private StoreRepository storeRepository;

	@Mock
	private UserRepository userRepository;

	@Mock
	private ApplicationProperties applicationProperties;

	@Mock
	private StoreAssignmentRepository storeAssignmentRepository;

	@Mock
	private CounterAssignmentRepository counterAssignmentRepository;

	@Mock
	private CounterCodesRepository counterCodesRepository;

	@Test
	void updateDeviceIdForAdmin() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
		deviceIdDto.setUserId(1l);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		Long counterCode = 1l;
		List<Users> userList = new ArrayList<>();
		Users user = new Users();
		user.setUserId(1l);
		user.setClientId(1l);
		userList.add(user);
		assertThrows(PermissionException.class, () -> counterServiceImpl.updateDeviceId(deviceIdDto, casUser));
	}

	@Test
	void updateDeviceId() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
		deviceIdDto.setUserId(1l);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long counterCode = 1l;
		List<Users> userList = new ArrayList<>();
		Users user = new Users();
		user.setUserId(1l);
		user.setClientId(1l);
		userList.add(user);

		Mockito.when(userRepository.findByUserId(deviceIdDto.getUserId())).thenReturn(userList);
		Mockito.when(counterRepository.findCounterCodeForSpecificClient(casUser.getCustomerID()))
				.thenReturn(counterCode);
		Mockito.when(counterRepository.updateDeviceIdOnCounters(deviceIdDto.getDeviceID(), counterCode)).thenReturn(1);
		ResponseEntity<Object> response = counterServiceImpl.updateDeviceId(deviceIdDto, casUser);
		assertNotNull(response);
		SuccessResponse successResponse = (SuccessResponse) response.getBody();
		assertEquals(AppConstants.SUCCESS_STATUS, successResponse.getStatusCode());
	}

	@Test
	void updateDeviceIdThrowInternalServer() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long counterCode = 1l;
		List<Users> userList = new ArrayList<>();
		Users user = new Users();
		user.setUserId(1l);
		user.setClientId(1l);
		userList.add(user);

		Mockito.when(userRepository.findByUserId(deviceIdDto.getUserId())).thenReturn(userList);
		Mockito.when(counterRepository.findCounterCodeForSpecificClient(deviceIdDto.getUserId()))
				.thenReturn(counterCode);
		Mockito.when(counterRepository.updateDeviceIdOnCounters(deviceIdDto.getDeviceID(), counterCode))
				.thenReturn(-11);
		ResponseEntity<Object> response = counterServiceImpl.updateDeviceId(deviceIdDto, casUser);
		assertNotNull(response);
		SuccessResponse successResponse = (SuccessResponse) response.getBody();

	}

	@Test
	void updateDeviceIdThrowUserListEmpty() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Integer counterCode = 1;
		List<Users> userList = new ArrayList<>();
		Mockito.when(userRepository.findByUserId(deviceIdDto.getUserId())).thenReturn(userList);
		assertThrows(NotFoundExceptions.class, () -> counterServiceImpl.updateDeviceId(deviceIdDto, casUser));

	}

	@Test
	void updateDeviceIdThrowCounterNotAssign() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long counterCode = null;
		List<Users> userList = new ArrayList<>();
		Users user = new Users();
		user.setUserId(1l);
		user.setClientId(1l);
		userList.add(user);

		Mockito.when(userRepository.findByUserId(deviceIdDto.getUserId())).thenReturn(userList);
		Mockito.when(counterRepository.findCounterCodeForSpecificClient(deviceIdDto.getUserId()))
				.thenReturn(counterCode);

		assertThrows(NotFoundExceptions.class, () -> counterServiceImpl.updateDeviceId(deviceIdDto, casUser));

	}

	@Test
	void updateDeviceIdFailedToUpdate() {
		DeviceIdDto deviceIdDto = new DeviceIdDto();
		deviceIdDto.setDeviceID("nzmgfhgsdhmnjhsgdjhs");
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long counterCode = 2l;
		List<Users> userList = new ArrayList<>();
		Users user = new Users();
		user.setUserId(1l);
		user.setClientId(1l);
		userList.add(user);

		Mockito.when(userRepository.findByUserId(deviceIdDto.getUserId())).thenReturn(userList);
		Mockito.when(counterRepository.findCounterCodeForSpecificClient(deviceIdDto.getUserId()))
				.thenReturn(counterCode);
		Mockito.when(counterRepository.updateDeviceIdOnCounters(deviceIdDto.getDeviceID(), counterCode))
				.thenReturn(-11);
		ResponseEntity<Object> response = counterServiceImpl.updateDeviceId(deviceIdDto, casUser);
		assertNotNull(response);
		SuccessResponse successResponse = (SuccessResponse) response.getBody();
		assertEquals(AppConstants.BAD_REQUEST_STATUS_CODE, successResponse.getStatusCode());

	}

	@Test
	void testUpdateCounterForAdmin() {
		String country ="KEN";
		String counterCode = "1l";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();

		assertThrows(NullPointerException.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void testUpdateCounterUnAuth() {
		String country ="KEN";
		String counterCode = "1l";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();

		assertThrows(PermissionException.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void testUpdateCounterForCashier() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class, () -> counterServiceImpl.updateCounter(counterDto, casUser, counter));

	}

	@Test
	void testUpdateCounterForStoreManager() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;
	
		Stores stores = new Stores(checkingStoreId, checkingStoreId, null, null, null, null, null, null, null, null);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(stores);
		Mockito.when(counterRepository.findCounterOnTheBasisOfStoreId(stores.getStoreId(), counter.getCounterId()))
				.thenReturn(counter);
		assertDoesNotThrow( () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void testUpdateCounterForStoreManagerNoSuccess() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;
		Stores stores = new Stores(checkingStoreId, checkingStoreId, null, null, null, null, null, null, null, null);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(stores);

		assertThrows( PermissionException.class,() -> counterServiceImpl.updateCounter(counterDto, casUser,counter));


	}

	@Test
	void testUpdateCounterForStoreManagerNoFound() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(null);
		assertThrows(NotFoundExceptions.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void testUpdateCounterThrow() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();

		assertThrows(PermissionException.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	 @Test
	void testUpdateCounterthrowError() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		int updateValue = 1;
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(counters.getStoreId(), casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterRepository.findByCounterNameAndCounterId(counterDto.getCounterName(), counters.getStoreId(),
				counter.getCounterId())).thenThrow(new RuntimeException());

		assertThrows(RuntimeException.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void testUpdateCounter() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		int updateValue = 1;
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(counters.getStoreId(), casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterRepository.findByCounterNameAndCounterId(counterDto.getCounterName(), counters.getStoreId(),
				counter.getCounterId())).thenReturn(counterList);
		Mockito.when(counterRepository.findByMsisdnAndCounterId(counterDto.getMsisdn(), counters.getStoreId(),
				counter.getCounterId())).thenReturn(counterPhoneList);
		Mockito.when(counterRepository.updateCounters(counterDto.getCounterName(), counter.getCounterId(),
				counterDto.getMsisdn(),
				(counterDto.getIsReference()).equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO))
				.thenReturn(updateValue);
		ResponseEntity<Object> response = counterServiceImpl.updateCounter(counterDto, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testUpdateCounterNotUpdated() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", "yes");
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		counters.setStoreId(1l);
		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		int updateValue = -1;
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
	
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(counters.getStoreId(), casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterRepository.findByCounterNameAndCounterId(counterDto.getCounterName(), counters.getStoreId(),
				counter.getCounterId())).thenReturn(counterList);
		Mockito.when(counterRepository.findByMsisdnAndCounterId(counterDto.getMsisdn(), counters.getStoreId(),
				counter.getCounterId())).thenReturn(counterPhoneList);
		Mockito.when(counterRepository.updateCounters(counterDto.getCounterName(), counter.getCounterId(),
				counterDto.getMsisdn(),
				(counterDto.getIsReference()).equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO))
				.thenReturn(updateValue);
		ResponseEntity<Object> response = counterServiceImpl.updateCounter(counterDto, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testUpdateCounterThrowCounterNameAlreadyExist() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", null);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		List<CountersDto> counterList = new ArrayList<>();
		counterList.add(counters);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(counter.getStoreId(),
				casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterRepository.findByCounterNameAndCounterId(
				counterDto.getCounterName(), counter.getStoreId(), counter.getCounterId())).thenReturn(counterList);
		assertThrows(AlreadyExistExceptions.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void testUpdateCounterThrowPhoneNumberAlreadyExist() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(2155l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", null);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1234l");
		counters.setCounterName("aim");
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Stores store = new Stores(1l, 2155l, "bav", null, null, null, null, null, 1, null);

		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		counterPhoneList.add(counters);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(counter.getStoreId(),
				casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterRepository.findByCounterNameAndCounterId(
				counterDto.getCounterName(), counter.getStoreId(), counter.getCounterId())).thenReturn(counterList);
		
		Mockito.when(counterRepository.findByMsisdnAndCounterId(counterDto.getMsisdn(),
				counter.getStoreId(), counter.getCounterId())).thenReturn(counterPhoneList);
		assertThrows(AlreadyExistExceptions.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));
	}

	@Test
	void testUpdateCounterThrowInternalServer() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		UpdateCounterDto counterDto = new UpdateCounterDto("1l", "abc", "abc", null);
		CountersDto counters = new CountersDto();
		counters.setCounterCode("1");
		counters.setCounterName("aim");
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);

		List<CountersDto> counterList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		counterPhoneList.add(counters);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class, () -> counterServiceImpl.updateCounter(counterDto, casUser,counter));

	}

	@Test
	void fetchCounterByIdWithCounterAssignment() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(12l))
				.thenReturn(counterAssignmentList);
		ResponseEntity<Object> response = counterServiceImpl.fetchCounterById(counterCode, casUser,counter);
		assertNotNull(response);
	}

	@Test
	void fetchCounterById() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCounterById(counterCode, casUser,counter));
	}

	@Test
	void fetchCounterByIdForCustomer() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Stores store = new Stores(1l, 1l, "storeName", "abc", "abc", "ndh", null, null, null, null);

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(counterAssignmentList);
		ResponseEntity<Object> response = counterServiceImpl.fetchCounterById(counterCode, casUser,counter);
		assertNotNull(response);
	}

	@Test
	void fetchCounterByIdForCashier() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		Stores store = new Stores(1l, 1l, "storeName", "abc", "abc", "ndh", null, null, null, null);

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCounterById(counterCode, casUser,counter));
	}

	@Test
	void fetchCounterByIdForStoreManager() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		
		Stores store = new Stores(1l, 1l, "storeName", "abc", "abc", "ndh", null, null, 1, null);
		Long checkingStoreId = 1l;

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(store);
		Mockito.when(counterRepository.findCounterOnTheBasisOfStoreId(store.getStoreId(), counter.getCounterId()))
				.thenReturn(counter);

		assertDoesNotThrow(() -> counterServiceImpl.fetchCounterById(counterCode, casUser,counter));
	}

	//@Test
	void fetchCounterByIdForStoreManagerUnAuth() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counters = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Counters counter = null;
		Stores store = new Stores(1l, 1l, "storeName", "abc", "abc", "ndh", null, null, 1, null);
		Long checkingStoreId = 1l;

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(store);
		Mockito.when(counterRepository.findCounterOnTheBasisOfStoreId(store.getStoreId(), counters.getCounterId()))
				.thenReturn(counters);

		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCounterById(counterCode, casUser,counter));
	}

	@Test
	void fetchCounterByIdForStoreManagerNoStore() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counters = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Counters counter = null;
		Stores store = null;
		Long checkingStoreId = 1l;

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(store);
		assertThrows(NotFoundExceptions.class, () -> counterServiceImpl.fetchCounterById(counterCode, casUser,counters));
	}

	@Test
	void fetchCounterByIdForCustomerUnAuth() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counters = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		Stores store = null;

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(store);

		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCounterById(counterCode, casUser,counters));
	}

	 @Test
	void fetchCounterByIdWithoutCounterAssignment() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counters = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		Stores store = new Stores(1l, 1l, "abc", "abc", null, null, null, null, 1, null);

	
		Mockito.when(storeRepository.findStoreById(countersDto.getStoreId())).thenReturn(store);
		ResponseEntity<Object> response = counterServiceImpl.fetchCounterById(counterCode, casUser,counters);
		assertNotNull(response);
	}



	@Test
	void fetchCounterByIdthroWInternalServerError() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counters = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		CountersDto countersDto = null;
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		Stores store = new Stores(1l, 1l, "abc", "abc", null, null, null, null, 1, null);
		assertDoesNotThrow(() -> counterServiceImpl.fetchCounterById(counterCode, casUser,counters));
	}

	@Test
	void fetchCounterByIdThrowRuntimeExceptions() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counters = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CountersDto countersDto = null;
		assertThrows(NullPointerException.class, () -> counterServiceImpl.fetchCounterById(counterCode, null,counters));
	}

	@Test
	void testDeleteCounterApi() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(counterAssignmentList);
		Mockito.when(counterAssignmentRepository.updateCounterAssignmnet(counter.getCounterId())).thenReturn(1);
		Mockito.when(counterRepository.updateCountersActive(counter.getCounterId())).thenReturn(1);
		ResponseEntity<Object> response = counterServiceImpl.deleteCounter(counterCode, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testDeleteCounterApiException() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);

		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(counterAssignmentList);
		Mockito.when(counterAssignmentRepository.updateCounterAssignmnet(counter.getCounterId()))
				.thenThrow(new RuntimeException());

		assertThrows(RuntimeException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser,counter));

	}

	@Test
	void testDeleteCounterApiForMerchant() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);

		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(null);
		Mockito.when(counterRepository.updateCountersActive(counter.getCounterId())).thenReturn(1);

		ResponseEntity<Object> response = counterServiceImpl.deleteCounter(counterCode, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testDeleteCounterApiForMerchantNotUpdate() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
	
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(null);
		Mockito.when(counterRepository.updateCountersActive(counter.getCounterId())).thenReturn(-1);

		ResponseEntity<Object> response = counterServiceImpl.deleteCounter(counterCode, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testDeleteCounterApiForMerchantUnAuth() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(null);

		assertThrows(PermissionException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser,counter));

	}

	@Test
	void testDeleteCounterApiForStoreManager() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(
				new Stores(checkingStoreId, checkingStoreId, null, null, null, null, null, null, null, null));

		assertThrows(PermissionException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser, counter));

	}

	@Test
	void testDeleteCounterApiForStoreManagerUnAuth() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(
				new Stores(checkingStoreId, checkingStoreId, null, null, null, null, null, null, null, null));
		Mockito.when(counterRepository.findCounterOnTheBasisOfStoreId(1l, counter.getCounterId())).thenReturn(
				counter);
		ResponseEntity<Object> response = counterServiceImpl.deleteCounter(counterCode, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testDeleteCounterApiForStoreManagerNot() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(null);
		assertThrows(NotFoundExceptions.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser,counter));

	}

	@Test
	void testDeleteCounterApiNot() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(counterAssignmentList);
		Mockito.when(counterAssignmentRepository.updateCounterAssignmnet(counter.getCounterId())).thenReturn(-1);
		ResponseEntity<Object> response = counterServiceImpl.deleteCounter(counterCode, casUser,counter);
		assertNotNull(response);

	}

	@Test
	void testDeleteCounterApiThrowServer() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenThrow(new RuntimeException());
		assertThrows(RuntimeException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser,counter));

	}

	@Test
	void testDeleteCounterApiNotNN() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;

		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(countersDto.getStoreId(), casUser.getCustomerID()))
				.thenReturn(new Stores(userIdForStoreManager, userIdForStoreManager, null, null, null, null, null, null,
						null, null));
		Mockito.when(counterAssignmentRepository.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId()))
				.thenReturn(counterAssignmentList);
		Mockito.when(counterAssignmentRepository.updateCounterAssignmnet(counter.getCounterId())).thenReturn(1);
		Mockito.when(counterRepository.updateCountersActive(counter.getCounterId())).thenReturn(-1);
		ResponseEntity<Object> response = counterServiceImpl.deleteCounter(counterCode, casUser, counter);
		assertNotNull(response);

	}

	@Test
	void testDeleteCounterApiForAdmin() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);

		assertThrows(PermissionException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser, counter));

	}

	@Test
	void testDeleteCounterApiFor() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		assertThrows(PermissionException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser,counter));

	}

	@Test
	void testDeleteCounterApiForCashier() {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();

		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setStoreId(1l);
		List<CounterAssignment> counterAssignmentList = new ArrayList<>();
		CounterAssignment counterAssignment = new CounterAssignment();
		counterAssignment.setCounterAssignmentId(1l);
		counterAssignment.setUserId(1l);
		counterAssignment.setCounterId(1l);
		counterAssignmentList.add(counterAssignment);
		Long userIdForCashier = 1l;
		;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class, () -> counterServiceImpl.deleteCounter(counterCode, casUser,counter));

	}

	@Test
	void testGetCounters() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		counterList.add(countersDto);
		Mockito.when(counterRepository.findAllCountersForAdmin()).thenReturn(counterList);
		ResponseEntity<Object> response = counterServiceImpl.getCounters(casUser);
		assertNotNull(response);
	}

	@Test
	void testGetCountersNotAdminNotCustomer() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		counterList.add(countersDto);
		assertThrows(PermissionException.class, () -> counterServiceImpl.getCounters(casUser));
	}

	@Test
	void testGetCountersForCustomer() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		counterList.add(countersDto);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(counterRepository.findAllCounters(casUser.getCustomerID())).thenReturn(counterList);
		ResponseEntity<Object> response = counterServiceImpl.getCounters(casUser);
		assertNotNull(response);
	}

	@Test
	void testGetCountersForCashier() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		counterList.add(countersDto);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class, () -> counterServiceImpl.getCounters(casUser));
	}

	@Test
	void testGetCountersForStoreManager() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		counterList.add(countersDto);
		Long storeId = 1l;
		Stores stores = new Stores(1l, 1l, "java", null, null, null, null, null, 1, null);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(storeId);
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(stores);
		ResponseEntity<Object> response = counterServiceImpl.getCounters(casUser);
		assertNotNull(response);
	}

	 @Test
	void testGetCountersForStoreManagerThrow() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		List<CountersDto> counterList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		counterList.add(countersDto);
		Long storeId = 1l;
		Stores stores = new Stores(1l, 1l, "java", null, null, null, null, null, 1, null);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(storeId);
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(null);
		assertThrows(NotFoundExceptions.class, () -> counterServiceImpl.getCounters(casUser));
	}

	@Test
	void testFindCounters() throws PermissionException, IOException, DocumentException {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String searchCounters = "abc";
		Long storeId = 1l;
		 int page=1; 
		 int size=1;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		StoreCountersDto storeCountersDto =  new StoreCountersDto(1l,"abc", "abc", "abc", "abc", "1l", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(counterRepository.fetchCounterByFilterForAdmin(storeId,searchCounters, pagingRequest)).thenReturn(paging);
		Mockito.when(counterRepository.findCounterById(storeCountersDto.getCounterId())).thenReturn(counter);
		Mockito.when( storeRepository.findStoreById(counter.getStoreId())).thenReturn(store);
		ResponseEntity<Object> response = counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser);
		assertNotNull(response);
		
	}

	@Test
	void testFindCountersUnAuth() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		String searchCounters = "abc";
		Long storeId = 1l;
		int page = 1;
		int size = 1;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto = new StoreCountersDto(1l, "abc", "abc", "abc", "abc", "1", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		assertThrows(PermissionException.class,
				() -> counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser));

	}

	@Test
	void testFindCountersForStoreManager() throws PermissionException, IOException, DocumentException {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "";
		Long storeId = 1l;
		 int page=1; 
		 int size=1;
		 Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto =  new StoreCountersDto(1l,"abc", "abc", "abc", "abc", "1l", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when( storeRepository.findStoreById(checkingStoreId)).thenReturn(store);
		Mockito.when(counterRepository.findByCountersStoreId( pagingRequest,storeId, casUser.getCustomerID())).thenReturn(paging);
	Mockito.when(counterRepository.findCounterById(storeCountersDto.getCounterId())).thenReturn(counter);
		ResponseEntity<Object> response = counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser);
		assertNotNull(response);
		
	}

	@Test
	void testFindCountersForStoreManagerWithFilter() throws PermissionException, IOException, DocumentException {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		Stores stores = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "abh";
		Long storeId = 1l;
		 int page=1; 
		 int size=1;
		 Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;
		
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto =  new StoreCountersDto(1l,"abc", "abc", "abc", "abc", "1l", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when( storeRepository.findStoreById(checkingStoreId)).thenReturn(stores);
		Mockito.when(counterRepository.fetchCounterByFilter(storeId, searchCounters, casUser.getCustomerID(), pagingRequest)).thenReturn(paging);
		Mockito.when(counterRepository.findCounterById(storeCountersDto.getCounterId())).thenReturn(counter);
		Mockito.when( storeRepository.findStoreById(counter.getStoreId())).thenReturn(stores);
		ResponseEntity<Object> response = counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser);
		assertNotNull(response);
		
	}

	@Test
	void testFindCountersForStoreManagerUnAuth() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "abh";
		Long storeId = 1l;
		int page = 1;
		int size = 1;
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;
		Stores stores = new Stores(5l, checkingStoreId, searchCounters, searchCounters, searchCounters, searchCounters,
				searchCounters, searchCounters, null, null);
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto = new StoreCountersDto(1l, "abc", "abc", "abc", "abc", "1", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(stores);
		assertThrows(PermissionException.class,
				() -> counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser));

	}

	@Test
	void testFindCountersForStoreManagerStoreNotFound() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "abh";
		Long storeId = 1l;
		int page = 1;
		int size = 1;
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		Long checkingStoreId = 1l;
		Stores stores = null;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto = new StoreCountersDto(1l, "abc", "abc", "abc", "abc", "1", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(checkingStoreId);
		Mockito.when(storeRepository.findStoreById(checkingStoreId)).thenReturn(stores);

		assertThrows(NotFoundExceptions.class,
				() -> counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser));

	}

	@Test
	void testFindCountersForAdmin() throws PermissionException, IOException, DocumentException {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		Stores store = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String searchCounters = "";
		Long storeId = 1l;
		 int page=1; 
		 int size=1;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto =  new StoreCountersDto(1l,"abc", "abc", "abc", "abc", "1l", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(counterRepository.findByCountersStoreIdForAdmin(storeId, pagingRequest)).thenReturn(paging);
		Mockito.when(counterRepository.findCounterById(storeCountersDto.getCounterId())).thenReturn(counter);
		Mockito.when( storeRepository.findStoreById(counter.getStoreId())).thenReturn(store);
		ResponseEntity<Object> response = counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser);
		assertNotNull(response);
		
	}

	@Test
	void testFindCountersForCashier() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "";
		Long storeId = 1l;
		int page = 1;
		int size = 1;
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto = new StoreCountersDto(1l, "abc", "abc", "abc", "abc", "1", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);

		assertThrows(PermissionException.class,
				() -> counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser));

	}

	@Test
	void testFindCountersForMerchant() throws PermissionException, IOException, DocumentException {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		Stores stores = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "";
		Long storeId = 1l;
		 int page=1; 
		 int size=1;
		 Long userIdForCashier = null;
			Long userIdForStoreManager = null;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto =  new StoreCountersDto(1l,"abc", "abc", "abc", "abc", "1l", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
	   Mockito.when(counterRepository.findByCountersStoreId( pagingRequest,storeId, casUser.getCustomerID())).thenReturn(paging);
	   Mockito.when(counterRepository.findCounterById(storeCountersDto.getCounterId())).thenReturn(counter);
		Mockito.when( storeRepository.findStoreById(counter.getStoreId())).thenReturn(stores);
	   ResponseEntity<Object> response = counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser);
		assertNotNull(response);
		
	}
	
	@Test
	void testFindCountersForMerchantWithFilter() throws PermissionException, IOException, DocumentException {
		String country ="KEN";
		String counterCode = "1l";
		Counters counter = new Counters(12l, 1234l, country, counterCode, 1, country, null, 1l, counterCode, country);
		Stores stores = new Stores(1l, 1l, "bav", null, null, null, null, null, 1, null);
		CASUser casUser =  CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String searchCounters = "avc";
		Long storeId = 1l;
		 int page=1; 
		 int size=1;
		 Long userIdForCashier = null;
			Long userIdForStoreManager = null;
		List<StoreCountersDto> storeCountersDtoList = new ArrayList<>();
		StoreCountersDto storeCountersDto =  new StoreCountersDto(1l,"abc", "abc", "abc", "abc", "1l", null);
		storeCountersDtoList.add(storeCountersDto);
		Page<StoreCountersDto> paging = new PageImpl(storeCountersDtoList);
		Pageable pagingRequest = PageRequest.of(page - 1, size);
		Mockito.when(userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole())).thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole())).thenReturn(userIdForStoreManager);
	   Mockito.when(counterRepository.fetchCounterByFilter(storeId, searchCounters, casUser.getCustomerID(), pagingRequest)).thenReturn(paging);
	   Mockito.when(counterRepository.findCounterById(storeCountersDto.getCounterId())).thenReturn(counter);
		Mockito.when( storeRepository.findStoreById(counter.getStoreId())).thenReturn(stores);
	   ResponseEntity<Object> response = counterServiceImpl.findCountersByStoreId(storeId, searchCounters, page, size, casUser);
		assertNotNull(response);
		
	}

	@Test
	void fetchCashierDetail() {

		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String role = "store-cashier";
		role = role.replaceAll("\\s", "");
		MerchantDetail merchantDetail = new MerchantDetail("store", "counter", "1", 1l, "address", 1l, null, "ZMB");
		Mockito.when(applicationProperties.getCashierRoleName()).thenReturn(role);
		Mockito.when(userRepository.findCashierInfo(casUser.getUserID())).thenReturn(merchantDetail);
		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
				merchantDetail);
		ResponseEntity<Object> success = counterServiceImpl.fetchCashierDetail(role, casUser);
		assertNotNull(success);
	}

	@Test
	void fetchCashierDetailRoleNotmatch() {

		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String role = "cashier";
		MerchantDetail merchantDetail = new MerchantDetail("store", "counter", "1", 1l, "address", 1l, null, "ZMB");
		Mockito.when(applicationProperties.getCashierRoleName()).thenReturn("abcbsvdf");
		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCashierDetail(role, casUser));
	}

	@Test
	void fetchCashierDetailUnAuthorize() {

		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String role = "cashier";

		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCashierDetail(role, casUser));
	}

	@Test
	void fetchCashierDetailThrowExceptions() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String role = "store-cashier";

		MerchantDetail merchantDetail = new MerchantDetail("store", "counter", "1", 1l, "address", 1l, null, "ZMB");
		Mockito.when(applicationProperties.getCashierRoleName()).thenReturn(role);
		Mockito.when(userRepository.findCashierInfo(casUser.getUserID()))
				.thenThrow(new PermissionException(AppConstants.PERMISSION_FAILED));
		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
				merchantDetail);

		assertThrows(PermissionException.class, () -> counterServiceImpl.fetchCashierDetail(role, casUser));

	}
}
