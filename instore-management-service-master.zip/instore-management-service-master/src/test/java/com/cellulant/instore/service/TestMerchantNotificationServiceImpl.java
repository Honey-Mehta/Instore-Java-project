package com.cellulant.instore.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.MerchantNotification;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.MerchantNotificationRepository;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;

import javassist.NotFoundException;

@ExtendWith(MockitoExtension.class)
class TestMerchantNotificationServiceImpl {

	@InjectMocks
	private MerchantServiceImpl merchantServiceImpl;

	@Mock
	private CounterRepository counterRepository;

	@Mock
	private MerchantNotificationRepository merchantNotificationRepository;

	@Mock
	private com.cellulant.instore.repository.StoreRepository storeRepository;

	@Mock
	private UserRepository userRepository;

	@Mock
	private StoreAssignmentRepository storeAssignmentRepository;

	@Mock
	private ApplicationProperties applicationProperties;

	// @Test
	void testGetMerchantDetailByCounterCode() throws NotFoundException {
		String counterCode = "50";
		String xCountry ="KEN";
		Counters counter = new Counters();
		counter.setActive(1);
		counter.setCounterCode(1234l);
		counter.setCounterId(1l);
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,xCountry)).thenReturn(counter);
		ResponseEntity<Object> response = merchantServiceImpl.getMerchantDetailByCounterCode(counterCode,xCountry);
		assertNotNull(response);
		SuccessResponse success = (SuccessResponse) response.getBody();
		assertEquals(AppConstants.SUCCESS_STATUS, success.getStatusCode());
	}

	// @Test
	void testGetMerchantDetailByCounterCodeThrowNotFound() throws NotFoundException {
		String counterCode = "50";
		Counters counter = null;
		String xCountry = "KEN";
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,xCountry)).thenReturn(counter);
		assertThrows(NotFoundExceptions.class, () -> merchantServiceImpl.getMerchantDetailByCounterCode(counterCode,xCountry));
	}

	@Test
	void testGetMerchantDetailByCounterCodeThrowServerError() throws NotFoundException {
		String counterCode ="50";
		Counters counter = null;
		String xCountryCode = "KEN";
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,xCountryCode)).thenThrow(NotFoundExceptions.class);

		assertThrows(NotFoundExceptions.class, () -> merchantServiceImpl.getMerchantDetailByCounterCode(counterCode,xCountryCode));

	}

	@Test
	void testGetMerchantDetailOnTheBasisOfClientId() throws NotFoundException {
		Long clientId = 2l;

		List<MerchantNotification> merchantNotificationList = new ArrayList<>();
		MerchantNotification merChanNotification = new MerchantNotification();
		merChanNotification.setMerchantNotificationId(1l);
		merchantNotificationList.add(merChanNotification);
		Mockito.when(merchantNotificationRepository.findByClientId(clientId)).thenReturn(merchantNotificationList);
		ResponseEntity<Object> response = merchantServiceImpl.getMerchantDetailOnTheBasisOfClientId(clientId);
		assertNotNull(response);
	}

	@Test
	void testGetMerchantDetailOnTheBasisOfClientIdThrowEmptyList() throws NotFoundException {
		Long clientId = 2l;

		List<MerchantNotification> merchantNotificationList = new ArrayList<>();
		Mockito.when(merchantNotificationRepository.findByClientId(clientId)).thenReturn(merchantNotificationList);

		assertThrows(NotFoundExceptions.class,
				() -> merchantServiceImpl.getMerchantDetailOnTheBasisOfClientId(clientId));
	}

	@Test
	void testGetMerchantDetailOnTheBasisOfClientIdThrowExceptions() throws NotFoundException {
		Long clientId = 2l;

		List<MerchantNotification> merchantNotificationList = new ArrayList<>();
		Mockito.when(merchantNotificationRepository.findByClientId(clientId)).thenThrow(NotFoundExceptions.class);
		assertThrows(NotFoundExceptions.class,
				() -> merchantServiceImpl.getMerchantDetailOnTheBasisOfClientId(clientId));
	}

	@Test
	void testGetTotalCashierAndCounterOnTheBasisOfStoreId() throws NotFoundException {
		Long storeId = 1l;
		List<Stores> storeList = new ArrayList<>();
		Stores stores = new Stores();
		stores.setStoreId(1l);
		storeList.add(stores);
		Long counter_count = 1l;
		Long cashier_count = 3l;
		Mockito.when(storeRepository.findByStoreId(storeId)).thenReturn(storeList);
		Mockito.when(storeRepository.totalCounters(storeId)).thenReturn(counter_count);
		Mockito.when(storeRepository.totalCashierOfCounter(storeId)).thenReturn(cashier_count);
		ResponseEntity<Object> response = merchantServiceImpl.getTotalCashierAndCounterOnTheBasisOfStoreId(storeId);
		assertNotNull(response);
	}

	@Test
	void testGetTotalCashierAndCounterOnTheBasisOfStoreIdThrowStorNotFoundExceptions() throws NotFoundExceptions {
		Long storeId = 1l;
		List<Stores> storeList = new ArrayList<>();
		Stores stores = new Stores();
		Mockito.when(storeRepository.findByStoreId(storeId)).thenReturn(storeList);

		assertThrows(NotFoundExceptions.class,
				() -> merchantServiceImpl.getTotalCashierAndCounterOnTheBasisOfStoreId(storeId));
	}

	@Test
	void testGetTotalCashierAndCounterOnTheBasisOfStoreIdThrowRuntimeExceptions() throws NotFoundException {
		Long storeId = 1l;
		List<Stores> storeList = new ArrayList<>();
		Stores stores = new Stores();
		Mockito.when(storeRepository.findByStoreId(storeId)).thenThrow(NotFoundExceptions.class);

		assertThrows(NotFoundExceptions.class,
				() -> merchantServiceImpl.getTotalCashierAndCounterOnTheBasisOfStoreId(storeId));
	}

	@Test
	void testGetTotalCounterAndStoresofParticaularClient() {
		Long customerId = 1l;
		String xCountryCode = "zmb";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		Long storeCountForAdmin = 1l;
		Long counterCountForAdmin = 1l;
		Long userIdForStoreManager = null;
		Long userIdForCashier = null;
		assertThrows(PermissionException.class, () -> merchantServiceImpl
				.getTotalCounterAndStoresofParticaularClient(customerId, casUser, xCountryCode));
	}

	@Test
	void testGetTotalCounterAndStoresForStoreManager() {
		Long customerId = 1l;
		String xCountryCode = "zmb";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		Long storeCountForAdmin = 1l;
		Long counterCountForAdmin = 1l;
		Long userIdForStoreManager = 1l;
		Long userIdForCashier = null;
		Long storeId = 1l;
		ResponseEntity<Object> response = merchantServiceImpl.getTotalCounterAndStoresofParticaularClient(customerId,
				casUser, xCountryCode);
		assertNotNull(response);
	}

	@Test
	void testGetTotalCounterAndStoresForStoreManagerWithOutExceptions() {
		Long customerId = 1l;
		String xCountryCode = "zmb";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Stores stores = new Stores();
		stores.setStoreId(1l);
		stores.setStoreName("store");
		Long storeCountForAdmin = 1l;
		Long counterCountForAdmin = 1l;
		Long userIdForStoreManager = 1l;
		Long userIdForCashier = null;
		Long storeId = 1l;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(storeId);
		Mockito.when(storeRepository.findStoreById(storeId)).thenReturn(stores);
		ResponseEntity<Object> response = merchantServiceImpl.getTotalCounterAndStoresofParticaularClient(customerId,
				casUser, xCountryCode);
		assertNotNull(response);
	}

	@Test
	void testGetTotalCounterAndStoresForCashier() {
		Long customerId = 1l;
		String xCountryCode = "zmb";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long storeCountForAdmin = 1l;
		Long counterCountForAdmin = 1l;
		Long userIdForStoreManager = null;
		Long userIdForCashier = 1l;
		Long storeId = 1l;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class, () -> merchantServiceImpl
				.getTotalCounterAndStoresofParticaularClient(customerId, casUser, xCountryCode));
	}

	@Test
	void testGetTotalCounterAndStoresofParticaularClientForCustomer() {
		Long customerId = 1l;
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long storeCount = 1l;
		Long counterCount = 1l;
		Long userIdForStoreManager = null;
		Long userIdForCashier = null;
		String xCountryCode = "zmb";
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(merchantNotificationRepository.totalStoreForCustomer(customerId, xCountryCode))
				.thenReturn(storeCount);
		Mockito.when(merchantNotificationRepository.totalCountersForCustomer(customerId, xCountryCode))
				.thenReturn(counterCount);
		ResponseEntity<Object> response = merchantServiceImpl.getTotalCounterAndStoresofParticaularClient(customerId,
				casUser, xCountryCode);
		assertNotNull(response);
	}

	@Test
	void testGetTotalCounterAndStoresofParticaularClientThrowExceptions() {
		Long customerId = 1l;
		String xCountryCode = "zmb";
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		Long storeCount = 1l;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(storeCount);

		assertThrows(NotFoundExceptions.class, () -> merchantServiceImpl
				.getTotalCounterAndStoresofParticaularClient(customerId, casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForAdmin() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = 1l;
		String xCountryCode = "KEN";
		Stores store = new Stores();
		store.setStoreId(1l);
		Mockito.when(storeRepository.findStoreById(storeID)).thenReturn(store);
		assertThrows(PermissionException.class, () -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email,
				page, size, storeID, casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForAdminStoreIDNotFound() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = 1l;
		String xCountryCode = "KEN";
		Mockito.when(storeRepository.findStoreById(storeID)).thenReturn(null);
		assertThrows(NotFoundExceptions.class, () -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email, page,
				size, storeID, casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForStoreManager() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = 1l;
		String xCountryCode = "KEN";
		Stores store = new Stores();
		store.setStoreId(1l);
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		List<Long> counterList = new ArrayList<>();
		counterList.add(79l);
		Mockito.when(applicationProperties.getStoreManagerRole()).thenReturn(16);
		Mockito.when(applicationProperties.getCashierRole()).thenReturn(15);
		Mockito.when(storeRepository.findStoreById(storeID)).thenReturn(store);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getStoreManagerRole(), email)).thenReturn(userIdForStoreManager);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getCashierRole(), email)).thenReturn(userIdForCashier);

		Mockito.when(storeAssignmentRepository.findStoreId(userIdForStoreManager)).thenReturn(storeID);
		Mockito.when(counterRepository.findcounterIdListByStoreId(storeID)).thenReturn(counterList);
		Pageable paging = PageRequest.of(page - 1, size, Sort.by("merchantNotificationId").descending());
		List<MerchantNotification> merchantNotificationList = new ArrayList();
		MerchantNotification merchantNotification = new MerchantNotification();
		merchantNotification.setMerchantNotificationId(1l);
		merchantNotificationList.add(merchantNotification);
		Page<MerchantNotification> pageResponse = new PageImpl(merchantNotificationList);

		Mockito.when(merchantNotificationRepository.findNotificationForMerchantOnTheBasisOfClientAndCountryCode(
				casUser.getCustomerID(), paging, counterList)).thenReturn(pageResponse);
		assertDoesNotThrow(() -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email, page, size, storeID,
				casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForCashier() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = 1l;
		String xCountryCode = "KEN";
		Stores store = new Stores();
		store.setStoreId(1l);
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		List<Long> counterList = new ArrayList<>();
		counterList.add(79l);
		Mockito.when(applicationProperties.getStoreManagerRole()).thenReturn(16);
		Mockito.when(applicationProperties.getCashierRole()).thenReturn(15);
		Mockito.when(storeRepository.findStoreById(storeID)).thenReturn(store);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getStoreManagerRole(), email)).thenReturn(userIdForStoreManager);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getCashierRole(), email)).thenReturn(userIdForCashier);

		Pageable paging = PageRequest.of(page - 1, size, Sort.by("merchantNotificationId").descending());
		List<MerchantNotification> merchantNotificationList = new ArrayList();
		MerchantNotification merchantNotification = new MerchantNotification();
		merchantNotification.setMerchantNotificationId(1l);
		merchantNotificationList.add(merchantNotification);
		Page<MerchantNotification> pageResponse = new PageImpl(merchantNotificationList);

		Mockito.when(merchantNotificationRepository.findByUserId(userIdForCashier, paging)).thenReturn(pageResponse);
		assertDoesNotThrow(() -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email, page, size, storeID,
				casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForMerchant() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = null;
		String xCountryCode = "KEN";
		Stores store = new Stores();
		store.setStoreId(1l);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		List<Long> counterList = new ArrayList<>();
		counterList.add(79l);
		Mockito.when(applicationProperties.getStoreManagerRole()).thenReturn(16);
		Mockito.when(applicationProperties.getCashierRole()).thenReturn(15);

		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getStoreManagerRole(), email)).thenReturn(userIdForStoreManager);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getCashierRole(), email)).thenReturn(userIdForCashier);
		Mockito.when(counterRepository.findcounterIdByClientIdAndCountryCode(casUser.getCustomerID(), xCountryCode))
				.thenReturn(counterList);
		Pageable paging = PageRequest.of(page - 1, size, Sort.by("merchantNotificationId").descending());
		List<MerchantNotification> merchantNotificationList = new ArrayList();
		MerchantNotification merchantNotification = new MerchantNotification();
		merchantNotification.setMerchantNotificationId(1l);
		merchantNotificationList.add(merchantNotification);
		Page<MerchantNotification> pageResponse = new PageImpl(merchantNotificationList);

		Mockito.when(merchantNotificationRepository.findNotificationForMerchantOnTheBasisOfClientAndCountryCode(
				casUser.getCustomerID(), paging, counterList)).thenReturn(pageResponse);
		assertDoesNotThrow(() -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email, page, size, storeID,
				casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForMerchantWithFilter() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = 1l;
		String xCountryCode = "KEN";
		Stores store = new Stores();
		store.setStoreId(1l);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		List<Long> counterList = new ArrayList<>();
		counterList.add(79l);
		Mockito.when(applicationProperties.getStoreManagerRole()).thenReturn(16);
		Mockito.when(applicationProperties.getCashierRole()).thenReturn(15);
		Mockito.when(storeRepository.findStoreById(storeID)).thenReturn(store);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getStoreManagerRole(), email)).thenReturn(userIdForStoreManager);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getCashierRole(), email)).thenReturn(userIdForCashier);
		Mockito.when(storeRepository.findStoresByStoreIdAndClientId(storeID, casUser.getCustomerID()))
				.thenReturn(store);
		Mockito.when(counterRepository.findcounterIdListByStoreId(storeID)).thenReturn(counterList);
		Pageable paging = PageRequest.of(page - 1, size, Sort.by("merchantNotificationId").descending());
		List<MerchantNotification> merchantNotificationList = new ArrayList();
		MerchantNotification merchantNotification = new MerchantNotification();
		merchantNotification.setMerchantNotificationId(1l);
		merchantNotificationList.add(merchantNotification);
		Page<MerchantNotification> pageResponse = new PageImpl(merchantNotificationList);

		Mockito.when(merchantNotificationRepository.findNotificationForMerchantOnTheBasisOfClientAndCountryCode(
				casUser.getCustomerID(), paging, counterList)).thenReturn(pageResponse);
		assertDoesNotThrow(() -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email, page, size, storeID,
				casUser, xCountryCode));
	}

	@Test
	void testFetchNotificationForMerchantStoreNotFound() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String email = "java@gmail.com";
		Integer page = 1;
		Integer size = 10;
		Long storeID = 1l;
		String xCountryCode = "KEN";
		Stores store = new Stores();
		store.setStoreId(1l);
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		List<Long> counterList = new ArrayList<>();
		counterList.add(79l);
		Mockito.when(applicationProperties.getStoreManagerRole()).thenReturn(16);
		Mockito.when(applicationProperties.getCashierRole()).thenReturn(15);
		Mockito.when(storeRepository.findStoreById(storeID)).thenReturn(store);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getStoreManagerRole(), email)).thenReturn(userIdForStoreManager);
		Mockito.when(userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
				applicationProperties.getCashierRole(), email)).thenReturn(userIdForCashier);

		assertThrows(PermissionException.class, () -> merchantServiceImpl.getMerchantDetailOnTheBasisOfEmail(email,
				page, size, storeID, casUser, xCountryCode));
	}

	@Test
	void testMerchantDetailWithouToken() {
		String counterCode = "1";
		String country="KEN";
		Counters counter = new Counters();
		counter.setActive(1);
		counter.setCounterCode(1234l);
		counter.setCounterId(1l);
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,country)).thenReturn(counter);
		assertDoesNotThrow(() -> merchantServiceImpl.getCounterInfoByCounterCode(counterCode,country));
	}

	@Test
	void testMerchantDetailWithoutTokenCounterNotFound() {
		String counterCode = "1";
		String country="KEN";
		Mockito.when(counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,country)).thenReturn(null);
		assertThrows(NotFoundExceptions.class, () -> merchantServiceImpl.getCounterInfoByCounterCode(counterCode,country));
	}

}
