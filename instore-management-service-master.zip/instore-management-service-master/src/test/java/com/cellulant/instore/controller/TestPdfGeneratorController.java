package com.cellulant.instore.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cellulant.instore.utils.ApplicationProperties;
import com.itextpdf.text.DocumentException;

@ExtendWith(MockitoExtension.class)
 class TestPdfGeneratorController {

	@InjectMocks
	 PdfGeneratorController pdfGeneratorController;
	
	@Mock
	 ApplicationProperties applicationProperties;
	

	
//	@Test
//	void testGeneratePdfForCounterCode() throws IOException, DocumentException {
//			String counterCode = "1234";
//			Whitebox.setInternalState(this.pdfGeneratorController, "applicationProperties", applicationProperties);
//		 Mockito.when(applicationProperties.getTinggLogoUrl()).thenReturn("http://accounts.dev.tingg.africa/assets/img/logo-small.png");
//			InputStream is = new ByteArrayInputStream(Charset.forName("UTF-16").encode(counterCode).array());
//            ResponseEntity<InputStreamResource> response =  new ResponseEntity<InputStreamResource>(HttpStatus.OK);
//    		response = pdfGeneratorController.download(counterCode);
//	}
	
	@Test
	void testGeneratePdfForBeepTransactionId() throws IOException, DocumentException {
			String beepTransactionId = "1223444225";
			Whitebox.setInternalState(this.pdfGeneratorController, "applicationProperties", applicationProperties);
		 Mockito.when(applicationProperties.getTinggLogoUrl()).thenReturn("http://accounts.dev.tingg.africa/assets/img/logo-small.png");
			InputStream is = new ByteArrayInputStream(Charset.forName("UTF-16").encode(beepTransactionId).array());
            ResponseEntity<InputStreamResource> response =  new ResponseEntity<InputStreamResource>(HttpStatus.OK);
    		response = pdfGeneratorController.generatePdfForBeepTransactionId(beepTransactionId);
	}
}
