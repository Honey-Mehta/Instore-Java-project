package com.cellulant.instore.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpServerErrorException.InternalServerError;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.dto.CashierDto;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

@ExtendWith(MockitoExtension.class)
 class TestCashierController {
	
	@InjectMocks
	private CashierController cashierController;
	
	@Mock
	private RestTemplate restTemplate;
	
	@Mock
	private ApplicationProperties applicationProperties;
	
	private final String response = "{'success':true,'statusCode':200,'message':'cashier is added'}";
	
	private final String responseInternal = "{'success':false,'statusCode':500,'message':'InternalServer Error'}";
	
	@Test
	void testAddCashierThrowException() {
		CASUser casUser = CASUser.builder().metaData(CASUser.MetaData.builder().accessToken("Cass").build())
				.customerID(23L).build();
		CashierDto cashierDto =  new CashierDto();
		String xCountryCode = "KEN";
		cashierDto.setCounterCode("1");
		cashierDto.setEmailAddress("abc");
		cashierDto.setIdNumber("1234");
		String restResponse =  "abc.com";
		Gson gson = new Gson();
        HttpHeaders headers = new HttpHeaders();
        String token = "abc";
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        headers.set("content-type", "application/json");
    	when(this.applicationProperties.getCashierUrl()).thenReturn(restResponse);
        HttpEntity<String> http = new HttpEntity<>(gson.toJson(cashierDto), headers);
        Mockito.when(restTemplate.postForObject(applicationProperties.getCashierUrl(), http, String.class))
        .thenReturn(response);
		ResponseEntity<Object>  response = cashierController.addCashier(cashierDto,xCountryCode, casUser);
		assertNotNull(response);
	}
	

	
	
	
	@Test
	void testAddCashier() {
		CASUser casUser = CASUser.builder().metaData(CASUser.MetaData.builder().accessToken("Cass").build())
				.customerID(23L).build();
		CashierDto cashierDto =  new CashierDto();
		cashierDto.setCounterCode("1");
		cashierDto.setEmailAddress("abc");
		cashierDto.setIdNumber("1234");
		String restResponse =  "abc.com";
		String xCountryCode = "KEN";
		Gson gson = new Gson();
        HttpHeaders headers = new HttpHeaders();
        String token = "abc";
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        headers.set("content-type", "application/json");
        
    	when(this.applicationProperties.getCashierUrl()).thenReturn(restResponse);
        

        HttpEntity<String> http = new HttpEntity<>(gson.toJson(cashierDto), headers);
        Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
        .thenReturn(response);
        
		ResponseEntity<Object>  response = cashierController.addCashier(cashierDto,xCountryCode, casUser);
	
		assertNotNull(response);
			
	}
	
	@Test
	void testAddCashierThrowInternalServerError() {
		CASUser casUser = CASUser.builder().metaData(CASUser.MetaData.builder().accessToken("Cass").build())
				.customerID(23L).build();
		String xCountryCode = "KEN";
		CashierDto cashierDto =  new CashierDto();
		cashierDto.setCounterCode("1");
		cashierDto.setEmailAddress("abc");
		cashierDto.setIdNumber("1234");
		HttpClientErrorException http = HttpClientErrorException.Unauthorized.create(HttpStatus.BAD_REQUEST, null, null, null, null);
        Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any()))
        .thenThrow(http);
        
		ResponseEntity<Object>  response = cashierController.addCashier(cashierDto,xCountryCode, casUser);
	
		assertNotNull(response);
			
	}
}
