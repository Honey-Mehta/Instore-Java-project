package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestAppNotification {

	
	@InjectMocks
	AppNotification appNotification;
	
	@Test
    void testBean() {
		
		AppNotification appNotification = new AppNotification();
		AppNotification allArgsAppNotification = new AppNotification(1l, 1l, "abc", "abc", "abc", 1, 1, "abc", "abc", "abc", 1);
		
		appNotification.setAppNotificationId(1l);
		appNotification.setMerchantNotificationId(1l);
	    appNotification.setDeviceId("abc");
	    appNotification.setTitle("abc");
	    appNotification.setMessage("abc");
	    appNotification.setNumberOfSends(1);
	    appNotification.setStatus(1);
	    appNotification.setStatusHistory("abc");
	    appNotification.setRequestPayload("abc");
	    appNotification.setResponsePayload("abc");
	    appNotification.setActive(1);
	    
		assertEquals(1l, (long)appNotification.getAppNotificationId());
		assertEquals(1l, (long)appNotification.getMerchantNotificationId());
		assertEquals("abc",appNotification.getDeviceId());
		assertEquals("abc",appNotification.getTitle());
		assertEquals("abc",appNotification.getMessage());
		assertEquals(1, (int)appNotification.getNumberOfSends());
		assertEquals(1, (int)appNotification.getStatus());
		assertEquals("abc",appNotification.getStatusHistory());
		assertEquals("abc",appNotification.getRequestPayload());
		assertEquals("abc",appNotification.getResponsePayload());
		assertEquals(1, (int)appNotification.getActive());
		appNotification.equals(allArgsAppNotification);
		appNotification.hashCode();

	}
	
	@Test
	void onCreate() {
		appNotification.onCreate();
	}

	@Test
	void onUpdate() {
		appNotification.onUpdate();
	}

	@Test
	void testToString() {
		appNotification.toString();
		assertNotNull(appNotification.toString());
	}
	
}
