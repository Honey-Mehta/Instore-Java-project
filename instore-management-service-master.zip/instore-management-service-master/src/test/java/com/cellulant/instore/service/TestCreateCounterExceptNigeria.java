package com.cellulant.instore.service;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel.Code;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.CounterCodes;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CountersDto;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;

@ExtendWith(MockitoExtension.class)
class TestCreateCounterExceptNigeria {

	@InjectMocks
	private CreateCounterExceptNigeria createCounterExceptNigeria;

	@Mock
	private UserRepository userRepository;

	@Mock
	private StoreRepository storeRepository;

	@Mock
	private CounterRepository counterRepository;

	@Mock
	private ApplicationProperties applicationProperties;

	@Mock
	private CounterCodesRepository counterCodesRepository;

	@Mock
	private Utility utility;

	List<CounterDto> counterDtoList;
	List<CountersDto> countersdtoList;
	CountersDto countersDto;
	CASUser casUser;
	CounterDto counterdto;
	Stores store;
	Counters counter;
	CounterCodes counterCodes;

	@BeforeEach
	void setUp() {
		casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		counterDtoList = new ArrayList<>();
		counterdto = new CounterDto();
		counter = new Counters();
		counter.setCounterId(1l);
		counterCodes = new CounterCodes();
		counterCodes.setActive(1);
		counterCodes.setCounterCode("1");

		counterCodes.setCounterId(1l);
		counterCodes.setCountry("ZMB");
		
		counterdto.setCounterCode("1");
		counterdto.setCounterCodeType(2);
		counterdto.setCounterName("test");
		counterdto.setDescription("test");
		counterdto.setIsReference("NO");
		counterdto.setMsisdn("1234567891");
		counterdto.setStoreId(1l);
		counterDtoList.add(counterdto);

		countersdtoList = new ArrayList<>();
		countersDto = new CountersDto();
		countersDto.setActive(1);
		countersDto.setCounterCode("1");
		countersDto.setCounterName("test");
		countersDto.setDescription("test");
		countersDto.setIsReference(IsReference.NO);
		countersDto.setMsisdn("1234567891");
		countersDto.setStoreId(12l);
		countersdtoList.add(countersDto);

		store = new Stores();
		store.setCountry("ZMB");
	}

	@Test
	void testSaveCounter() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		List<Stores> storeList = new ArrayList<>();
		List<CountersDto> countersList = new ArrayList<>();
		String xCountryCode = "AFG";
		Stores store = new Stores();
		store.setStoreId(1l);
		storeList.add(store);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		Long userIdForCashier = null;
		Long userIdForStoreManager = null;
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		Counters savecounter = new Counters();
		savecounter.setCounterId(1l);
		savecounter.setCounterCode(1l);
		savecounter.setCounterName("counter");
		String reference = (counterDto.getIsReference()).replaceAll("\\s", "");
		savecounter.setIsReference(reference.equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO);
		savecounter.setActive(applicationProperties.getActiveStatus());
		savecounter.setCounterName(counterDto.getCounterName());
		Counters counter = Counters.builder().counterId(1l).counterCode(1l).counterName("counters").build();
		Integer maxCounter = 4;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(NotFoundExceptions.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}

	@Test
	void testSaveCounterThrowError() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		List<Stores> storeList = new ArrayList<>();
		Stores store = new Stores();
		store.setStoreId(1l);
		storeList.add(store);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		Long userIdForCashier = null;
		Long userIdForStoreManager = 1l;
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		Counters counter = new Counters();
		String reference = (counterDto.getIsReference()).replaceAll("\\s", "");
		counter.setIsReference(reference.equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO);
		counter.setActive(applicationProperties.getActiveStatus());
		counter.setCounterName(counterDto.getCounterName());
		listOfCounter.add(counter);
		Integer maxCounter = 4;
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);

		assertThrows(NotFoundExceptions.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}


	@Test
	void testSaveCounterForAdmin() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.ADMIN).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		assertThrows(PermissionException.class,
				() -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));
	}

	@Test
	void testSaveCounterUnAuth() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.RESELLER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		assertThrows(PermissionException.class,
				() -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}

	@Test
	void testSaveCounterForCashier() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		List<CounterDto> counterDtoList = new ArrayList<>();
		String xCountryCode = "AFG";
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDto.setIsReference("yes");
		counterDtoList.add(counterDto);
		Long userIdForCashier = 1l;
		Long userIdForStoreManager = null;
		Mockito.when(userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole()))
				.thenReturn(userIdForCashier);
		Mockito.when(userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole()))
				.thenReturn(userIdForStoreManager);
		assertThrows(PermissionException.class,
				() -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}

	@Test
	void testSaveCounterThrowPhoneConstraint() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		counterPhoneList.add(countersDto);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");

		counterDto.setMsisdn("5985698");
		counterDtoList.add(counterDto);

		assertThrows(NotFoundExceptions.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}

	@Test
	void testSaveCounterThrowCounterNameConstraint() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		CountersDto countersDto = new CountersDto();
		counterPhoneList.add(countersDto);
		CounterDto counterDto = new CounterDto();
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");

		counterDto.setMsisdn("5985698");
		counterDtoList.add(counterDto);

		assertThrows(NotFoundExceptions.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}

	@Test
	void testSaveCounterThrowException() {
		CASUser casUser = CASUser.builder().customerID(1l).build();
		String xCountryCode = "AFG";
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		CounterDto counterDto = new CounterDto();

		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDtoList.add(counterDto);
		Counters counter = new Counters();
		counter.setActive(1);
		counter.setCounterName(counterDto.getCounterName());
		listOfCounter.add(counter);
		Integer maxCounter = 4;
		List<Stores> storeList = new ArrayList<>();
		Stores stores = new Stores();
		stores.setStoreId(1l);
		storeList.add(stores);

		assertThrows(RuntimeException.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}

	@Test
	void testSaveCounterThrowStoreNotFound() {
		CASUser casUser = CASUser.builder().customerID(1l).customerLevel(Code.CUSTOMER).build();
		List<CounterDto> counterDtoList = new ArrayList<>();
		List<Counters> listOfCounter = new ArrayList<>();
		CounterDto counterDto = new CounterDto();
		String xCountryCode = "AFG";
		counterDto.setStoreId(1l);
		counterDto.setCounterName("amazon");
		counterDtoList.add(counterDto);
		Counters counter = new Counters();
		counter.setActive(1);
		counter.setCounterName(counterDto.getCounterName());
		listOfCounter.add(counter);
		Integer maxCounter = 4;
		assertThrows(NotFoundExceptions.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));

	}
	
	@Test
	void testCreateCounter() {
		CounterDto counterDto = new CounterDto("test", 1l, "test", "1234567891", "NO", 0, null, null, "1");
		Counters counter = Counters.builder().counterCode(1l).counterName("counters").build();
		Counters saveCounter = Counters.builder().counterId(1l).counterCode(1l).counterName("counters").build();
		Stores store = new Stores(1l, 1l, "store", "Nai", "Naroibi", "KEN", "AZM", "The Desc", 1,"1");
		CounterCodes counterCodesDto = new CounterCodes();
		counterCodesDto.setCounterCode(String.valueOf(1));
		counterCodesDto.setCounterCodeType(0);
		counterCodesDto.setCounterId(1l);
		counterCodesDto.setCountry(store.getCountry());
		counterCodesDto.setCreatedBy(store.getCreatedBy());
		counterCodesDto.setModifiedBy(store.getModifiedBy());
		counterCodesDto.setActive(1);
		List<CountersDto> countersList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		Mockito.when(storeRepository.findStoreById(counterDto.getStoreId())).thenReturn(store);
		Mockito.when(utility.setCounterInformation(counterDto, casUser)).thenReturn(counter);
		Mockito.when(counterRepository.save(counter)).thenReturn(saveCounter);
		Mockito.when(counterCodesRepository.save(counterCodesDto)).thenReturn(counterCodesDto);

		assertDoesNotThrow(() -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));
	}
	
	@Test
	void testCreateCounters() {
		CounterDto counterDto = new CounterDto("The Desc", 1l, "counter", "884152525", "Yes", 1, "test", 1l, "1");
		Counters counter = Counters.builder().counterCode(1l).counterName("counters").build();
		Counters saveCounter = Counters.builder().counterId(1l).counterCode(1l).counterName("counters").build();
		Stores store = null;
		List<CountersDto> countersList = new ArrayList<>();
		List<CountersDto> counterPhoneList = new ArrayList<>();
		Mockito.when(storeRepository.findStoreById(counterDto.getStoreId())).thenReturn(store);
		assertThrows(NotFoundExceptions.class, () -> createCounterExceptNigeria.createCounter(counterDtoList, casUser,"KEN"));
	}
}
