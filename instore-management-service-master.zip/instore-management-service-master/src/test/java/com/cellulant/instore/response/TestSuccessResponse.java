package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestSuccessResponse {
	
    @InjectMocks
    SuccessResponse successResponse;
    
    @Test
    void testBeans() {
    	SuccessResponse successResponse = new SuccessResponse();
    	SuccessResponse allargsSuccessResponse = new SuccessResponse(true, 200, "success", successResponse);
    	
    	successResponse.setMessage("success");
    	successResponse.setStatusCode(200);
    	successResponse.setSuccess(true);
    	successResponse.setData(successResponse);
    	
    	assertEquals("success", successResponse.getMessage());
    	assertEquals(200, successResponse.getStatusCode());
    	assertEquals(true, successResponse.getSuccess());
    	assertEquals(successResponse, successResponse.getData());
    }
    
    @Test
    void testToString() {
    	successResponse.toString();
    	assertNotNull(successResponse.toString());
    }
}
