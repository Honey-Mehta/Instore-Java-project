package com.cellulant.instore.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestNotificationTypes {
    
	@InjectMocks
	NotificationTypes notificationTypes;

	@Test
    void testBean() {
		
		NotificationTypes notificationType = new NotificationTypes();
		NotificationTypes allArgsNotificationTypes = new NotificationTypes(1l, "abc", "abc", 1);
		notificationType.setNotificationTypeId(1l);
		notificationType.setNotificationType("abc");
		notificationType.setDescription("abc");
		notificationType.setActive(1);
	
		assertEquals(1l, (long)notificationType.getNotificationTypeId());
		assertEquals("abc",notificationType.getNotificationType());
		assertEquals("abc",notificationType.getDescription());
		assertEquals(1, (int)notificationType.getActive());
		
		notificationType.equals(allArgsNotificationTypes);
		notificationType.hashCode();

	}
	
	@Test
	void onCreate() {
		notificationTypes.onCreate();
	}

	@Test
	void onUpdate() {
		notificationTypes.onUpdate();
	}

	@Test
	void testToString() {
		notificationTypes.toString();
		assertNotNull(notificationTypes.toString());
	}
}
