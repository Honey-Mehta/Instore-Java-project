package com.cellulant.instore.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
 class TestCounterDetail {

	@InjectMocks
	private CounterDetail counterDetail;
	
	@Test
	void testBean() {
		
		CounterDetail counterDetail =  new CounterDetail();
		CounterDetail allArgsCounterDetail =  new CounterDetail(1l, "abc", "abc", "abc");
		
		counterDetail.setCashierName("abc");
        counterDetail.setCounterId(1l);
        counterDetail.setCounterName("abc");
        counterDetail.setMsisdn("abc");
        
        assertEquals(1l,counterDetail.getCounterId());
        assertEquals("abc", counterDetail.getCashierName());
        assertEquals("abc", counterDetail.getCounterName());
        assertEquals("abc", counterDetail.getMsisdn());
		
	}
	
	@Test
	void testToString() {
		counterDetail.toString();
		assertNotNull(counterDetail.toString());
	}
}
