package com.cellulant.instore.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NigeriaResponseDto {

	private String accountnumber;

	private String accountname;
	private String bankname;
}
