package com.cellulant.instore.dto;
import lombok.Data;

@Data
public class CounterCodesDetail {

	private String counterCode;
	private String type;
}
