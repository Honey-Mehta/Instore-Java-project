package com.cellulant.instore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.repository.MerchantNotificationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.service.MerchantService;


@RestController
@CrossOrigin(origins = "*")
public class MerchantController {
	@Autowired
	private MerchantService merchantService;
	

	
	@Autowired
	private UserRepository userRepository;
	
	
	@Autowired
	private MerchantNotificationRepository merchantNotificationRepository;
	
	@Autowired
	private com.cellulant.instore.repository.StoreRepository storeRepository;

	@GetMapping("/fetchMerchantDetailsByCounterCode/{counterCode}")
	public ResponseEntity<Object> getMerchantDetails(@PathVariable String counterCode,
			@RequestHeader(value = "X-Country-Code", required = true)  String xCountryCode,@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" getMerchantDetails() method START " + counterCode).info();
			return merchantService.getMerchantDetailByCounterCode(counterCode,xCountryCode);
	}
	
	@GetMapping("/counterInfo/{counterCode}")
	public ResponseEntity<Object> getCounterInfo(@PathVariable String counterCode,
			@RequestHeader(value = "X-Country-Code", required = true)  String xCountryCode)  {
		Logger.builder(" getCounterInfo() method START " + counterCode).info();
			return merchantService.getCounterInfoByCounterCode(counterCode,xCountryCode);
	}
	
	@GetMapping("/fetchMerchant/{clientId}")
	public ResponseEntity<Object> getMerchantNotification(@PathVariable Long clientId,@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" getMerchantNotification() method START " + clientId).info();
		return merchantService.getMerchantDetailOnTheBasisOfClientId(clientId);
	}
	
	
	@GetMapping("/fetchStoresAndCountersCount")
	public ResponseEntity<Object> fetchStoresAndCountersCount(@RequestHeader(value = "X-Country-Code", required = true, defaultValue = "") String xCountryCode,
			@AuthenticationPrincipal CASUser casUser){
		Logger.builder(" fetchStoresAndCountersCount() method START " ).info();
			
			return merchantService.getTotalCounterAndStoresofParticaularClient(casUser.getCustomerID(),casUser,xCountryCode);	
	}
	
	

	@GetMapping("fetchCountersAndCashiersCount/{storeId}")
	public ResponseEntity<Object> fetchCountersAndCashiersCount(@PathVariable Long storeId,@AuthenticationPrincipal CASUser casUser){
		 Logger.builder(" fetchCountersAndCashiersCount() method START "+storeId).info();
		return merchantService.getTotalCashierAndCounterOnTheBasisOfStoreId(storeId);
		}
	
	@GetMapping("/fetchMerchantDetailByUserId")
	public ResponseEntity<Object> fetchMerchantNotificationByEmail(@RequestParam(name = "email", required = true) String email,
			@RequestParam(name = "storeID", required = false) Long storeID,
			@RequestParam(name = "page", required = false,defaultValue = "1") Integer page,
	        @RequestParam(name = "size", required = false,defaultValue = "10") Integer size,
	        @RequestHeader(value = "X-Country-Code", required = true) String xCountryCode,
			@AuthenticationPrincipal CASUser casUser ){
		Logger.builder(" fetchMerchantNotificationByUserId() method START "+email).info();
				return merchantService.getMerchantDetailOnTheBasisOfEmail(email, page, size, storeID,casUser, xCountryCode);
		
	}

}
