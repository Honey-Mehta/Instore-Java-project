package com.cellulant.instore.response;

import com.cellulant.instore.model.IsReference;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ToString
public class MerchantDetail {
  
	private String storeName;
	
	private String counterName;
	
	private String counterCode;
	
	private Long customerId;
	
	private String address;
	
	private Long storeCode;
	
	private IsReference isReference;
	
	private String countryCode;
	
	
}
