package com.cellulant.instore.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.request.CounterDto;

public interface CounterCreation {


	public ResponseEntity<Object> createCounter( List<CounterDto> counterDto,CASUser casUser,String xCountryCode);

	
	 String getCounterCreationName();
}
