package com.cellulant.instore.response;

import java.util.List;

import com.cellulant.instore.model.Counters;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StoreCounterDetail {
	
	private Long storeId;
	
	private String storeName;
	
	private String mobile;
	
	private List<Counters> counterList;
}
