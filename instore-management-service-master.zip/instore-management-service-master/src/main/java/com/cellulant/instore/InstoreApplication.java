package com.cellulant.instore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

import com.cellulant.cas.auth.servlet.EnableCASAuthentication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
@EnableCASAuthentication
@EnableRetry
@OpenAPIDefinition(info = @Info(title = "Instore Mangement Service", version = "2.0", description = "Instore related Api's"))
public class InstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstoreApplication.class, args);
	}

}
