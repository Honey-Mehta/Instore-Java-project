package com.cellulant.instore.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StoreDto {
	 
		private Long storeId;
		
		private String storeName;
		
		private String city;
		private String address;
		private String msisdn;
		private String country;
		
		private Long totalCounter;
		private String storeManager;
		private Integer status;
		private Long userID;
		private Long storeAssignmentID;
}
