package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "storeassignment")
@EqualsAndHashCode(callSuper = true)
public class StoreAssignment extends Actionable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "storeAssignmentID",unique = true,nullable = false)
	private Long storeAssignmentId;
	
	@Column(name="storeID")
	private Long storeId;
	
	@Column(name="userID")
	private Long userId;
	
	@Column(name="active")
	private Integer active;

}
