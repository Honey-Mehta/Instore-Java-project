package com.cellulant.instore.service;

import java.io.IOException;

import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.dto.DeviceIdDto;
import com.cellulant.instore.dto.UpdateCounterDto;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Counters;
import com.itextpdf.text.DocumentException;

public interface CounterService {




	ResponseEntity<Object> getCounters(CASUser casUser);


	ResponseEntity<Object> updateDeviceId(DeviceIdDto deviceIdDto, CASUser casUser);

	ResponseEntity<Object> updateCounter(UpdateCounterDto updateCounterDto, CASUser casUser,Counters counter );

	ResponseEntity<Object> deleteCounter(String counterCode, CASUser casUser,Counters counter);

	ResponseEntity<Object> fetchCounterById(String counterId, CASUser casUser,Counters counter);

	ResponseEntity<Object> fetchCashierDetail(String role, CASUser casUser);

	ResponseEntity<Object> findCountersByStoreId(Long storeId, String searchCounters, int page, int size,
			CASUser casUser) throws PermissionException, IOException, DocumentException;

}
