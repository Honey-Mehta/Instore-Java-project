package com.cellulant.instore.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CounterAndCashierCountDto {
	
	@JsonProperty("counter_count")
	private Long counterCount;
	
	@JsonProperty("cashier_count")
	private Long cashierCount;

}
