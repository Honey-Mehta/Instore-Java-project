package com.cellulant.instore.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class CounterDto {

	private String description;

	@NotNull(message = "storeId can not be null")
	private Long storeId;

	@NotNull(message = "counterName is required")
	@NotEmpty(message = "counterName can not be null")
	private String counterName;

	@NotNull(message = "msisdn number is required")
	@NotEmpty(message = "msisdn can not be null")
	private String msisdn;

	@NotNull(message = "isReference is required")
	@NotEmpty(message = "isReference can not be null")
	private String isReference;

	private int counterCodeType;

	private String counterCodeTypeName;
	private Long counterId;


	@Length(max = 20, message = "Counter code value cannot exceed 20 digits")
	private String counterCode;

}
