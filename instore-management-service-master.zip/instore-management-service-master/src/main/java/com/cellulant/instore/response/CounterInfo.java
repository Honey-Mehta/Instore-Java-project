package com.cellulant.instore.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CounterInfo {

	private String counterCode;

	private String counterName;

	private String msisdn;

	private String userName;

	private String storeName;

	private String emailAddress;
}
