package com.cellulant.instore.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "counters")
@EqualsAndHashCode(callSuper = true)
@Builder
public class Counters extends Actionable {
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "counterID", unique = true,nullable = false)
	private Long counterId;
	
    @Column(name = "counterCode")
	private Long counterCode;
    
    @Column(name = "MSISDN")
	private String msisdn;
    
    @Column(name = "counterName")
    private String counterName;
	
	@Column(name = "active")
	private Integer active;
	
	
	@Column(name = "description")
	private String description;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "isReference",nullable = false)
	private IsReference isReference;
	
	@Column(name = "storeID",nullable = false)
	private Long storeId;
	
	@Column(name = "deviceID",nullable = true)
	private String deviceId;
	

	@Column(name = "serviceCode")
	private String serviceCode;


}
