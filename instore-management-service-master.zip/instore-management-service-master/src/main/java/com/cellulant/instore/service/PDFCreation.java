package com.cellulant.instore.service;
import java.io.IOException;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cellulant.instore.response.QRCodeCounter;

public interface PDFCreation {

	public @ResponseBody ResponseEntity<InputStreamResource> downLoadPDF(String counterCode,QRCodeCounter counterInfo)throws IOException, com.lowagie.text.DocumentException ;

	
	 String getPdfCreationName();
}
