package com.cellulant.instore.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.MappingDeviceID;



public interface MappingDeviceIdRepository extends JpaRepository<MappingDeviceID, Long> {
	
	@Query(value = "select m FROM MappingDeviceID m WHERE m.deviceID=:deviceID and m.casUserID=:casUserID and m.role=:role AND m.active!=0")
	MappingDeviceID findMappingByDeviceId(@Param("deviceID") String deviceID,@Param("casUserID") Long casUserID,@Param("role") String role);
	
	@Query(value = "select m FROM MappingDeviceID m WHERE m.deviceID=:deviceID  and m.role=:role AND m.active!=0")
	MappingDeviceID findMappingByDeviceIdWithAlternativeRole(@Param("deviceID") String deviceID,@Param("role") String role);
	
	   
    @Transactional
   	@Modifying   
   	@Query("update MappingDeviceID m set m.active=0 where m.mappingID=:mappingID and m.active!=0")
   	int updateMappingDeviceId(@Param("mappingID") Long mappingID);

}
