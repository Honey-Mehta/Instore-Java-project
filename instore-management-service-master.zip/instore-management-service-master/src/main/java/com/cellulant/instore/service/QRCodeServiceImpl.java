package com.cellulant.instore.service;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.cellulant.core.logging.Logger;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

@Service
public class QRCodeServiceImpl implements QRCodeService {

   

    @Override
    public byte[] generateQRCode(String qrContent, int width, int height) {
        try {
        	Map<EncodeHintType, Object> hints = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
        	hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        	hints.put(EncodeHintType.MARGIN, 0); /* default = 4 */
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(qrContent, BarcodeFormat.QR_CODE, width, height,hints);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        } catch (WriterException e) {
          Logger.info("WriterException "+e.getLocalizedMessage());
        } catch (IOException e) {
        	Logger.info("IOException "+e.getLocalizedMessage());
        }
        return null;
    }
}
