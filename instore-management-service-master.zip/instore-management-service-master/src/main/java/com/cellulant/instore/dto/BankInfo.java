package com.cellulant.instore.dto;
import lombok.Data;


@Data
public class BankInfo {
	private String accountNumber;
	private String accountState;

	
}