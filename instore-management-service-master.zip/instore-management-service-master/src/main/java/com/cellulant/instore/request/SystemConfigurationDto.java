package com.cellulant.instore.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class SystemConfigurationDto {
	
    private Long systemConfigurationId;
	
	private Integer clientId;
	
	private String configKey;
	
	private String configValue;
	
	private Integer active;
	
	private String createdBy;

	private String modifiedBy;

}
