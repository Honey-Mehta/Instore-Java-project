package com.cellulant.instore.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NigeriaDto {

	private String clientId;
	private String uniqueId;
	private String amount;
	private String serviceCode;
	private String accountReference;
	private String merchantId;
	private String serviceName;

}
