package com.cellulant.instore.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;


@Data
@MappedSuperclass
public class Actionable implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dateCreated")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone ="EAT")
	private Date dateCreated;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dateModified")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone ="EAT")
	private Date dateModified;
	
	@Column(name = "createdBy")
	private Long createdBy;
	
	@Column(name = "modifiedBy")
	private Long modifiedBy;
	
	@PrePersist
	public void onCreate() {
		this.dateCreated = this.dateModified = new Date();
	}

	@PreUpdate
	public void onUpdate() {
		this.dateModified = new Date();
	}
	

}
