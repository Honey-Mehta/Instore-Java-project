package com.cellulant.instore.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cellulant.core.logging.Logger;
import com.cellulant.instore.utils.AppConstants;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Setter
public class CounterCreationFactory {
	
	
	@Autowired
	private List<CounterCreation> counterCreationList;

	
	private static final Map<String, CounterCreation> handler = new HashMap<String, CounterCreation>();

	
	@PostConstruct
	private void getObject() {
		 for (CounterCreation counterCreation : counterCreationList) {
			 Logger.info("Counter Creation Name-->>>> "+counterCreation.getCounterCreationName()+" : Counter Creation Instance -->>>>  "+counterCreation);
			 handler.put(counterCreation.getCounterCreationName(), counterCreation);
		    }
	}
	
	 public static CounterCreation createInstance(String isoCountryCode) {
		 CounterCreation counterCreation = handler.get(isoCountryCode.toUpperCase());
		    Logger.info("number of  isoCountry Code {} "+handler.size());
		    if (counterCreation == null)
		      throw new IllegalArgumentException(AppConstants.INVALID_COUNTRY_CODE);
		    return counterCreation;
		  }
	
}
