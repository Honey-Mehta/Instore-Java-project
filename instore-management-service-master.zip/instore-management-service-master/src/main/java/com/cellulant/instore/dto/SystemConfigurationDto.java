package com.cellulant.instore.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SystemConfigurationDto {

	@NotNull(message = "sendSMS is required")
	@NotEmpty(message = "sendSMS can not be null")
	private String sendSMS;
	
	@NotNull(message = "sendNotification is required")
	@NotEmpty(message = "sendNotification can not be null")
	private String sendNotification;
	
	@NotNull(message = "isCallBack is required")
	@NotEmpty(message = "isCallBack can not be null")
	private String isCallBack;
	
	@NotNull(message = "callBackUrl is required")
	@NotEmpty(message = "callBackUrl can not be null")
	private String callBackUrl;
	
	@NotNull(message = "clientId can not be null")
	private Long clientId;
	
	private String requestType;
}

