package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Entity
@Table(name = "mappingdeviceid")
public class MappingDeviceID extends Actionable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mappingID",unique = true,nullable = false)
	private Long mappingID;
	

	@Column(name = "casUserID")
	private Long casUserID;
	
	@Column(name = "deviceID",nullable = true)
	private String deviceID;
	
	@Column(name = "role")
	private String role;
	
	@Column(name = "clientID",nullable = false)
	private Long clientID;
	
	@Column(name = "active")
	private Integer active;
	
	
	

}
