package com.cellulant.instore.service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cellulant.core.logging.Logger;
import com.cellulant.instore.utils.AppConstants;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Setter
public class PDFCreationFactory {
	
	@Autowired
	private List<PDFCreation> pdfCreationList;

	
	private static final Map<String, PDFCreation> handler = new HashMap<String, PDFCreation>();

	
	@PostConstruct
	private void getObject() {
		 for (PDFCreation pdfCreation : pdfCreationList) {
			 Logger.info("Counter Creation Name-->>>> "+pdfCreation.getPdfCreationName()+" : PDF Creation Instance -->>>>  "+pdfCreation);
			 handler.put(pdfCreation.getPdfCreationName(), pdfCreation);
		    }
	}
	
	 public static PDFCreation createInstance(String isoCountryCode) {
		 PDFCreation pdfCreation = handler.get(isoCountryCode.toUpperCase());
		    Logger.info("number of  isoCountry Code {} "+handler.size());
		    if (pdfCreation == null)
		      throw new IllegalArgumentException(AppConstants.INVALID_COUNTRY_CODE);
		    return pdfCreation;
		  }

}
