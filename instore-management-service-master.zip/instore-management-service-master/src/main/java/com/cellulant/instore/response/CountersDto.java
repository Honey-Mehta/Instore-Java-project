package com.cellulant.instore.response;



import com.cellulant.instore.model.IsReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@AllArgsConstructor
@NoArgsConstructor
@Data
public class CountersDto {
	
    private Long counterId;
	
	private String counterCode;
    
	private String msisdn;
    
    private String counterName;
	
	private Integer active;
	
	private String description;
	
	private Long storeId;
	
	private IsReference isReference;
	


}
