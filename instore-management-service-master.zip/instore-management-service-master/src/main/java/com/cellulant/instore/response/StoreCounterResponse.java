package com.cellulant.instore.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class StoreCounterResponse {

	private Long storeId;
	
	private String storeName;
	
	private Long counterId;
	
	private String counterName;
}
