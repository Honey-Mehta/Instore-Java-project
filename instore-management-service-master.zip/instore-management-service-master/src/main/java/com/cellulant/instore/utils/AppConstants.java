package com.cellulant.instore.utils;

public class AppConstants {

	private AppConstants() {
	}

	public static final int SUCCESS_STATUS = 200;
	public static final int NO_CONTENT_STATUS = 204;
	public static final int INTERNAL_ERROR_STATUS_CODE = 500;
	public static final int NOT_FOUND = 404;
	public static final int BAD_REQUEST_STATUS_CODE = 400;
	public static final int NOT_AUTHORIZED = 403;
	public static final int MISSING_PARAMETER = 172;
	public static final int INVALID_PARAMETER = 175;
	public static final int PHONE_NUMBER_ALREADY_EXIST = 176;
	public static final Long STORE_COUNT_FOR_STORE_MANAGER = 1l;
	public static final int SQL_EXCEPTIONS = 1000;

	public static final String INTERNAL_SERVER_ERROR_MESSAGE = "Server Error";
	public static final String VALIDATION_FAILED = "Validation Failed";
	public static final String NO_CONTENT_MESSAGE = "No Store Found";
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String STORE_NOT_FOUND = "Store Id is not Found";
	public static final String STORE_UPDATED_SUCCESSFULLY = "Store Is updated Succesfully";
	public static final String STORE_ADDED_SUCCESSFULLY = "Store is added SuccessFully";
	public static final String STORE_NAME_ALREADY_EXIST1 = "The given store name ";
	public static final String STORE_NAME_ALREADY_EXIST2 = " is already in use, please try using another store name";
	public static final String COUNTER_NAME_ALREADY_EXIST = "The given counter name is already in use, please try using another counter name";
	public static final String COUNTER_PHONE_ALREADY_EXIST = "The given mobile number is already taken in the current store. Please try another one";
	public static final String COUNTER_NAME_ALREADY_EXIST2 = " is already in use, please try using another counter name";
	public static final String COUNTER_NOT_FOUND = "Counter Id is not Found";
	public static final String COUNTER_NOT_ADDED_SUCCESSFULLY = "Counter is not Added SuccessFully";
	public static final String COUNTER_UPDATED_SUCCESSFULLY = "Counter Is Updated Succesfully";
	public static final String COUNTER_ADDED_SUCCESSFULLY = "Congratulations your counter is successfully created";
	public static final String COUNTER_NOT_DELETED_SUCCESSFULLY = "Counter is not delete SuccessFully...!!!";
	public static final String COUNTER_DELETED_SUCCESSFULLY = "Counter is delete SuccessFully...!!!";
	public static final String STORE_FETCH_SUCCESSFULLY = "Store fetch SuccessFully";
	public static final String STORE_NOT_FETCH_SUCCESSFULLY = "Store not fetch SuccessFully";
	public static final String SYSTEM_CONFIGURATION_NOT_FOUND = "System Configuration Id is not Found";
	public static final String SYSTEM_CONFIGURATION_UPDATED_SUCCESSFULLY = "System Configuration Is Updated Succesfully";
	public static final String SYSTEM_CONFIGURATION_ADDED_SUCCESSFULLY = "System Configuration is Added SuccessFully";
	public static final String SYSTEM_CONFIGURATION_DELETED_SUCCESSFULLY = "System Configuration  deleted SuccessFully";
	public static final String STORE_DELETED_SUCCESSFULLY = "Store has been deleted succesfully";
	public static final String METHOD_ARGUMENT_MISMATCH = "Method Argument Type Mismatch";
	public static final String STOREID_NOT_FOUND = "Store Id Not Found";
	public static final String COUNTER_CODE_NOT_FOUND = "Counter code Not Found";
	public static final String CLIENTID_NOT_FOUND = "ClientId not found";
	public static final String USERID_NOT_FOUND = "userId not found";
	public static final String COUNTER_NOT_ASSIGN = "Counter is Not Assign for specific Cashier";
	public static final String CASHIER_IS_NOT_ADDED_SUCCESSFULLY = "Cashier is not added Successfully";
	public static final String CREATE_CASHIER_API_EXCEPTIONS = "Error while calling cashier Api";
	public static final String DEVICEID_NOT_UPDATED = "DeviceId is not Updated Successfully";
	public static final String DEVICEID_UPDATED = "DeviceId is updated successfully";
	public static final String SQL_EXCEPTIONS_MESSAGE = "SQL Exceptions Occur ";
	public static final String SYSTEM_CONFIGURATION_ONLY_FOR_ADMIN = "Not authorized";
	public static final String PERMISSION_FAILED = "Permission denied";
	public static final String PERMISSION_DENIED = "Cellulant admin only have permission to update mobile number";
	public static final String REQUEST_UNABLE_TO_PROCESS = "We are unable to process your request at this time, please try again later.";

	// QrCode
	public static final String TINGG_MESSAGE = "Or Scan QR Code To Pay";
	public static final String TINGG_MESSAGE1 = "       Work is hard\r\n" + " Payments shouldn't be!";
	public static final String TINGG_MESSAGE_FOR_TICKET = "#TICKET";

	public static final String INVALID_COUNTRY_CODE = "Invalid country code";

	// QRCODE Related Stuff
	public static final String QRCODE_GENERATED_SUCCESSFULLY = "QRCODE is generated successfully....";
	public static final int QRCODE_HEIGHT = 350;
	public static final int QRCODE_WIDTH = 350;
	public static final String QRCODE_EXTENSION = "PNG";
	public static final String COUNTERCODE_NOTFOUND = "CounterCode Not Found For Existing Client";
	public static final String SERVICECODE_NOTFOUND = "ServiceCode  Not Found For Existing Client";
	public static final String EXCEPTION_OCCUR = "Exception occur ";
	public static final String IS_COUNTER_CODE = "Yes";
    public static final  String MULTIPLE_SERVICECODE_FOUND= "Multiple service Codes have been found for Service Instore Client, NO allowed currently";

		
	  
		

}
