package com.cellulant.instore.response;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SuccessResponse {
	
	private Boolean success;
	private int statusCode;
	// General error message about nature of error
	private String message;

	private Object data;
	
}
