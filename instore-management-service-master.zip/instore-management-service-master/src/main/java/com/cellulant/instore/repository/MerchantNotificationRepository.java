package com.cellulant.instore.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.MerchantNotification;
import com.cellulant.instore.response.MerchantDetail;

public interface MerchantNotificationRepository extends JpaRepository<MerchantNotification, Long> {

	@Query(value = "select m FROM MerchantNotification m WHERE m.clientId=:clientId")
	List<MerchantNotification> findByClientId(@Param("clientId") Long clientId);
	
	//author gagan
	@Query(value = "select COUNT(s.storeId) FROM Stores s WHERE s.clientID=:customerID AND s.active !=0 and s.country=:xCountryCode")
	Long totalStoreForCustomer(@Param("customerID")Long customerID,@Param("xCountryCode")String xCountryCode);
	
	@Query(value = "select COUNT(s.storeId) FROM Stores s WHERE s.active !=0 and s.country=:xCountryCode")
	Long totalStoreForAdmin(@Param("xCountryCode")String xCountryCode);
	
	@Query(value = "select COUNT(c.counterId) FROM Counters c WHERE c.storeId in (select storeId FROM Stores s WHERE clientID=:customerID AND s.active !=0 and s.country=:xCountryCode) and c.active !=0 ")
	Long totalCountersForCustomer(@Param("customerID")Long customerID,@Param("xCountryCode")String xCountryCode);
	
	@Query(value = "select COUNT(c.counterId) FROM Counters c WHERE c.storeId in (select storeId FROM Stores s WHERE s.active !=0  and s.country=:xCountryCode) and c.active !=0 ")
	Long totalCountersForAdmin(@Param("xCountryCode")String xCountryCode);
	
	  @Query(value = "SELECT COUNT(*) FROM MerchantNotification m WHERE m.userId=:userId")
	  Long getTotalCounteOfUserId(@Param("userId")Long userId);
	  
    @Query(value="select COUNT(c.counterId) FROM Counters c WHERE c.storeId=:storeId and c.active !=0 ")
   Long totalCountersForStoreManager(@Param("storeId")Long storeId);
	
	  @Query(value="select m FROM MerchantNotification m WHERE m.userId=:userId ")
	Page<MerchantNotification> findByUserId(@Param("userId")Long userId,Pageable pageable);
	  
	  @Query(value="select m FROM MerchantNotification m WHERE m.clientId=:clientId ")
		Page<MerchantNotification> findNotificationForMerchant(@Param("clientId")Long clientId,Pageable pageable);
	  
	  
	  @Query(value="select m FROM MerchantNotification m WHERE   m.counterId in (:counterId) AND m.clientId=:clientId ")
		Page<MerchantNotification> findNotificationForMerchantOnTheBasisOfClientAndCountryCode(@Param("clientId")Long clientId,Pageable pageable,@Param("counterId")List<Long> counterId);
	
	@Query(value = "select m FROM MerchantNotification m WHERE m.userId=:userId And m.counterCode=:counterCode")
	Page<MerchantNotification> findMerchantDetailUsingUserIdAndCounterCode(@Param("userId")Long userId,
			@Param("counterCode")Long counterCode,Pageable pageable);
	
	  @Query(value="select m FROM MerchantNotification m ")
		Page<MerchantNotification> findMerchantNotificationForAdmin(Pageable pageable);
	  
	  @Query(value = "select new com.cellulant.instore.response.MerchantDetail(s.storeName,c.counterName,cc.counterCode,s.clientID,s.address,s.storeId,c.isReference,s.country)"
	       		+ " FROM Counters c INNER JOIN Stores s ON s.storeId = c.storeId"
			    + " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
	       		+ " WHERE cc.counterCode=:counterCode AND cc.country=:country")
	       MerchantDetail findMerchantDetailByCounterCode(@Param("counterCode") String counterCode,@Param("country")String country);
}
