package com.cellulant.instore.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QRCodeCounter {
	
	  private Long counterId;
		
		private String counterCode;
	    
		private String msisdn;
	    
	    private String counterName;
		
	    private String storeName;
		
		private Long storeId;
		
		private String country;

}
