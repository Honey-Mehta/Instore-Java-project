package com.cellulant.instore.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.SystemConfiguration;

public interface SystemConfigurationRepository extends JpaRepository<SystemConfiguration, Long>{

	@Query(value = "SELECT s from SystemConfiguration s where s.clientId=:clientId AND s.active!=0")
	List<SystemConfiguration> getMerchanthasConfigValueOrNot(@Param("clientId")Long clientId);
	
	@Query(value = "SELECT s FROM SystemConfiguration s WHERE s.systemConfigurationId=:systemConfigurationId AND s.active!=0")
	SystemConfiguration findSystemConfigurationById(@Param("systemConfigurationId")Long systemConfigurationId);
	
	@Query(value = "SELECT s FROM SystemConfiguration s WHERE s.active!=0")
	Page<SystemConfiguration> fetchSystemConfiguration(Pageable pageable);
	
	@Query(value = "SELECT s FROM SystemConfiguration s WHERE s.clientId=:merchantId AND s.active!=0")
	Page<SystemConfiguration> fetchSystemConfigurationByMerchantId(Pageable pageable,@Param("merchantId")Long merchantId);
	
	@Query(value = "SELECT s FROM SystemConfiguration s WHERE s.clientId=:clientId And s.configKey=:smsKey AND s.active!=0")
	SystemConfiguration findSystemConfigForSms(@Param("clientId")Long clientId,@Param("smsKey")String smsKey);
	
	@Query(value = "SELECT s FROM SystemConfiguration s WHERE s.clientId=:clientId And s.configKey=:appKey AND s.active!=0")
	SystemConfiguration findSystemConfigForApp(@Param("clientId")Long clientId,@Param("appKey")String appKey);
	
	@Query(value = "SELECT s FROM SystemConfiguration s WHERE s.clientId=:clientId And s.configKey=:settlementType AND s.active!=0")
	SystemConfiguration findSystemConfigForSettlement(@Param("clientId")Long clientId,@Param("settlementType")String settlementType);

	
	@Transactional
	@Modifying
	@Query("update SystemConfiguration s set s.active=0 where s.systemConfigurationId=:systemConfigurationId")
	int deleteSystemConfigurationById(@Param("systemConfigurationId") Long systemConfigurationId);

	
	@Transactional
	@Modifying
	@Query("update SystemConfiguration s set s.active=0 where  s.clientId=:clientId ")
	int deactivateSystemConfigurationOnTheBasisOfClientId(@Param("clientId")Long clientId);
}
