package com.cellulant.instore.utils;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.InvalidInputException;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.CounterCodes;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CountersDto;

@Component
public class Utility {

	@Autowired
	private CounterRepository counterRepository;
	@Autowired
	private CounterCodesRepository counterCodeRepository;

	@Autowired
	private ApplicationProperties applicationProperties;

	public static void validateCountryCode(String countryCode) {
		if (!countryCode.matches("[a-zA-Z_]+")) {
			throw new InvalidInputException("Invalid country code ");
		}
	}

	public void validateCounterCodeLength(String counterCode) {
		Logger.info("In validateCounterCodeLength Method " + counterCode);
		if (counterCode.length() >= 20) {
			throw new InvalidInputException("Counter code value cannot exceed 20 digits");
		}
		if (counterCode.length() < 4 || Long.valueOf(counterCode) <= 1000) {
			throw new InvalidInputException("Counter code value should be greater than one thousand");
		}
	}

	public void validateRole(String role) {
		Logger.info("In validateRole Method " + role);
		Logger.info("Role List " + applicationProperties.getRoleList());
		if (!applicationProperties.getRoleList().contains(role)) {
			Logger.info("Role is inValid  " + role);
			throw new InvalidInputException("Invalid role.Please provide valid role ");
		}
	}

	public void validateClientID(Stores store, CASUser casUser) {
		Logger.info("In validateClientID Method StoreCountry-> " + store.getClientID() + "  cas clientID ->"
				+ casUser.getCustomerID());
		if (!store.getClientID().equals(casUser.getCustomerID())) {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}
	}

	public void validateCountry(Stores store, String country) {
		Logger.info("In validateCountry Method StoreCountry-> " + store.getCountry() + "  xCountryCode ->" + country);
		if (!store.getCountry().equals(country)) {
			throw new InvalidInputException("Invalid country code");
		}
	}

	private Utility() {
		super();

	}

	public void checkCounterNameAndPhoneAlreadyExistOrNot(CounterDto dto) {
		List<CountersDto> countersList = counterRepository.findByCounterName(dto.getCounterName(), dto.getStoreId());
		List<CountersDto> counterPhoneList = counterRepository.findByMsisdn(dto.getMsisdn(), dto.getStoreId());
		if (!counterPhoneList.isEmpty()) {
			Logger.builder("saveCounter() method END with Bad Request, Phone Number Already Exist ").info();
			throw new AlreadyExistExceptions(AppConstants.COUNTER_PHONE_ALREADY_EXIST);
		}
		if (!countersList.isEmpty()) {
			Logger.builder("saveCounter() method END with Bad Request Counter name Already Exist ").info();
			throw new AlreadyExistExceptions(AppConstants.COUNTER_NAME_ALREADY_EXIST);
		}
	}

	public Counters setCounterInformation(CounterDto dto, CASUser casUser) {

		Logger.info("Inside setCounterInformation() method " + dto);

		Counters counter = new Counters();
		counter.setCounterName(dto.getCounterName());
		counter.setActive(applicationProperties.getActiveStatus());

		Long autoIncrementedCounterCode = counterRepository.autoIncrementValue(applicationProperties.getDataBaseName(),
				applicationProperties.getCounterTableName());
		counter.setCounterCode(autoIncrementedCounterCode);

		String reference = (dto.getIsReference()).replaceAll("\\s", "");
		counter.setIsReference(reference.equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO);
		counter.setDescription(dto.getDescription());
		counter.setStoreId(dto.getStoreId());
		counter.setCreatedBy(casUser.getUserID());
		counter.setModifiedBy(casUser.getUserID());
		counter.setMsisdn(dto.getMsisdn());
		Logger.info("Return counter object " + counter);
		return counter;
	}

	public void checkProvider(String provider) {
		Logger.info("In checkProvider Method " + provider);
		Logger.info("Provider List " + applicationProperties.getProvider());
		if (!applicationProperties.getProvider().contains(provider)) {
			Logger.info("provider is inValid  " + provider);
			throw new InvalidInputException("Invalid provider.Please provide valid provider ");
		}
	}

	public void checkProviderAlreadyExist(CounterDto dto) {
		Logger.info(
				"In checkProviderAlreadyExist Method " + dto.getCounterCodeType() + " counterId " + dto.getCounterId());
		Logger.info("Provider List " + applicationProperties.getProvider());
		if (!Objects.isNull(dto.getCounterId())) {
			CounterCodes counterCodes = counterCodeRepository.findExistingProvider(dto.getCounterCodeType(),
					dto.getCounterId());
			Logger.info("Check checkProviderAlreadyExist " + counterCodes);
			if (!Objects.isNull(counterCodes)) {
				Logger.info("Provider Is Already Exist " + counterCodes);
				throw new AlreadyExistExceptions("Provider Is Already Exist Please Select Another One");
			}
		}

	}
}
