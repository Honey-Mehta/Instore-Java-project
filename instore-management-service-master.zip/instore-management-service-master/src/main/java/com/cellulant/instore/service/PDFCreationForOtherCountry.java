package com.cellulant.instore.service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.PDFDto;
import com.cellulant.instore.dto.PaymentMethodDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.response.QRCodeCounter;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lowagie.text.DocumentException;

@Component
public class PDFCreationForOtherCountry implements PDFCreation {
	
	private static final String ISOCOUNTRYCODE = "ALL";
	
	@Autowired
	private QRCodeService qrCodeService;
	
	@Autowired
	private ApplicationProperties applicationPropertie;

	@Autowired
	private StoreRepository storeRepository;
	
	@Autowired
	private Gson gson;
	
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired 
	private PDFservice pdfservice;

	@Override
	public @ResponseBody ResponseEntity<InputStreamResource> downLoadPDF(String counterCode,QRCodeCounter counterInfo) throws IOException, DocumentException {
		Logger.info("Download PDF For Other Country");
		Stores store = storeRepository.findStoreById(counterInfo.getStoreId());
		Logger.info("Store is available or not in db " + store);
		if (Objects.isNull(store)) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		}
		
		String url = applicationPropertie.getPayByLinkUrl() + store.getCountry() + "/" + counterCode;
		Logger.info("QRCode Content url "+url);
		PDFDto pdfInfo = getShortCode(counterCode,counterInfo);
		String image = getQrCode(url);
		String shortCode = "*" + pdfInfo.getShortCode() +" * "+counterCode+" *"+pdfInfo.getCurrencyCode()+"#";
		 Map<String, Object> data = new HashMap<>();
		 data.put("url", url);
		 data.put("shortCode", shortCode);
		 data.put("image", image);
		 List<PaymentMethodDto> paymentMethodList = pdfInfo.getPaymentMethodDto();	
         data.put("storeName", store.getStoreName());
		 data.put("logoUrl", paymentMethodList);
		 Logger.info("Data -->> "+data);
		return pdfservice.generatePdfFile("qrcode", data, "qrcode.pdf",counterCode);
	}
	
	private String getQrCode(String url) {
		
		
        byte[] qrCode = qrCodeService.generateQRCode(url, 250, 250);
       
       
        return  Base64.getEncoder().encodeToString(qrCode);
}

 public PDFDto getShortCode(String counterCode,QRCodeCounter counterInfo) {
		Logger.info("getShortCode Method -->>>> "+counterCode);
		Logger.info("rest url -->> "+applicationPropertie.getUssdUrl()+counterCode);
		HttpHeaders headers = new HttpHeaders();
		 headers.set("X-Country-Code", counterInfo.getCountry());
		 HttpEntity<String> http = new HttpEntity<>(null, headers);
		 ResponseEntity<String> getServiceResult = restTemplate
					.exchange(applicationPropertie.getUssdUrl()+counterCode ,HttpMethod.GET,http, String.class);
		Logger.info("Response Coming from Api -->>> "+new Gson().toJson(getServiceResult));
		if (getServiceResult != null) {   
			JSONObject obj = new JSONObject(getServiceResult.getBody());
			Logger.info("Body --->>> "+obj);
			JSONObject dataObj = (JSONObject) obj.get("data");
			Logger.info("data --->>> "+dataObj);
			PDFDto pdf = new PDFDto();
					
			String shortCode = (String) dataObj.get("shortCode");
			String currencyCode = (String) dataObj.get("currencyCode");
			pdf.setShortCode(shortCode);
			pdf.setCurrencyCode(currencyCode);
			JSONArray sportsArray = dataObj.getJSONArray("paymentMethods");
			ArrayList<PaymentMethodDto> data = new Gson().fromJson(sportsArray.toString(),
					 new TypeToken<List<PaymentMethodDto>>(){}.getType());
			Logger.info("Please Print Payment Method -->>> "+gson.toJson(data));
         pdf.setPaymentMethodDto(data);
			return pdf;
		} 
			throw new NotFoundExceptions("Payment Method Not Found");
	}



	@Override
	public String getPdfCreationName() {
		
		return ISOCOUNTRYCODE;
	}

}
