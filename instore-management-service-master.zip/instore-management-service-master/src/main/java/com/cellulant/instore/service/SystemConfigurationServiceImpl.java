package com.cellulant.instore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.DeviceIDRequest;
import com.cellulant.instore.dto.SystemConfigurationDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.MappingDeviceID;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.MappingDeviceIdRepository;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

@Service
public class SystemConfigurationServiceImpl implements SystemConfigurationService {

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private SystemConfigurationRepository systemConfigurationRepository;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private MappingDeviceIdRepository mappingDeviceIdRepository;


	private ResponseEntity<Object> savedSystemConfiguration(SystemConfigurationDto systemConfigurationDto,
			CASUser casUser) {
		Logger.info("saveSystemConfiguration Methoad Start " + new Gson().toJson(systemConfigurationDto));
		SuccessResponse response = null;
		List<SystemConfiguration> systemConfigurationList = systemConfigurationRepository
				.getMerchanthasConfigValueOrNot(systemConfigurationDto.getClientId());
		Logger.info("Checking any System Configuration is Already available for particular client or not"
				+ new Gson().toJson(systemConfigurationList));
		if (systemConfigurationList != null && !systemConfigurationList.isEmpty()) {
			int value = systemConfigurationRepository
					.deactivateSystemConfigurationOnTheBasisOfClientId(systemConfigurationDto.getClientId());
			Logger.info("value " + value);
			if (value >= 1) {
				Logger.info("All previous System Configuration is deactivated");
			} else {
				Logger.info("Old System Configuration is not updated Some issue while executing Query");

			}
		}

		SystemConfiguration systemConfigurationForSms = new SystemConfiguration();
		systemConfigurationForSms.setActive(applicationProperties.getActiveStatus());
		systemConfigurationForSms.setClientId(systemConfigurationDto.getClientId());
		systemConfigurationForSms.setConfigKey(applicationProperties.getConfigKeyForSms());
		systemConfigurationForSms.setConfigValue(systemConfigurationDto.getSendSMS());
		systemConfigurationForSms.setCreatedBy(casUser.getUserID());
		systemConfigurationForSms.setModifiedBy(casUser.getUserID());
		systemConfigurationRepository.save(systemConfigurationForSms);
		Logger.info("Added Sms key value" + new Gson().toJson(systemConfigurationForSms));

		SystemConfiguration systemConfigurationForApp = new SystemConfiguration();
		systemConfigurationForApp.setActive(applicationProperties.getActiveStatus());
		systemConfigurationForApp.setClientId(systemConfigurationDto.getClientId());
		systemConfigurationForApp.setConfigKey(applicationProperties.getConfigKeyForApp());
		systemConfigurationForApp.setConfigValue(systemConfigurationDto.getSendNotification());
		systemConfigurationForApp.setCreatedBy(casUser.getUserID());
		systemConfigurationForApp.setModifiedBy(casUser.getUserID());
		systemConfigurationRepository.save(systemConfigurationForApp);
		Logger.info("Added Notification key value" + new Gson().toJson(systemConfigurationForApp));

		SystemConfiguration systemConfigurationForCallBack = new SystemConfiguration();
		systemConfigurationForCallBack.setActive(applicationProperties.getActiveStatus());
		systemConfigurationForCallBack.setClientId(systemConfigurationDto.getClientId());
		systemConfigurationForCallBack.setConfigKey(applicationProperties.getConfigKeyForCallBack());
		systemConfigurationForCallBack.setConfigValue(systemConfigurationDto.getIsCallBack());
		systemConfigurationForCallBack.setCreatedBy(casUser.getUserID());
		systemConfigurationForCallBack.setModifiedBy(casUser.getUserID());
		systemConfigurationRepository.save(systemConfigurationForCallBack);
		Logger.info("Added callBack key value" + new Gson().toJson(systemConfigurationForCallBack));

		SystemConfiguration systemConfigurationForCallBackUrl = new SystemConfiguration();
		systemConfigurationForCallBackUrl.setActive(applicationProperties.getActiveStatus());
		systemConfigurationForCallBackUrl.setClientId(systemConfigurationDto.getClientId());
		systemConfigurationForCallBackUrl.setConfigKey(applicationProperties.getConfigValueForCallBackUrl());
		systemConfigurationForCallBackUrl.setConfigValue(systemConfigurationDto.getCallBackUrl());
		systemConfigurationForCallBackUrl.setCreatedBy(casUser.getUserID());
		systemConfigurationForCallBackUrl.setModifiedBy(casUser.getUserID());
		systemConfigurationRepository.save(systemConfigurationForCallBackUrl);
		Logger.info("Added callBackUrl key value" + new Gson().toJson(systemConfigurationForCallBackUrl));
		response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
				AppConstants.SYSTEM_CONFIGURATION_ADDED_SUCCESSFULLY, systemConfigurationDto);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	@Override
	public ResponseEntity<Object> saveSystemConfiguration(SystemConfigurationDto systemConfigurationDto,
			CASUser casUser) {
		Logger.info("saveSystemConfiguration Methoad Start " + new Gson().toJson(systemConfigurationDto));
		SuccessResponse response = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("user Is Admin");
			return savedSystemConfiguration(systemConfigurationDto, casUser);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("user Is Customer Checking for Type");
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (userIdForCashier != null) {
				Logger.builder(" saveSystemConfiguration() method END  because User is Cashier Not Authorized User "
						+ new Gson().toJson(response)).info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else if (userIdForStoreManager != null) {
				Logger.builder(
						" saveSystemConfiguration() method END because User is Store manager Not Authorized User "
								+ new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("merchant");
				return savedSystemConfiguration(systemConfigurationDto, casUser);
			}
		}
		Logger.info("User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);

	}

	@Override
	public ResponseEntity<Object> removeSystemConfigurationById(Long systemConfigurationId, CASUser casUser)
			throws NotFoundExceptions {
		Logger.info(
				"removeSystemConfigurationById Methoad Start and  SystemConfiguration Id is " + systemConfigurationId);
		SuccessResponse response = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			SystemConfiguration systemConfiguration = systemConfigurationRepository
					.findSystemConfigurationById(systemConfigurationId);
			if (systemConfiguration != null) {
				int i = systemConfigurationRepository.deleteSystemConfigurationById(systemConfigurationId);
				if (i >= 1) {
					response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
							AppConstants.SYSTEM_CONFIGURATION_DELETED_SUCCESSFULLY, systemConfigurationId);
					Logger.builder("removeSystemConfigurationById() method END " + response.toString()).info();
					return new ResponseEntity<>(response, HttpStatus.OK);
				} else {
					response = new SuccessResponse(true, AppConstants.INTERNAL_ERROR_STATUS_CODE,
							AppConstants.REQUEST_UNABLE_TO_PROCESS, systemConfigurationId);
					Logger.builder("removeSystemConfigurationById() method END with INTERNAL_SERVER_ERROR "
							+ response.toString()).info();
					return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}

			} else {
				Logger.info("user is admin  But there is no Systemconfiguration for this particular Id"
						+ systemConfigurationId);
				throw new NotFoundExceptions(AppConstants.SYSTEM_CONFIGURATION_NOT_FOUND);
			}
		} else {
			Logger.info("user is not admin  Bad Request systemConfigurationId is " + systemConfigurationId);
			response = new SuccessResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
					AppConstants.SYSTEM_CONFIGURATION_ONLY_FOR_ADMIN, null);
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public Page<SystemConfiguration> getSystemConfiguration(CASUser casUser, int page, int size, Long merchantId) {
		Logger.info("getSystemConfiguration Methoad Start " + merchantId);

		Logger.info("Fetching data Using filter");
		Pageable paging = PageRequest.of(page - 1, size);
		Logger.info("Calling Data Base");
		return systemConfigurationRepository.fetchSystemConfigurationByMerchantId(paging, merchantId);

	}
	
	@Override
	public ResponseEntity<Object> saveDeviceId(DeviceIDRequest deviceIDRequest, CASUser casUser) {
		Logger.info("In saveDeviceId Method ");
		SuccessResponse response = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("User is Admin Now ");
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else {
			MappingDeviceID mapping = mappingDeviceIdRepository.findMappingByDeviceId(deviceIDRequest.getDeviceID(), casUser.getUserID(), deviceIDRequest.getRole());
			Logger.info("checking entry for same role and deviceId "+new Gson().toJson(mapping));
			if(mapping!=null) {
				Logger.info("DeviceId  Present  In our DataBase So Not Doing Any Thing "+new Gson().toJson(mapping));
				response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, mapping);
				Logger.info("Added New deviceId in Table and returning Success Response "+new Gson().toJson(mapping));
				return new ResponseEntity<>(response,HttpStatus.OK);
			}else {
				
				MappingDeviceID deviceIdObject =mappingDeviceIdRepository.findMappingByDeviceIdWithAlternativeRole(deviceIDRequest.getDeviceID(), deviceIDRequest.getRole());
				Logger.info("Checking deviceId is already assign to any counter or Not");
				if(deviceIdObject!=null) {
					Logger.info("Yes, deviceId is already assign to  counter");
					int val = mappingDeviceIdRepository.updateMappingDeviceId(deviceIdObject.getMappingID());
					Logger.info("So,deactivating previous assign  deviceId  counter "+val);
					MappingDeviceID mappingObject  = getMappingDeviceIdObject(deviceIDRequest, casUser);
					MappingDeviceID savedMapping = mappingDeviceIdRepository.save(mappingObject);
					response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, savedMapping);
					Logger.info("Now adding  deviceId in Table and returning Success Response "+new Gson().toJson(savedMapping));
					return new ResponseEntity<>(response,HttpStatus.OK);
				} else {
					Logger.info("DeviceId Not Present  In our DataBase So Adding New Entry");
					MappingDeviceID mappingObject  =  getMappingDeviceIdObject(deviceIDRequest, casUser);
					MappingDeviceID savedMapping = mappingDeviceIdRepository.save(mappingObject);
					response =  new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE, savedMapping);
					Logger.info("Added New deviceId in Table and returning Success Response "+new Gson().toJson(savedMapping));
					return new ResponseEntity<>(response,HttpStatus.OK);
				}
				
			}
		}
		
	}
	
	public MappingDeviceID getMappingDeviceIdObject(DeviceIDRequest deviceIDRequest, CASUser casUser) {
		MappingDeviceID mappingObject  =  new MappingDeviceID();
		mappingObject.setActive(applicationProperties.getActiveStatus());
		mappingObject.setDeviceID(deviceIDRequest.getDeviceID());
		mappingObject.setCreatedBy(casUser.getCustomerID());
		mappingObject.setModifiedBy(casUser.getCustomerID());
		mappingObject.setCasUserID(casUser.getUserID());
		mappingObject.setClientID(casUser.getCustomerID());
		mappingObject.setRole(deviceIDRequest.getRole());
		return mappingObject;
	}


}
