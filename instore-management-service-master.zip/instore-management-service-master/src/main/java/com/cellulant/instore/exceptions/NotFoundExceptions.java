package com.cellulant.instore.exceptions;

public class NotFoundExceptions extends RuntimeException {
	
	public NotFoundExceptions(String message, Throwable cause) {
		super(message, cause);
		
	}

	public NotFoundExceptions(String message) {
		super(message);
		
	}

	public NotFoundExceptions(Throwable cause) {
		super(cause);
		
	}

}
