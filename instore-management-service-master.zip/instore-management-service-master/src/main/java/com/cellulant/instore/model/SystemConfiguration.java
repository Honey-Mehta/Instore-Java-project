package com.cellulant.instore.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "systemconfigurations")
@EqualsAndHashCode(callSuper = true)

public class SystemConfiguration extends Actionable implements Serializable {

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "systemConfigurationID",unique = true,nullable = false)
	private Long systemConfigurationId;
	
	@Column(name = "clientID",nullable = false)
	private Long clientId;
	
	@Column(name = "configKey")
	private String configKey;
	
	@Column(name = "configValue")
	private String configValue;
	
	@Column(name = "active")
	private Integer active; 
	
}
