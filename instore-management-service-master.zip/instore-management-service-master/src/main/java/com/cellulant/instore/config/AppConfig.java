package com.cellulant.instore.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.web.client.RestTemplate;

import com.cellulant.instore.utils.ApplicationProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

@EnableRetry
@Configuration
public class AppConfig {
	

	
	@Autowired
	private ApplicationProperties properties;
	
	@Bean 
	public RestTemplate restTemplate() {
		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		httpComponentsClientHttpRequestFactory.setConnectionRequestTimeout(properties.getHttpSocketTimeOut());
		httpComponentsClientHttpRequestFactory.setReadTimeout(properties.getHttpSocketTimeOut());
		return new RestTemplate(httpComponentsClientHttpRequestFactory);
	}

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

}
