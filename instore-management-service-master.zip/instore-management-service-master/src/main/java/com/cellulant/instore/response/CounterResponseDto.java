package com.cellulant.instore.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CounterResponseDto {

	private Long counterId;
	private String counterCode;

	private String msisdn;

	private String counterName;

	private Integer active;

	private Long storeId;

	private String type;

}
