package com.cellulant.instore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.Users;
import com.cellulant.instore.response.MerchantDetail;

public interface UserRepository extends JpaRepository<Users, Long> {

	List<Users> findByUserId(Long userId);

	@Query(value = "SELECT COUNT(*) FROM Users u WHERE u.userId=:userId")
	Long getTotalCountOfUserId(@Param("userId") Long userId);

	@Query(value = "SELECT u.userId FROM Users u WHERE u.emailAddress=:email And u.status=1")
	Long findUserByEmailAddress(@Param("email") String email);

	@Query(value = "SELECT u.userId FROM Users u WHERE u.casUserID=:casUserId And u.roleId=:roleId And u.status=1")
	Long findCasUser(@Param("casUserId") Long casUserId, @Param("roleId") Integer roleId);

	@Query(value = "SELECT u.userId FROM Users u WHERE u.casUserID=:casUserId And u.roleId=:roleId And u.emailAddress=:email")
	Long findUserIdByUserIdAndRoleAndEmail(@Param("casUserId") Long casUserId, @Param("roleId") Integer roleId,
			@Param("email") String email);

	@Query(value = "SELECT u.userId FROM Users u WHERE u.casUserID=:casUserId And u.roleId=:roleId And u.status=1")
	Long findCashier(@Param("casUserId") Long casUserId, @Param("roleId") Integer roleId);

	@Query(value = "select new com.cellulant.instore.response.MerchantDetail(s.storeName,c.counterName,cc.counterCode,u.userId,s.address,s.storeId,c.isReference,s.country) "

			+ "  from Users u inner join CounterAssignment ca On ca.userId=u.userId and ca.active=1"
			+ " inner join Counters c On c.counterId = ca.counterId and c.active=1"
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " inner join Stores s on s.storeId = c.storeId where s.active=1  and u.casUserID=:casUserId")
	MerchantDetail findCashierInfo(@Param("casUserId") Long casUserId);
}
