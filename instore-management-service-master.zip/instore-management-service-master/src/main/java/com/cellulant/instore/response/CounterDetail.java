package com.cellulant.instore.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CounterDetail {
	
	private Long counterId;
	
	
	private String msisdn;
	
	private String counterName;
	
	private String cashierName;

}
