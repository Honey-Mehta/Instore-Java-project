
package com.cellulant.instore.response;


import com.cellulant.instore.utils.AppConstants;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class Response {

    private int statusCode;
    private String message;
    boolean success = false;
    /**
     * Can be a hashmap or list Spring will render a nice Json response :-)
     *
     */
    private Object data;

    public Response(int statCode, String statusDesc) {
        statusCode = statCode;
        message = statusDesc;

        if (statusCode == AppConstants.SUCCESS_STATUS) {
            success = true;
        }
        
    }

    public Response() {
    }

}
