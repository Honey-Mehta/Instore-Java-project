package com.cellulant.instore.service;

import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;

public interface MerchantService {

	ResponseEntity<Object> getMerchantDetailByCounterCode(String counterCode,String xCountry);
	
	ResponseEntity<Object> getCounterInfoByCounterCode(String counterCode,String xCountry);
	
	ResponseEntity<Object> getMerchantDetailOnTheBasisOfClientId(Long clientId);
	
	ResponseEntity<Object> getTotalCounterAndStoresofParticaularClient(Long customerId,CASUser casUser,String xCountryCode);
	
	ResponseEntity<Object> getTotalCashierAndCounterOnTheBasisOfStoreId(Long storeId);
	
	ResponseEntity<Object> getMerchantDetailOnTheBasisOfEmail(String email,Integer page,Integer size,Long storeID,CASUser casUser,String xCountryCode);
}
