package com.cellulant.instore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.StoreAssignment;

public interface StoreAssignmentRepository extends JpaRepository<StoreAssignment, Long>{

	@Query(value = "SELECT sa.storeId FROM StoreAssignment sa WHERE sa.userId=:userId AND sa.active!=0")
	Long findStoreId(@Param("userId")Long userId);
}
