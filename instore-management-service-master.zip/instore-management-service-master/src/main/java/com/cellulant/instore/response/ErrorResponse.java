package com.cellulant.instore.response;

import java.util.HashMap;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString
@NoArgsConstructor
public class ErrorResponse {

	private Boolean success;
	
	private Integer statusCode;
	// General error message about nature of error
	private String message;

	// Specific errors in API request processing
	private HashMap<String, String> details;

	private Object data;
	
}
