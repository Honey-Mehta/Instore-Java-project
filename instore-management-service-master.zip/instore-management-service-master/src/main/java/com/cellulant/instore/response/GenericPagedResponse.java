package com.cellulant.instore.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class GenericPagedResponse<T> {
    boolean success;
    Integer statusCode;
    String message;
    Long size;
    Long totalItems;
    Long totalPages;
    Integer currentPage;
    List<T> data;
}