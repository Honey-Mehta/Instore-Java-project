package com.cellulant.instore.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SystemConfigurationRequest {

	 private Long systemConfigurationId;
	 
	@NotNull(message = "clientId can not be null")
	private Long clientId;
	
	@NotNull(message = "configKey is required")
	@NotEmpty(message = "configKey can not be null")
	private String configKey;
	
	@NotNull(message = "configValue is required")
	@NotEmpty(message = "configValue can not be null")
	private String configValue;
}
