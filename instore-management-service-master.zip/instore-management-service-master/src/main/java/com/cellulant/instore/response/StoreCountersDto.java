package com.cellulant.instore.response;

import com.cellulant.instore.model.IsReference;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StoreCountersDto {
	

	private Long counterId;

	private String counterName;

	private String msisdn;
	
	private String storeName;
	
	private String username;
	
	private String counterCode;
	
	private IsReference isReference;

}
