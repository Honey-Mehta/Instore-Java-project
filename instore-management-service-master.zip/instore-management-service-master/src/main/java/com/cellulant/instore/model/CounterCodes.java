package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "countercodes")
@EqualsAndHashCode(callSuper = true)
@Builder
public class CounterCodes extends Actionable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Long id;

	@Column(name = "counterCode")
	private String counterCode;

	@Column(name = "counterId")
	private Long counterId;

	@Column(name = "counterCodeType")
	private int counterCodeType;

	@Column(name = "country")
	private String country;

	@Column(name = "active")
	private Integer active;

}
