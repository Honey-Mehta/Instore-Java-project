package com.cellulant.instore.model;

public enum IsReference {
	
	YES, NO
	
	

}
