package com.cellulant.instore.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Benchmark;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.StoreDto;
import com.cellulant.instore.response.GenericPagedResponse;
import com.cellulant.instore.response.StoreCounterDetail;
import com.cellulant.instore.response.StoreCounterResponse;
import com.cellulant.instore.response.StoreDetail;
import com.cellulant.instore.response.StoresParam;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;


@Service
public class StoreServiceImpl implements StoreService {

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private SystemConfigurationRepository systemConfigurationRepository;

	@Autowired
	private StoreAssignmentRepository storeAssignmentRepository;

	@Autowired
	private UserRepository userRepository;


	@Override
	public ResponseEntity<Object> findStoreDetail(Long storeId, CASUser casUser) throws NotFoundExceptions {
		Logger.builder(" findStoreDetail() method START " + storeId).info();

		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("user is Admin");
			return findStoreByStoreId(storeId);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("user is Customer checking for Customer Type");
			Long storeManagerId = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			Long cashierId = userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole());
			if (storeManagerId != null) {
				Logger.info("Its a Store Manager");
				return getStoreByIdForStoreManager(storeId, casUser, storeManagerId);
			} else if (cashierId != null) {
				Logger.builder(" findStoreDetail() method END Cashier is Not Authorized ").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("Its a merchant ");
				return getStoreByIdForMerchant(storeId, casUser);

			}

		}

		Logger.info("findStoreDetail() End User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
	}

	private ResponseEntity<Object> getStoreByIdForStoreManager(Long storeId, CASUser casUser, Long userId)
			throws NotFoundExceptions {
		Long storeIdFromStoreAssignment = storeAssignmentRepository.findStoreId(userId);
		Stores stores = storeRepository.findStoreById(storeIdFromStoreAssignment);
		if (stores == null) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		} else {
			Stores store = storeRepository.findStoresByStoreIdAndClientId(stores.getStoreId(), casUser.getCustomerID());
			Logger.info("Checking Store Manager is Accesing his store or other store ");
			if (store != null) {
				Logger.info(" Store Manager is Accesing his store ");
				return findStoreByStoreId(storeId);
			} else {
				Logger.info(
						" getStoreByIdForStoreManager() method END because Store Manager is Not Accesing his store  ");
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}

		}
	}

	private ResponseEntity<Object> getStoreByIdForMerchant(Long storeId, CASUser casUser) {
		Logger.info("Merchant is fetching his stores or other merchant Store");
		Stores store = storeRepository.findStoresByStoreIdAndClientId(storeId, casUser.getCustomerID());
		if (store != null) {
			Logger.info(" merchant is fetching his stores No issue");
			return findStoreByStoreId(storeId);
		} else {
			Logger.info("findStoreDetail() method END merchant is fetching other store Sorry you are unAuthorized");
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}
	}

	private ResponseEntity<Object> findStoreByStoreId(Long storeId) {
		Long start = Benchmark.start();
		Logger.builder(" findStoreDetail() method START " + storeId).info();
		List<StoreDetail> storeDetailList = storeRepository.fetchstoresById(storeId);
		StoreCounterDetail storeCounterDetail = new StoreCounterDetail();
		List<Counters> counterList = new ArrayList<>();
		for (StoreDetail storeDetail : storeDetailList) {
			storeCounterDetail.setStoreId(storeDetail.getStoreId());
			storeCounterDetail.setMobile(storeDetail.getStoreMsisdn());
			storeCounterDetail.setStoreName(storeDetail.getStoreName());
			Counters counter = new Counters();
			counter.setCounterName(storeDetail.getCounterName());
			counter.setMsisdn(storeDetail.getCounterMsisdn());
			counter.setStoreId(storeDetail.getStoreId());
			counterList.add(counter);
		}
		storeCounterDetail.setCounterList(counterList);
		SuccessResponse reponse = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
				AppConstants.STORE_FETCH_SUCCESSFULLY, storeCounterDetail);
		Logger.builder("findStoreDetail() method END " + reponse.toString()).start(start).info();
		return new ResponseEntity<>(reponse, HttpStatus.OK);

	}

	@Override
	public int deleteStoreById(Long storeId) {

		return storeRepository.deleteStoreById(storeId);
	}

	private ResponseEntity<Object> saveStores(StoreDto storeDto, CASUser casUser) {
		Logger.builder(" createStores() method START " + storeDto.getStoreName()).info();
		SuccessResponse response = null;
		List<Stores> storesList = storeRepository.findByStoreName(storeDto.getStoreName(), casUser.getCustomerID());
		Logger.builder("Check store list for same Store name  -->>> " + new Gson().toJson(storesList)).info();
		if (storesList.isEmpty()) {
			List<SystemConfiguration> systemConfigurationList = systemConfigurationRepository
					.getMerchanthasConfigValueOrNot(casUser.getCustomerID());
			Logger.builder("Check merchant is allowed for Sms And App Notification -->>> "
					+ new Gson().toJson(systemConfigurationList)).info();
			if (systemConfigurationList.isEmpty()) {
				addSystemConfiguration(casUser.getCustomerID(), casUser.getUserID());
			}
			Stores store = new Stores();
			store.setDescription(storeDto.getDescription());
			store.setClientID(casUser.getCustomerID());
			store.setStoreName(storeDto.getStoreName());
			store.setStoreCode(casUser.getCustomerCode());
			store.setCity(storeDto.getCity());
			store.setAddress(storeDto.getAddress());
			store.setCountry(storeDto.getCountryID());
			store.setActive(applicationProperties.getActiveStatus());
			store.setCreatedBy(casUser.getUserID());
			store.setModifiedBy(casUser.getUserID());
			Stores savedStore = storeRepository.save(store);

			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.STORE_ADDED_SUCCESSFULLY,
					savedStore);
			Logger.builder("saveStore() method END " + response.toString()).info();
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			Logger.builder("saveStore() method END ").info();
			throw new AlreadyExistExceptions(AppConstants.STORE_NAME_ALREADY_EXIST1 + storeDto.getStoreName()
					+ AppConstants.STORE_NAME_ALREADY_EXIST2);
		}

	}

	@Override
	public ResponseEntity<Object> createStores(StoreDto storeDto, CASUser casUser) {
		Logger.builder(" createStores() method START " + storeDto.getStoreName()).info();
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.builder(" createStores() method END Its Admin Not Authorized User admin ").info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Checking which type of Customer");
			Long cashierId = userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole());
			Long storeManagerId = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (storeManagerId != null) {
				Logger.builder(" createStores() method END Store-Manager Not Authorized User for Store Manager ")
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else if (cashierId != null) {
				Logger.builder(" createStores() method END User is cashier Not Authorized User cashier ").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("Its Merchant");
				return saveStores(storeDto, casUser);
			}
		}

		Logger.info("createStores() User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
	}

	private void addSystemConfiguration(Long clientId, Long userId) {
		Logger.builder(" addSystemConfiguration() method START UserId is " + userId + " : clientId " + clientId).info();
		try {
			SystemConfiguration systemConfigurationForSms = new SystemConfiguration();
			systemConfigurationForSms.setActive(applicationProperties.getActiveStatus());
			systemConfigurationForSms.setClientId(clientId);
			systemConfigurationForSms.setConfigKey(applicationProperties.getConfigKeyForSms());
			systemConfigurationForSms.setConfigValue(applicationProperties.getConfigValueForSms());
			systemConfigurationForSms.setCreatedBy(userId);
			systemConfigurationForSms.setModifiedBy(userId);
			systemConfigurationRepository.save(systemConfigurationForSms);

			SystemConfiguration systemConfigurationForApp = new SystemConfiguration();
			systemConfigurationForApp.setActive(applicationProperties.getActiveStatus());
			systemConfigurationForApp.setClientId(clientId);
			systemConfigurationForApp.setConfigKey(applicationProperties.getConfigKeyForApp());
			systemConfigurationForApp.setConfigValue(applicationProperties.getConfigValueForApp());
			systemConfigurationForApp.setCreatedBy(userId);
			systemConfigurationForApp.setModifiedBy(userId);
			systemConfigurationRepository.save(systemConfigurationForApp);

			Logger.builder("addSystemConfiguration() method End").info();
		} catch (Exception e) {

			Logger.builder(e.getMessage()).error();
		}

	}

	private ResponseEntity<Object> editStoresInfo(StoreDto storeDto, CASUser casUser) throws NotFoundExceptions {
		Logger.builder(" updateStoresInfo() method START " + storeDto.getStoreName()).info();
		SuccessResponse response = null;
		List<Stores> store = storeRepository.findByStoreId(storeDto.getStoreId());
		if (store.isEmpty()) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		}
		Stores storeDbData = storeRepository.findStoreById(storeDto.getStoreId());
		if (storeDbData != null) {
			storeDbData.setStoreId(storeDbData.getStoreId());
			storeDbData.setClientID(storeDbData.getClientID());
			storeDbData
					.setCountry(storeDto.getCountryID() != null ? storeDto.getCountryID() : storeDbData.getCountry());
			storeDbData.setCity(storeDto.getCity() != null ? storeDto.getCity() : storeDbData.getCity());
			storeDbData.setAddress(storeDto.getAddress() != null ? storeDto.getAddress() : storeDbData.getAddress());
			storeDbData.setActive(storeDto.getActive() != null ? storeDto.getActive() : storeDbData.getActive());
			storeDbData.setDescription(
					storeDto.getDescription() != null ? storeDto.getDescription() : storeDbData.getDescription());
			storeDbData.setStoreName(
					storeDto.getStoreName() != null ? storeDto.getStoreName() : storeDbData.getStoreName());
			storeDbData.setStoreCode(storeDbData.getStoreCode());
			storeDbData.setDateModified(new Date());
			storeDbData.setModifiedBy(casUser.getUserID());
			storeDbData.setDateCreated(storeDbData.getDateCreated());
			storeDbData.setCreatedBy(storeDbData.getCreatedBy());
			storeRepository.save(storeDbData);
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.STORE_UPDATED_SUCCESSFULLY,
					storeDto);
			Logger.builder(" updateStoresInfo() method END " + new Gson().toJson(response)).info();
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		Logger.builder(" updateStoresInfo() method END " + new Gson().toJson(response)).info();
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
	}

	@Override
	public ResponseEntity<Object> updateStoresInfo(StoreDto storeDto, CASUser casUser) throws NotFoundExceptions {
		Logger.builder(" updateStoresInfo() method START " + storeDto.getStoreName()).info();
		SuccessResponse response = null;

		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.builder(" updateStoresInfo() method END Not Authorized User Admin " + new Gson().toJson(response))
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Checking which type of Customer");
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			Long storeManagerId = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (storeManagerId != null) {
				Stores store = storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(),
						casUser.getCustomerID());
				if (store != null) {
					return editStoresInfo(storeDto, casUser);
				} else {
					Logger.builder(
							" updateStoresInfo() method END user is Store Manager Not Authorized User update other user store info "
									+ new Gson().toJson(response))
							.info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				}

			} else if (userIdForCashier != null) {
				Logger.builder(" updateStoresInfo() method END Not Authorized User " + new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("Its Marchant");
				Stores store = storeRepository.findStoresByStoreIdAndClientId(storeDto.getStoreId(),
						casUser.getCustomerID());
				if (store != null) {
					return editStoresInfo(storeDto, casUser);
				} else {
					Logger.builder(
							" updateStoresInfo() method END user is merchant Not Authorized User merchant updateing other store info "
									+ new Gson().toJson(response))
							.info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				}
			}
		}
		Logger.info("updateStoresInfo() User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);

	}

	@Override
	public ResponseEntity<Object> fetchStores(CASUser casUser,String xCountryCode) {
		Logger.builder(" fetchStores() method START " + new Gson().toJson(casUser)).info();
		SuccessResponse response = null;
		List<StoresParam> storeParamList = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			storeParamList = storeRepository.fetchStoresForAdminWithoutPagination(xCountryCode);
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
					storeParamList);
			Logger.builder(" fetchStores() method End with Success Response for Admin " + new Gson().toJson(response))
					.info();
			return new ResponseEntity<>(response, HttpStatus.OK);

		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Now Checking which type of user it is");
			Long userId = userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole());
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			if (userId != null) {
				Logger.info("Its a store Manager" + userIdForCashier);
				Long storeId = storeAssignmentRepository.findStoreId(userId);
				storeParamList = storeRepository.findStoresForStoresManagerWithoutPagination(storeId,xCountryCode);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						storeParamList);
				Logger.builder(" getStoresWithoutPagination() method End with Success Response for Store Manager"
						+ new Gson().toJson(response)).info();
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else if (userIdForCashier != null) {
				Logger.builder(" fetchStoresAndCountersCount() method END Not Authorized User ").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.builder(" user is Merchant").info();
				storeParamList = storeRepository.fetchStoresForCustomerWithoutPagination(casUser.getCustomerID(),xCountryCode);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						storeParamList);
				Logger.builder(
						" fetchStores() method End with Success Response for merchant" + new Gson().toJson(response))
						.info();
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		}

		Logger.info("fetchStores() User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
	}

	@Override
	public ResponseEntity<Object> fetchStoresWithPagination(String searchStores, int page, int size, CASUser casUser,
			String xCountryCode, Long casUserId) {
		Logger.builder(" fetchStoresWithPagination() method START " + xCountryCode).info();
		SuccessResponse response = null;
		Pageable paging = PageRequest.of(page - 1, size);
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Page<StoresParam> storeListForAdmin = getAdminData(searchStores, xCountryCode, casUserId,
					paging);
			GenericPagedResponse<StoresParam> pagingResponse = GenericPagedResponse.<StoresParam>builder().success(true)
					.statusCode(AppConstants.SUCCESS_STATUS).message(AppConstants.SUCCESS_MESSAGE).size((long) size)
					.totalItems(storeListForAdmin.getTotalElements())
					.totalPages((long) storeListForAdmin.getTotalPages()).currentPage(page)
					.data(storeListForAdmin.getContent()).build();
			Logger.info("fetchStoresWithPagination() method End user is ADMIN returning Value "
					+ new Gson().toJson(pagingResponse));
			return new ResponseEntity<>(pagingResponse, HttpStatus.OK);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Long userId = userRepository.findCasUser(casUser.getUserID(), applicationProperties.getStoreManagerRole());
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			if (userId != null) {
				Logger.info("Its a store Manager");
				Long storeId = storeAssignmentRepository.findStoreId(userId);
				Stores stores = storeRepository.findStoreById(storeId);
				if (stores == null) {
					response = new SuccessResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
							AppConstants.STORE_NOT_FOUND, null);
					return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
				} else {
					Page<StoresParam> storeListForStoreManager = storeRepository.findStoresForStoresManager(paging,
							storeId);
					GenericPagedResponse<StoresParam> pagingResponse = GenericPagedResponse.<StoresParam>builder()
							.success(true).statusCode(AppConstants.SUCCESS_STATUS).message(AppConstants.SUCCESS_MESSAGE)
							.size((long) size).totalItems(storeListForStoreManager.getTotalElements())
							.totalPages((long) storeListForStoreManager.getTotalPages()).currentPage(page)
							.data(storeListForStoreManager.getContent()).build();
					Logger.info("fetchStoresWithPagination() method End user is StoreManager returning Value "
							+ new Gson().toJson(pagingResponse));
					return new ResponseEntity<>(pagingResponse, HttpStatus.OK);
				}
			} else if (userIdForCashier != null) {
				Logger.builder(" fetchStoresWithPagination() method END User is cashier Not Authorized User ").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.builder(" user is Merchant").info();
				Page<StoresParam> storeListForMerchant = getmerchantData(searchStores, casUser,
						xCountryCode, paging);
				GenericPagedResponse<StoresParam> pagingResponse = GenericPagedResponse.<StoresParam>builder()
						.success(true).statusCode(AppConstants.SUCCESS_STATUS).message(AppConstants.SUCCESS_MESSAGE)
						.size((long) size).totalItems(storeListForMerchant.getTotalElements())
						.totalPages((long) storeListForMerchant.getTotalPages()).currentPage(page)
						.data(storeListForMerchant.getContent()).build();
				Logger.info("fetchStoresWithPagination() method End user is Merchant returning Value "
						+ new Gson().toJson(pagingResponse));
				return new ResponseEntity<>(pagingResponse, HttpStatus.OK);
			}

		}
		Logger.info("fetchStoresWithPagination() User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
	}

	private Page<StoresParam> getmerchantData(String searchStores,  CASUser casUser,
			String xCountryCode, Pageable paging) {
		if (searchStores.isEmpty()) {
			if (xCountryCode != null && !xCountryCode.isEmpty()) {
				Logger.builder("Without Filter Stores for Customer and with countryCode and Without Any Filter").info();
				Page<StoresParam> storesForMerchant = storeRepository.fetchStores(casUser.getCustomerID(), paging,
						xCountryCode);

				Logger.info("getmerchantData() method End user is Merchant returning Value "
						+ new Gson().toJson(storesForMerchant));
				return storesForMerchant;
			} else {
				Logger.builder("Without Filter Stores for Customer and without countryCode and Without Any Filter")
						.info();
				Page<StoresParam> storesForMerchant = storeRepository
						.fetchStoresWithoutXcountryCode(casUser.getCustomerID(), paging);
				Logger.info("fetchStoresWithPagination() method End user is Merchant returning Value "
						+ new Gson().toJson(storesForMerchant));
				return storesForMerchant;
			}

		} else {
			if (xCountryCode != null && !xCountryCode.isEmpty()) {
				Logger.builder(" Customer and with countryCode and With Filter" + searchStores).info();
				Page<StoresParam> storesForMerchantWithFilters = storeRepository.fetchStoresByFilter(searchStores,
						casUser.getCustomerID(), paging, xCountryCode);
				Logger.info(
						"fetchStoresWithPagination() method End user is Merchant and filter is apply returning Value "
								+ new Gson().toJson(storesForMerchantWithFilters));
				return storesForMerchantWithFilters;
			} else {
				Logger.builder(" Customer and without countryCode and With Filter" + searchStores).info();
				Page<StoresParam> storesForMerchantWithFilters = storeRepository
						.fetchStoresByFilterWithoutXcountryCode(searchStores, casUser.getCustomerID(), paging);
				Logger.info(
						"fetchStoresWithPagination() method End user is Merchant and filter is apply returning Value "
								+ new Gson().toJson(storesForMerchantWithFilters));
				return storesForMerchantWithFilters;
			}
		}
	}

	private Page<StoresParam> getAdminData(String searchStores, String xCountryCode, Long casUserId,
			Pageable paging) {
		Logger.builder(" user is Admin").info();

		if (searchStores.isEmpty()) {
			return getAdminDataWithoutFilter( xCountryCode, casUserId, paging);
		} else {

			if (xCountryCode != null && !xCountryCode.isEmpty()) {
				if (casUserId != null) {
					Page<StoresParam> storesForAdminWithFilters = storeRepository
							.fetchStoresByFilterForAdminWithCasUserId(searchStores, paging, xCountryCode, casUserId);
					Logger.info("fetchStoresWithPagination() method End user is Admin returning Value yes "
							+ new Gson().toJson(storesForAdminWithFilters));
					return storesForAdminWithFilters;
				} else {
					Logger.builder("With Filter Stores for Admin and with countryCode Filter ").info();
					Page<StoresParam> storesForAdminWithFilters = storeRepository
							.fetchStoresByFilterForAdmin(searchStores, paging, xCountryCode);
					Logger.info("fetchStoresWithPagination() method End user is Admin returning Value yes "
							+ new Gson().toJson(storesForAdminWithFilters));
					return storesForAdminWithFilters;
				}

			} else {
				Logger.builder("With Filter Stores for Admin and without countryCode Filter ").info();
				Page<StoresParam> storesForAdminWithFilters = storeRepository
						.fetchStoresByFilterForAdminWithoutXcountryCode(searchStores, paging);
				Logger.info("fetchStoresWithPagination() method End user is Admin returning Value "
						+ new Gson().toJson(storesForAdminWithFilters));
				return storesForAdminWithFilters;
			}
		}

	}

	private Page<StoresParam> getAdminDataWithoutFilter(String xCountryCode, Long casUserId,
			Pageable paging) {

		if (xCountryCode != null && !xCountryCode.isEmpty()) {
			if (casUserId != null) {
				Logger.builder("Without Filter Stores for Admin and with countryCode and with casUserId ").info();
				Page<StoresParam> storesForAdmin = storeRepository.fetchStoresForAdminWithCasId(paging, xCountryCode,
						casUserId);
				Logger.info("fetchStoresWithPagination() method End user is Admin returning Value "
						+ new Gson().toJson(storesForAdmin));
				return storesForAdmin;
			} else {
				Logger.builder("Without Filter Stores for Admin and with countryCode  ").info();
				Page<StoresParam> storesForAdmin = storeRepository.fetchStoresForAdmin(paging, xCountryCode);
				Logger.info("fetchStoresWithPagination() method End user is Admin or returning Value "
						+ new Gson().toJson(storesForAdmin));
				return storesForAdmin;
			}

		} else {
			Logger.builder("Without Filter Stores for Admin and without countryCode Filter ").info();
			Page<StoresParam> storesForAdmin = storeRepository.fetchStoresForAdminWithOutxCountryCode(paging);
			Logger.info("fetchStoresWithPagination() method End user is Admin and  returning Value "
					+ new Gson().toJson(storesForAdmin));
			return storesForAdmin;
		}

	}

	@Override
	public ResponseEntity<Object> fetchStoresAndCounter(CASUser casUser, String userRole) {
		Logger.info("fetchStoresAndCounter Method Start -->> " + userRole);
		SuccessResponse response = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("User is Admin in fetchStoresAndCounter Method");
			List<StoreCounterResponse> storeCounterList = storeRepository.fetchStoresCountersForAdmin();
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
					storeCounterList);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is  Customer in fetchStoresAndCounter Method() -->>>" + userRole);
			userRole = userRole.replaceAll("\\s", "");
			if (userRole.equals(applicationProperties.getCashierRoleName())) {
				Logger.info("Its cashoier or ");
				List<StoreCounterResponse> storeCounterList = storeRepository
						.findStoresCounterForCashier(casUser.getUserID());
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						storeCounterList);
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else if (userRole.equals(applicationProperties.getStoreManagerRoleName())) {
				Logger.info("User is Store manager " + userRole);
				Long userId = userRepository.findCasUser(casUser.getUserID(),
						applicationProperties.getStoreManagerRole());
				Long storeId = storeAssignmentRepository.findStoreId(userId);
				Logger.info("StoreId " + storeId + " userId " + casUser.getUserID());
				List<StoreCounterResponse> storeCounterList = storeRepository
						.findStoresCounterForStoresManager(storeId);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						storeCounterList);
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				Logger.info("User is Customer  " + userRole);
				List<StoreCounterResponse> storeCounterList = storeRepository
						.fetchStoresForCustomer(casUser.getCustomerID());
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						storeCounterList);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		}

		Logger.info("fetchStoresAndCounter() User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
	}

}
