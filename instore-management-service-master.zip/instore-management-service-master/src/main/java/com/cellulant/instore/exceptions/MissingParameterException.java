package com.cellulant.instore.exceptions;

public class MissingParameterException extends RuntimeException{
    public MissingParameterException(String message) {
        super(message);
    }
}
