package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "merchantnotification")
@EqualsAndHashCode(callSuper = true)
public class MerchantNotification extends Actionable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "merchantNotificationID",unique = true,nullable = false)
	private Long merchantNotificationId;
	
	@Column(name = "beepTransactionId")
	private String beepTransactionId;
	
	@Column(name = "counterID",nullable = false)
	private Long counterId;
	
	@Column(name = "userID",nullable = false)
	private Long userId;
	
	@Column(name = "notificationTypeID",nullable = true)
	private  Long notificationTypeId;
	
	@Column(name = "reference")
	private String reference;
	
	@Column(name = "reversalID")
	private Long reversalId;
	
	@Column(name ="clientID")
	private Long clientId;
	
	@Column(name = "amount")
	private Double amount;
	
	@Column(name = "beepStatus",nullable = false)
	private Integer beepStatus;
	
	@Column(name = "narration")
	private String narration;
	
	@Column(name = "counterCode",nullable = false)
	private Long counterCode;

}
