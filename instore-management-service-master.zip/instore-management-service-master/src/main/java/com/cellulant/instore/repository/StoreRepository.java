package com.cellulant.instore.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.Stores;
import com.cellulant.instore.response.StoreCounterResponse;
import com.cellulant.instore.response.StoreDetail;
import com.cellulant.instore.response.StoresParam;

public interface StoreRepository extends JpaRepository<Stores, Long> {

	public final String SELECT_STATEMENT = "select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)";
	public final String LEFT_STATEMENT = " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0";
	public final String LEFT_JOIN_WITH_USER = " left join Users u on u.userId=sa.userId";
	public final String FROM_STATEMENT = " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0";
	String FETCH_ALL_STORES = SELECT_STATEMENT + FROM_STATEMENT + LEFT_STATEMENT + LEFT_JOIN_WITH_USER
			+ " where s.active !=0 and  s.clientID=:clientId and s.country=:countryIso group by s.storeId ";

	@Query(FETCH_ALL_STORES)
	Page<StoresParam> fetchStores(@Param("clientId") Long clientId, Pageable pageable,
			@Param("countryIso") String countryIso);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName) "
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0 "
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId"
			+ " where s.active !=0 and  s.clientID=:clientId group by s.storeId ")
	Page<StoresParam> fetchStoresWithoutXcountryCode(@Param("clientId") Long clientId, Pageable pageable);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId  and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId where s.active !=0 and s.country=:countryIso group by s.storeId  ")
	Page<StoresParam> fetchStoresForAdmin(Pageable pageable, @Param("countryIso") String countryIso);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId  and c.active!=0"
			+ "  left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId where s.active !=0 and s.country=:countryIso and s.clientID=:casUserId group by s.storeId ")

	Page<StoresParam> fetchStoresForAdminWithCasId(Pageable pageable, @Param("countryIso") String countryIso,
			@Param("casUserId") Long casUserId);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId  and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId where s.active !=0 group by s.storeId  ")
	Page<StoresParam> fetchStoresForAdminWithOutxCountryCode(Pageable pageable);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId  and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId" + " left join Users u on u.userId=sa.userId"
			+ " where s.storeId=:storeId and s.active!=0")
	Page<StoresParam> findStoresForStoresManager(Pageable pageable, @Param("storeId") Long storeId);

	String FETCH_STOREBY_FILTER = SELECT_STATEMENT + FROM_STATEMENT + LEFT_STATEMENT + LEFT_JOIN_WITH_USER
			+ " where (s.clientID=:clientId) and s.country=:countryIso and (s.active !=0) and (s.city LIKE %:searchStores% or s.country LIKE %:searchStores% or s.address LIKE %:searchStores% or s.storeName LIKE %:searchStores% or c.msisdn LIKE %:searchStores%) "
			+ " group by s.storeId ";

	@Query(FETCH_STOREBY_FILTER)
	Page<StoresParam> fetchStoresByFilter(@Param("searchStores") String searchStores, @Param("clientId") Long clientId,
			Pageable pageable, @Param("countryIso") String countryIso);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName) "
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId"
			+ " where (s.clientID=:clientId) and (s.active !=0) and (s.city LIKE %:searchStores% or s.country LIKE %:searchStores% or s.address LIKE %:searchStores% or s.storeName LIKE %:searchStores% or c.msisdn LIKE %:searchStores%) "
			+ " group by s.storeId ")
	Page<StoresParam> fetchStoresByFilterWithoutXcountryCode(@Param("searchStores") String searchStores,
			@Param("clientId") Long clientId, Pageable pageable);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId"
			+ " where  (s.active !=0) and s.country=:countryIso and (s.city LIKE %:searchStores% or s.country LIKE %:searchStores% or s.address LIKE %:searchStores% or s.storeName LIKE %:searchStores% or c.msisdn LIKE %:searchStores%) "
			+ " group by s.storeId")
	Page<StoresParam> fetchStoresByFilterForAdmin(@Param("searchStores") String searchStores, Pageable pageable,
			@Param("countryIso") String countryIso);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId"
			+ " where  (s.active !=0) and s.country=:countryIso and s.clientID=:casUserId and (s.city LIKE %:searchStores% or s.country LIKE %:searchStores% or s.address LIKE %:searchStores% or s.storeName LIKE %:searchStores% or c.msisdn LIKE %:searchStores%) "
			+ " group by s.storeId")
	Page<StoresParam> fetchStoresByFilterForAdminWithCasUserId(@Param("searchStores") String searchStores,
			Pageable pageable, @Param("countryIso") String countryIso, @Param("casUserId") Long casUserId);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId and sa.active!=0"
			+ " left join Users u on u.userId=sa.userId "
			+ " where  (s.active !=0)  and (s.city LIKE %:searchStores% or s.country LIKE %:searchStores% or s.address LIKE %:searchStores% or s.storeName LIKE %:searchStores% or c.msisdn LIKE %:searchStores%) "
			+ " group by s.storeId ")
	Page<StoresParam> fetchStoresByFilterForAdminWithoutXcountryCode(@Param("searchStores") String searchStores,
			Pageable pageable);

	String FETCH_STORES_BY_ID = "select new com.cellulant.instore.response.StoreDetail( s.storeId ,s.storeName,c.msisdn ,c.counterName,c.msisdn)"
			+ "FROM Stores s Left join Counters c on c.storeId=s.storeId where s.storeId =:storeId and (s.active !=0)";

	@Query(FETCH_STORES_BY_ID)
	List<StoreDetail> fetchstoresById(@Param("storeId") Long storeId);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId "
			+ " left join StoreAssignment sa on sa.storeId=s.storeId"
			+ " left join Users u on u.userId=sa.userId where s.active !=0 AND s.country=:xCountryCode group by s.storeId")
	List<StoresParam> fetchStoresForAdminWithoutPagination(@Param("xCountryCode") String xCountryCode);

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId "
			+ " left join StoreAssignment sa on sa.storeId=s.storeId"
			+ " left join Users u on u.userId=sa.userId where s.active !=0 and s.clientID=:clientId AND s.country=:xCountryCode group by s.storeId")
	List<StoresParam> fetchStoresForCustomerWithoutPagination(@Param("clientId") Long clientId,
			@Param("xCountryCode") String xCountryCode);

	@Query("select new com.cellulant.instore.response.StoreCounterResponse(s.storeId ,s.storeName,c.counterId,c.counterName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId "
			+ " where s.active !=0 and s.clientID=:clientId and c.active!=0")
	List<StoreCounterResponse> fetchStoresForCustomer(@Param("clientId") Long clientId);

	@Query("select new com.cellulant.instore.response.StoreCounterResponse(s.storeId ,s.storeName,c.counterId,c.counterName)"
			+ " FROM Stores  s Left join Counters c on c.storeId=s.storeId "
			+ " where s.active !=0 and c.active!=0")
	List<StoreCounterResponse> fetchStoresCountersForAdmin();

	@Query("select new com.cellulant.instore.response.StoresParam(s.storeId ,s.storeName,s.city ,s.address ,c.msisdn ,s.country,count(c.storeId) as totalCounter,u.fullName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId" + " left join Users u on u.userId=sa.userId"
			+ " where s.storeId=:storeId AND s.country=:xCountryCode ")
	List<StoresParam> findStoresForStoresManagerWithoutPagination(@Param("storeId") Long storeId,
			@Param("xCountryCode") String xCountryCode);

	@Query("select new com.cellulant.instore.response.StoreCounterResponse(s.storeId ,s.storeName,c.counterId,c.counterName)"
			+ " FROM Users u join CounterAssignment ca on ca.userId=u.userId and ca.active!=0"
			+ " inner join Counters c on c.counterId=ca.counterId and c.active!=0"
			+ " inner join Stores s on s.storeId=c.storeId and s.active!=0" + " where u.casUserID=:casUserId")
	List<StoreCounterResponse> findStoresCounterForCashier(@Param("casUserId") Long casUserId);

	@Query("select new com.cellulant.instore.response.StoreCounterResponse(s.storeId ,s.storeName,c.counterCode,c.counterName)"
			+ " FROM Stores s Left join Counters c on c.storeId=s.storeId and c.active!=0"
			+ " left join StoreAssignment sa on sa.storeId=s.storeId" + " left join Users u on u.userId=sa.userId"
			+ " where s.storeId=:storeId ")
	List<StoreCounterResponse> findStoresCounterForStoresManager(@Param("storeId") Long storeId);

	@Transactional
	@Modifying
	@Query("update Stores s set s.active=0 where s.storeId=:storeId")
	int deleteStoreById(@Param("storeId") Long storeId);

	@Query("select s from Stores s where s.storeId=:storeId AND s.active !=0")
	List<Stores> findByStoreId(@Param("storeId") Long storeId);

	@Query(value = "select COUNT(*) FROM Counters c WHERE storeId=:storeId AND c.active !=0")
	Long totalCounters(@Param("storeId") Long storeId);

	@Query(value = "select COUNT(*) FROM Counters c WHERE storeId=:storeId AND c.active !=0")
	Long totalCountersForAdmin(@Param("storeId") Long storeId);

	@Query(value = "select COUNT(ca.counterAssignmentId) FROM CounterAssignment ca WHERE ca.counterId in (select c.counterId FROM Counters c WHERE c.storeId=:storeId And c.active !=0) And ca.active !=0")
	Long totalCashierOfCounter(@Param("storeId") Long storeId);

	@Query(value = "SELECT s FROM Stores s WHERE s.clientID=:clientId AND s.storeName=:storeName AND s.active !=0")
	List<Stores> findByStoreName(@Param("storeName") String storeName, @Param("clientId") Long clientId);

	@Query("select s from Stores s where s.storeId=:storeId AND s.active !=0")
	Stores findStoreById(@Param("storeId") Long storeId);

	@Query("select s from Stores s where s.storeId=:storeId AND s.active !=0 and s.clientID=:clientId")
	Stores findStoresByStoreIdAndClientId(@Param("storeId") Long storeId, @Param("clientId") Long clientId);

}
