package com.cellulant.instore.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.response.CounterInfo;
import com.cellulant.instore.response.CountersDto;
import com.cellulant.instore.response.QRCodeCounter;
import com.cellulant.instore.response.StoreCountersDto;

public interface CounterRepository extends JpaRepository<Counters, Long> {

	@Query(value = "select new com.cellulant.instore.response.StoreCountersDto(c.counterId,c.counterName,c.msisdn,s.storeName,u.username,cc.counterCode,c.isReference)"
			+ " from Stores s INNER JOIN  Counters c ON c.storeId=s.storeId and c.active!=0 "
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " LEFT JOIN CounterAssignment ca ON ca.counterId=c.counterId and  ca.active=1"
			+ " LEFT JOIN Users u On u.userId=ca.userId And u.status=1 WHERE c.storeId=:storeID AND s.clientID=:clientId AND s.active !=0")
	Page<StoreCountersDto> findByCountersStoreId(Pageable pageable, @Param("storeID") Long storeID,
			@Param("clientId") Long clientId);

	@Query(value = "select new com.cellulant.instore.response.StoreCountersDto(c.counterId,c.counterName,c.msisdn,s.storeName,u.username,cc.counterCode,c.isReference)"
			+ " from Stores s INNER JOIN  Counters c ON c.storeId=s.storeId and c.active!=0 "
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " LEFT JOIN CounterAssignment ca ON ca.counterId=c.counterId and  ca.active=1"
			+ " LEFT JOIN Users u On u.userId=ca.userId WHERE c.storeId=:storeID AND s.active !=0")
	Page<StoreCountersDto> findByCountersStoreIdForAdmin(@Param("storeID") Long storeID, Pageable pageable);

	@Query(value = "select new com.cellulant.instore.response.StoreCountersDto(c.counterId,c.counterName,c.msisdn,s.storeName,u.username,cc.counterCode,c.isReference)"
			+ " from Stores s INNER JOIN  Counters c ON c.storeId=s.storeId and c.active!=0 "
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " LEFT JOIN CounterAssignment ca ON ca.counterId=c.counterId and  ca.active=1"
			+ " LEFT JOIN Users u On u.userId=ca.userId"
			+ " WHERE (c.storeId=:storeID)  AND (s.clientID=:clientId) AND (s.active !=0) AND (u.username LIKE %:searchCounters% OR c.counterName LIKE %:searchCounters% OR c.msisdn LIKE %:searchCounters% OR s.storeName LIKE %:searchCounters%)")
	Page<StoreCountersDto> fetchCounterByFilter(@Param("storeID") Long storeID,
			@Param("searchCounters") String searchCounters, @Param("clientId") Long clientId, Pageable pageable);

	@Query(value = "select new com.cellulant.instore.response.StoreCountersDto(c.counterId,c.counterName,c.msisdn,s.storeName,u.username,cc.counterCode,c.isReference)"
			+ " from Stores s INNER JOIN  Counters c ON c.storeId=s.storeId and c.active!=0 "
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " LEFT JOIN CounterAssignment ca ON ca.counterId=c.counterId and  ca.active=1"
			+ " LEFT JOIN Users u On u.userId=ca.userId"
			+ " WHERE (c.storeId=:storeID) AND  (s.active !=0) AND (u.username LIKE %:searchCounters% OR c.counterName LIKE %:searchCounters% OR c.msisdn LIKE %:searchCounters% OR s.storeName LIKE %:searchCounters%)")
	Page<StoreCountersDto> fetchCounterByFilterForAdmin(@Param("storeID") Long storeID,
			@Param("searchCounters") String searchCounters, Pageable pageable);



	@Query(value = "select new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) from Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " WHERE c.storeId IN (select s.storeId FROM Stores s WHERE s.clientID=:clientId And s.active !=0) and c.active !=0")
	List<CountersDto> findAllCounters(@Param("clientId") Long clientId);

	@Query(value = "select new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) from Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " WHERE c.storeId=:storeId  and c.active !=0")
	List<CountersDto> findCountersForStoreManager(@Param("storeId") Long storeId);

	@Query(value = "select new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) from Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " WHERE c.storeId IN (select s.storeId FROM Stores s WHERE s.active !=0) and c.active !=0")
	List<CountersDto> findAllCountersForAdmin();

	@Query(value = "select c.counterId from Counters c "
			+ " inner Join CounterAssignment co ON co.counterId = c.counterId"
			+ " inner Join Users u ON u.userId =  co.userId where u.userId =:userId and co.active!=0 ")
	Long findCounterCodeForSpecificClient(@Param("userId") Long userId);

	@Transactional
	@Modifying
	@Query("update Counters c set c.deviceId=:deviceId where c.counterId=:counterId AND c.active!=0 ")
	int updateDeviceIdOnCounters(@Param("deviceId") String deviceId, @Param("counterId") Long counterId);

	@Query(value = "SELECT new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) FROM Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0 WHERE c.counterName=:counterName AND c.storeId=:storeId AND c.active !=0")
	List<CountersDto> findByCounterName(@Param("counterName") String counterName, @Param("storeId") Long storeId);

	@Query(value = "SELECT new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) FROM Counters c"
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " WHERE c.counterName=:counterName AND c.storeId=:storeId AND c.active !=0 AND c.counterId !=:counterId")
	List<CountersDto> findByCounterNameAndCounterId(@Param("counterName") String counterName,
			@Param("storeId") Long storeId, @Param("counterId") Long counterId);

	@Query(value = "SELECT new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) FROM Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0 WHERE c.msisdn=:msisdn AND c.storeId=:storeId AND c.active !=0")
	List<CountersDto> findByMsisdn(@Param("msisdn") String msisdn, @Param("storeId") Long storeId);

	@Query(value = "SELECT new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) FROM Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0 WHERE c.msisdn=:msisdn AND c.storeId=:storeId AND c.active !=0 AND c.counterId !=:counterId")
	List<CountersDto> findByMsisdnAndCounterId(@Param("msisdn") String msisdn, @Param("storeId") Long storeId,
			@Param("counterId") Long counterId);

	@Query(value = "select new com.cellulant.instore.response.CountersDto(c.counterId,cc.counterCode,c.msisdn,c.counterName,c.active,c.description,c.storeId,c.isReference) from Counters c JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0 "
			+ " WHERE c.counterId=:counterId AND c.active!=0")
	CountersDto findByCounterId(@Param("counterId") Long counterId);

	@Transactional
	@Modifying
	@Query("update Counters c set c.counterName=:counterName,c.msisdn=:msisdn,c.isReference=:isReference where c.counterId=:counterId and c.active!=0")
	int updateCounters(@Param("counterName") String counterName, @Param("counterId") Long counterId,
			@Param("msisdn") String msisdn, @Param("isReference") IsReference isReference);

	@Transactional
	@Modifying
	
	@Query("UPDATE Counters c  SET c.active=0 WHERE c.counterId=:counterId AND c.active!=0")
	int updateCountersActive(@Param("counterId") Long counterId);

	@Query("SELECT new com.cellulant.instore.response.CounterInfo(cc.counterCode,c.counterName,c.msisdn,u.username,s.storeName,u.emailAddress) FROM Counters c "
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
			+ " INNER JOIN Stores s ON s.storeId=c.storeId"
			+ " INNER JOIN CounterAssignment co ON co.counterId=c.counterId"
			+ " INNER JOIN Users u ON u.userId=co.userId"
			+ " WHERE c.counterId=:counterId And c.active!=0 And co.active!=0")
	CounterInfo counterInformation(@Param("counterId") Long counterId);

	@Query(value = "SELECT c FROM Counters c where c.counterId=:counterId and c.active!=0")
	Counters findCounterById(@Param("counterId") Long counterId);

	@Query(value = "SELECT c FROM Counters c INNER JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0 where cc.counterCode=:counterCode and c.active!=0")
	Counters findCounterByCounterCode(@Param("counterCode") String counterCode);

	@Query(value = "SELECT c FROM Counters c where c.counterId=:counterId and c.active!=0 and c.storeId=:storeId")
	Counters findCounterOnTheBasisOfStoreId(@Param("storeId") Long storeId, @Param("counterId") Long counterId);

	@Query(value = "SELECT AUTO_INCREMENT" + "     FROM information_schema.TABLES"
			+ "     WHERE TABLE_SCHEMA =:dataBaseName" + "     AND TABLE_NAME =:tableName", nativeQuery = true)
	Long autoIncrementValue(@Param("dataBaseName") String dataBaseName, @Param("tableName") String tableName);

	@Query(value = "select c.counterId from Counters c " + " Inner join Stores s on s.storeId=c.storeId"
			+ " where c.active!=0 and s.active!=0 and s.clientID=:clientID and s.country=:countryCode")
	List<Long> findcounterIdByClientIdAndCountryCode(@Param("clientID") Long clientID,
			@Param("countryCode") String countryCode);

	@Query(value = "select c.counterId from Counters c " + " where c.active!=0  AND c.storeId=:storeId")
	List<Long> findcounterIdListByStoreId(@Param("storeId") Long storeId);

	@Query(value = "SELECT c FROM Counters c where c.counterId=:counterId and c.active!=0")
	Counters findCounterByCounterId(@Param("counterId") Long counterId);
	
	
	@Query(value = "SELECT c FROM Counters c "
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
    		+ " INNER Join Stores s ON s.storeId=c.storeId" 
    		+" where cc.counterCode=:counterCode AND s.country=:country and c.active!=0")
    Counters findCounterByCounterCodeAndxcountryCode(@Param("counterCode")String counterCode,@Param("country")String country);

	@Query(value = "select new com.cellulant.instore.response.QRCodeCounter(c.counterId,cc.counterCode,c.msisdn,c.counterName,s.storeName,s.storeId,s.country)  from Counters c "
			+ " INNER JOIN Stores s ON s.storeId=c.storeId and s.active!=0" 
			+ " JOIN CounterCodes cc on c.counterId=cc.counterId and cc.active!=0"
	+ " where cc.counterCode=:counterCode AND c.active!=0  AND c.storeId=:storeId")
	QRCodeCounter findcountersByStoreId(@Param("storeId") Long storeId,@Param("counterCode") String counterCode);

}
