package com.cellulant.instore.service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.AccountInfo;
import com.cellulant.instore.dto.PDFDtoForNigeria;
import com.cellulant.instore.dto.PaymentMethodDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.response.QRCodeCounter;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lowagie.text.DocumentException;

@Component
public class PDFCreationForNigeria implements PDFCreation {
	
	  private static final String ISOCOUNTRYCODE = "NGA";

	  @Autowired 
	 private PDFservice pdfservice;
	  
	  @Autowired
	  private ApplicationProperties applicationProperties;
	  
	  @Autowired
	  private RestTemplate restTemplate;

	  @Autowired
	  private Gson gson;
	  
		
		
		
	@Override
	public @ResponseBody ResponseEntity<InputStreamResource> downLoadPDF(String counterCode,QRCodeCounter counterInfo) throws IOException, DocumentException {
		Logger.info("Download Pdf For Nigeria ");
	
		PDFDtoForNigeria nigeria = getAccountInfo( counterCode,counterInfo);
		 Map<String, Object> data = new HashMap<>();
		 List<PaymentMethodDto> paymentMethodList = nigeria.getPaymentMethodDto();	
		 List<AccountInfo> accountInfoList = nigeria.getAccountInfo();	
		 data.put("accountName", nigeria.getAccountName());
		 data.put("logoUrl", paymentMethodList);
		 for(AccountInfo account: accountInfoList) {
			 if(account.getCounterCodeType().equals("wema")&&!Objects.isNull(account.getCounterCode())) {
					 String firstPart = account.getCounterCode().substring(0, 3);
					 String secondPart = account.getCounterCode().substring(3, 7);
					 String last = account.getCounterCode().substring(7);
					 data.put("wema",firstPart+" - "+secondPart+" - "+last);
			 }
			 if(account.getCounterCodeType().equals("zenith")&&!Objects.isNull(account.getCounterCode()))
			 {
				 String firstPart = account.getCounterCode().substring(0, 3);
				 String secondPart = account.getCounterCode().substring(3, 7);
				 String last = account.getCounterCode().substring(7);
				 data.put("zenith",firstPart+" - "+secondPart+" - "+last);
			 }
			 if(account.getCounterCodeType().equals("sterling")&&!Objects.isNull(account.getCounterCode()))
			 {
				 String firstPart = account.getCounterCode().substring(0, 3);
				 String secondPart = account.getCounterCode().substring(3, 7);
				 String last = account.getCounterCode().substring(7);
				 data.put("sterling",firstPart+" - "+secondPart+" - "+last);
			 }
				
		 }
		 data.put("account", accountInfoList);
		 Logger.info("Data -->> "+data);
		return pdfservice.generatePdfFile("qrCodeforNigeria", data, "qrcode.pdf",counterCode);
	}

	private PDFDtoForNigeria getAccountInfo(String counterCode,QRCodeCounter counterInfo) {
	Logger.info("In getAccountInfo Method "+ counterCode);
	Logger.info("Rest Url "+applicationProperties.getUssdNigeriaUrl()+counterCode);
	HttpHeaders headers = new HttpHeaders();
	 headers.set("X-Country-Code", counterInfo.getCountry());
	 HttpEntity<String> http = new HttpEntity<>(null, headers);
	 ResponseEntity<String> getServiceResult = restTemplate
				.exchange(applicationProperties.getUssdNigeriaUrl()+counterCode ,HttpMethod.GET,http, String.class);

	Logger.info("Response Coming from Api -->>> "+new Gson().toJson(getServiceResult));
	if (getServiceResult != null) {   
		JSONObject obj = new JSONObject(getServiceResult.getBody());
		Logger.info("Body --->>> "+obj);
		JSONObject dataObj = (JSONObject) obj.get("data");
		Logger.info("data --->>> "+dataObj);
		PDFDtoForNigeria nigeria = new PDFDtoForNigeria();
		String accountName = (String) dataObj.get("accountName");
		nigeria.setAccountName(accountName);
		JSONArray sportsArray = dataObj.getJSONArray("paymentMethods");
		ArrayList<PaymentMethodDto> paymentMethodList = gson.fromJson(sportsArray.toString(),
				 new TypeToken<List<PaymentMethodDto>>(){}.getType());
		nigeria.setPaymentMethodDto(paymentMethodList);
		JSONArray accountInfoArray = dataObj.getJSONArray("accountInfo");
		ArrayList<AccountInfo> accountInfo = gson.fromJson(accountInfoArray.toString(),
				 new TypeToken<List<AccountInfo>>(){}.getType());
		nigeria.setAccountInfo(accountInfo);
		Logger.info(" Return Response to Method "+gson.toJson(nigeria));
		return nigeria;
	}
	throw new NotFoundExceptions("Payment Method Not Found");
	}

	@Override
	public String getPdfCreationName() {
		 return ISOCOUNTRYCODE;
	}

}
