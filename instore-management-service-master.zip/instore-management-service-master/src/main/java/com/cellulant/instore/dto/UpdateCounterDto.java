package com.cellulant.instore.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateCounterDto {

	@NotNull(message = "counterCode is required")
	private String counterId;
	
	@NotNull(message = "counter name is required")
	@NotEmpty(message = "counter name  can not be null")
	private String counterName;
	
	@NotNull(message = "msisdn number is required")
	@NotEmpty(message = "msisdn can not be null")
	private String msisdn;
	
	@NotNull(message = "isReference is required")
	@NotEmpty(message = "isReference can not be null")
	private String isReference;

	
	
}
