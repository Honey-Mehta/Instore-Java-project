package com.cellulant.instore.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.CashierDto;
import com.cellulant.instore.response.ErrorResponse;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

@RestController
@CrossOrigin(origins = "*")
public class CashierController {

	@Autowired
	private RestTemplate restTemplate;
	

	@Autowired
	private   ApplicationProperties applicationProperties;
	
	
	
	
	
	@PostMapping("/createCashier")
	public ResponseEntity<Object> addCashier(@Valid @RequestBody CashierDto cashierDto
			,@RequestHeader(value = "X-Country-Code", required = true) String xCountryCode
			,@AuthenticationPrincipal CASUser casUser ) {
		 SuccessResponse response = new SuccessResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE,
					AppConstants.INTERNAL_SERVER_ERROR_MESSAGE, null);
		 Logger.builder(" addCashier() method START "+ new Gson().toJson(cashierDto)).info();
		try {
			   	   
               Gson gson = new Gson();
               HttpHeaders headers = new HttpHeaders();
               String token = casUser.getMetaData().getAccessToken();
               headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + token);
               headers.set("content-type", "application/json");
               headers.set("X-Country-Code", xCountryCode);
               HttpEntity<String> http = new HttpEntity<>(gson.toJson(cashierDto), headers);
               String restResponse = restTemplate.postForObject(applicationProperties.getCashierUrl(),http,
                      String.class);
               if (restResponse != null ) {
            	    response = gson.fromJson(restResponse,
                           SuccessResponse.class);
                   return new ResponseEntity<>(response,HttpStatus.OK);

               }
            
           } catch (HttpClientErrorException  ex) {
        	   ErrorResponse error = null;
		       Gson gson = new Gson();
        	   error = gson.fromJson(ex.getResponseBodyAsString(),
        			   ErrorResponse.class);
              return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
           }
		catch(Exception e) {
			 SuccessResponse errorResponse = new SuccessResponse(false,AppConstants.BAD_REQUEST_STATUS_CODE
					 ,e.getMessage(),null);
		      
      	   
            return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
}
