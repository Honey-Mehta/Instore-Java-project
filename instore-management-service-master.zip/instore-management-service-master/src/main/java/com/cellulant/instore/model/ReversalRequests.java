package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Entity
@Table(name = "reversalrequests")
public class ReversalRequests extends Actionable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true,nullable = false,name = "reversalRequestID")
	private Long reversalRequestId;
	
	@Column(name = "beepTransactionID")
	private String beepTransactionId;
	
	@Column(name = "reference")
	private Integer referenceId;
	
	@Column(name = "clientID")
	private Long clientId;
	
	@Column(name = "message")
	private String message;
	
	@Column(name = "amount")
	private Double amount;
	
	
	@Column(name = "status",nullable = false)
	private int status;
	
	@Column(name = "active",nullable = false)
	private Integer active;
	

}
