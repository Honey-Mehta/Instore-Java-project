package com.cellulant.instore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cellulant.core.logging.Logger;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;

@Service
public class CheckCustomCounterCode {

	@Autowired
	private CounterCodesRepository counterCodesRepository;

	public ResponseEntity<Object> checkCustomCounterCodeAlreadyExist(String country, String counterCode) {
		Logger.info("Inside checkCustomCounterCodeAlreadyExist() method  " + country + "  " + counterCode);
		String reponse = counterCodesRepository.findAlreadyExistCounterCode(country, counterCode);
		if (reponse != null) {
			Logger.info("counterCode already exist in db  -- >>> " + reponse);
			throw new AlreadyExistExceptions("This code is already allocated please enter another code");
		}
		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
				null);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

}
