package com.cellulant.instore.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentMethodDto {
	

	private String country;

	private String client_name;

	private String client_code;


	private String logo;
	

	

}
