package com.cellulant.instore.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cellulant.core.logging.Logger;
import com.cellulant.instore.itext.HeaderFooterPageEvent;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.response.QRCodeCounter;
import com.cellulant.instore.service.PDFCreation;
import com.cellulant.instore.service.PDFCreationFactory;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BarcodeQRCode;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@RestController
public class PdfGeneratorController {
	
	
	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private CounterRepository counterRepository;

	
	private static final String ISOCOUNTRYCODEFORNIGERIA = "NGA";

	
	@GetMapping("/app/genrateQrCode/")
	public @ResponseBody ResponseEntity<InputStreamResource> downloadQRCode(
			@RequestParam(name = "counterCode", required = true) String counterCode,
			@RequestParam(name = "storeId", required = true) Long storeId
			)
			throws IOException, com.lowagie.text.DocumentException {
		Logger.info("In downloadQRCode Method And counterCode is "+counterCode);
		QRCodeCounter counterInfo = counterRepository.findcountersByStoreId(storeId, counterCode);
		Logger.info("counter Code info "+counterInfo);
		String isoCountryCode = getIsoCountryCode(counterInfo.getCountry().toUpperCase());
		Logger.builder(" IsoCounrtyCode is " + isoCountryCode).info();
		PDFCreation pdfCreationFactory = PDFCreationFactory.createInstance(isoCountryCode);
		return pdfCreationFactory.downLoadPDF(counterCode,counterInfo);
		

		

	}
	
	private String getIsoCountryCode(String xCountryCode) {
		if (xCountryCode.equals(ISOCOUNTRYCODEFORNIGERIA)) {
			return applicationProperties.getXCountryCodeNigeria();
		}
			
			else {
		
			return applicationProperties.getXCountryCodeForOther();
		}

	}
	




	@GetMapping("/event/{beepTransactionId}")
	public @ResponseBody ResponseEntity<InputStreamResource> generatePdfForBeepTransactionId(
			@PathVariable String beepTransactionId) throws IOException, DocumentException {
		Logger.info("generatePdfForBeepTransactionId method Start  --->>> " + beepTransactionId);
		byte[] decodedBytes = Base64.getDecoder().decode(beepTransactionId);
		String decodedString = new String(decodedBytes);
		ByteArrayInputStream bis = getQRCodePdf(decodedString, "No");
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=qrCode" + beepTransactionId + ".pdf");
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));

	}

	private ByteArrayInputStream getQRCodePdf(String generateQRCode, String counterCode)
			throws DocumentException, IOException {

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

		Document document = new Document(PageSize.A4, 10, 15, 90, 36);
		PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
		document.open();
		BarcodeQRCode barcodeQRCode = new BarcodeQRCode(generateQRCode, 1000, 1000, null);

		Logger.info("Logo paths -->>>  " + applicationProperties.getTinggLogoUrl());

		Image headerImage = Image.getInstance(applicationProperties.getTinggLogoUrl());

		headerImage.scaleToFit(100, 30);
		headerImage.scaleAbsolute(100, 350);
		headerImage.setAlignment(1);
		headerImage.setAbsolutePosition(215f, 800f);

		PdfPTable table = new PdfPTable(1);
		PdfPCell cellTingg = new PdfPCell(new Phrase());
		cellTingg.setBorder(Rectangle.NO_BORDER);
		cellTingg.addElement(headerImage);
		cellTingg.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellTingg.setVerticalAlignment(Element.ALIGN_CENTER);
		cellTingg.setPaddingTop(35.0f);
		cellTingg.setPaddingBottom(35.f);
		table.addCell(cellTingg);

		cellTingg = new PdfPCell(new Phrase());
		cellTingg.setPaddingTop(4.0f);
		cellTingg.setBorder(Rectangle.NO_BORDER);
		cellTingg.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(cellTingg);

		Font font = new Font(FontFamily.TIMES_ROMAN, counterCode.equals(AppConstants.IS_COUNTER_CODE) ? 20.0f : 25.0f);
		Paragraph para = new Paragraph(counterCode.equals(AppConstants.IS_COUNTER_CODE) ? AppConstants.TINGG_MESSAGE
				: AppConstants.TINGG_MESSAGE_FOR_TICKET, font);
		PdfPCell paragraphCell = new PdfPCell(para);
		paragraphCell.setBorder(Rectangle.NO_BORDER);
		paragraphCell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(paragraphCell);

		PdfPCell barcodeCell = new PdfPCell(new Phrase());
		barcodeCell.setBorder(Rectangle.NO_BORDER);
		Image codeQrImage = barcodeQRCode.getImage();
		codeQrImage.setAlignment(1);

		codeQrImage.scaleAbsolute(300, 300);
		barcodeCell.addElement(codeQrImage);
		barcodeCell.setHorizontalAlignment(Element.ALIGN_CENTER);

		barcodeCell.setPaddingRight(15);
		table.addCell(barcodeCell);
		document.add(table);

		HeaderFooterPageEvent headerFooterPageEvent = new HeaderFooterPageEvent();
		headerFooterPageEvent.onEndPage(writer, document);
		document.close();

		return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
	}



}
