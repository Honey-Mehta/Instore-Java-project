package com.cellulant.instore.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.CounterAssignment;

public interface CounterAssignmentRepository extends JpaRepository<CounterAssignment, Long>{

	@Query("SELECT ca FROM CounterAssignment ca WHERE ca.counterId=:counterId AND ca.active!=0")
	List<CounterAssignment> findCounterAssignmnetOnTheBasisOfCounterId(@Param("counterId")Long counterId);
	
	@Transactional
	@Modifying  
	@Query("update CounterAssignment ca set ca.active=0 where ca.counterId=:counterId AND ca.active!=0")
	int updateCounterAssignmnet(@Param("counterId")Long counterId);
}
