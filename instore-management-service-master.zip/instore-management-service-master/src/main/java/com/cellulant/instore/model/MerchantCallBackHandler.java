package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "merchantcallbackhandler")
@EqualsAndHashCode(callSuper = true)
public class MerchantCallBackHandler extends Actionable{
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "merchantCallBackRequestID", unique = true,nullable = false)
	private Long merchantCallBackRequestId;
	
	
	@Column(name = "merchantNotificationID")
	private Long merchantNotificationId;
	
	@Column(name = "callBackUrl")
	private String callBackUrl;
	
	@Column(name = "requestPayload")
	private String requestPayload;
	
	@Column(name = "responsePayload")
	private String responsePayload;
	
	@Column(name = "status",nullable = false)
	private Integer status;
	
	@Column(name = "active")
	private Integer active;
	
	
	

}
