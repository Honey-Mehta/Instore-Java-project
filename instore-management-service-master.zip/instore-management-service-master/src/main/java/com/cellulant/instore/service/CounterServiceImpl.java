package com.cellulant.instore.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.CountersFinalResponse;
import com.cellulant.instore.dto.DeviceIdDto;
import com.cellulant.instore.dto.QRCode;
import com.cellulant.instore.dto.UpdateCounterDto;

import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;

import com.cellulant.instore.model.CounterAssignment;
import com.cellulant.instore.model.CounterCodes;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.IsReference;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.model.Users;
import com.cellulant.instore.repository.CounterAssignmentRepository;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.CounterInfo;
import com.cellulant.instore.response.CountersDto;
import com.cellulant.instore.response.GenericPagedResponse;
import com.cellulant.instore.response.MerchantDetail;
import com.cellulant.instore.response.StoreCountersDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;
import com.itextpdf.text.DocumentException;

@Service
public class CounterServiceImpl implements CounterService {

	@Autowired
	private CounterRepository counterRepository;

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private StoreAssignmentRepository storeAssignmentRepository;

	@Autowired
	private CounterAssignmentRepository counterAssignmentRepository;

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private CounterCodesRepository counterCodesRepository;

	@Override
	public ResponseEntity<Object> getCounters(CASUser casUser) {
		Logger.builder("In ServiceImpl layer  getCounters() method START casUser->>>" + new Gson().toJson(casUser))
				.info();
		SuccessResponse response = new SuccessResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null);
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("  User is Admin");
			List<CountersDto> countersDtoList = counterRepository.findAllCountersForAdmin();
			Logger.info("getCounters method End with Admin response " + countersDtoList);
			response = new SuccessResponse(false, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
					countersDtoList);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info(" User is Customer Checking Type Of Customer");
			Long cashierId = userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole());
			Long storeManagerId = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (storeManagerId != null) {
				return getCountersForStoreManager(storeManagerId);
			} else if (cashierId != null) {
				Logger.builder(
						"User is cashier  getCounters() method END becaue cashier not permision see any counters Not Authorized User "
								+ new Gson().toJson(response))
						.info();

				throw new PermissionException(AppConstants.PERMISSION_FAILED);

			} else {
				Logger.info("User is Merchant");
				List<CountersDto> countersDtoList = counterRepository.findAllCounters(casUser.getCustomerID());
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						countersDtoList);
				Logger.info("getCounters methods Ending with Merchant Data " + response);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}

		} else {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}

	}

	private ResponseEntity<Object> getCountersForStoreManager(Long storeManagerId) {
		Logger.info("getCountersForStoreManager() method Start  user is store Manager ");
		Long storeId = storeAssignmentRepository.findStoreId(storeManagerId);
		Stores stores = storeRepository.findStoreById(storeId);
		if (stores == null) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		} else {
			List<CountersDto> countersDtoList = counterRepository.findCountersForStoreManager(storeId);
			SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
					AppConstants.SUCCESS_MESSAGE, countersDtoList);
			Logger.info("getCounters methods Ending with Stores Manager Data " + response);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
	}

	@Override
	public ResponseEntity<Object> findCountersByStoreId(Long storeId, String searchCounters, int page, int size,
			CASUser casUser) throws PermissionException, IOException, DocumentException {
		Pageable paging = PageRequest.of(page - 1, size);
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.builder(" findCountersByStoreId() Method and User is  Admin " + storeId).info();
			Page<StoreCountersDto> counterListOnTheBasisOfStoreId = getCounterByStoreIdForAdmin(storeId, paging,
					searchCounters);
			return getQrCodeObject(counterListOnTheBasisOfStoreId, page, size);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info(" findCountersByStoreId() Method user Is Customer checking Customer Type");
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (userIdForStoreManager != null) {
				Page<StoreCountersDto> counterListOnTheBasisOfStoreId = getCounterByStoreIdForStoreManager(storeId,
						paging, searchCounters, casUser, userIdForStoreManager);

				return getQrCodeObject(counterListOnTheBasisOfStoreId, page, size);

			} else if (userIdForCashier != null) {
				Logger.builder(" findCountersByStoreId() method END it cashier Not Authorized User ").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);

			} else {
				Logger.info("user is Merchant");
				Page<StoreCountersDto> counterListOnTheBasisOfStoreId = getCounterByStoreIdForCustomer(storeId, paging,
						searchCounters, casUser);
				return getQrCodeObject(counterListOnTheBasisOfStoreId, page, size);
			}

		} else {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}

	}

	private ResponseEntity<Object> getQrCodeObject(Page<StoreCountersDto> counterListOnTheBasisOfStoreId, int page,
			int size) {
		List<CountersFinalResponse> countersFinalResponseList = new ArrayList<>();

		for (StoreCountersDto storeCountersDto : counterListOnTheBasisOfStoreId) {
			Counters counter = counterRepository.findCounterById(storeCountersDto.getCounterId());
			Logger.info("counterCode is available or not in db " + counter);
			if (Objects.isNull(counter)) {
				throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
			}
			Stores store = storeRepository.findStoreById(counter.getStoreId());

			if (Objects.isNull(store)) {
				throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
			}
			CountersFinalResponse countersFinalResponse = new CountersFinalResponse();
			countersFinalResponse.setCounterCode(storeCountersDto.getCounterCode());
			countersFinalResponse.setCounterId(storeCountersDto.getCounterId());
			countersFinalResponse.setCounterName(storeCountersDto.getCounterName());
			countersFinalResponse.setIsReference(storeCountersDto.getIsReference());
			countersFinalResponse.setMsisdn(storeCountersDto.getMsisdn());
			countersFinalResponse.setStoreName(storeCountersDto.getStoreName());
			countersFinalResponse.setUsername(storeCountersDto.getUsername());
			com.cellulant.instore.dto.QRCode qrCode = new QRCode();
			qrCode.setData(applicationProperties.getPayByLinkUrl() + store.getCountry() + "/"
					+ storeCountersDto.getCounterCode());
			Logger.info("Pdf url --->> " + applicationProperties.getPdfUrl()
					+ storeCountersDto.getCounterCode());
			qrCode.setPdf(applicationProperties.getPdfUrl() + String.valueOf(storeCountersDto.getCounterCode())+"&storeId="+store.getStoreId());
			countersFinalResponse.setQrCode(qrCode);
			countersFinalResponseList.add(countersFinalResponse);
		}
		GenericPagedResponse<CountersFinalResponse> successResponse = GenericPagedResponse
				.<CountersFinalResponse>builder().success(true).statusCode(AppConstants.SUCCESS_STATUS)
				.message(AppConstants.SUCCESS_MESSAGE).size((long) size)
				.totalItems(counterListOnTheBasisOfStoreId.getTotalElements())
				.totalPages((long) counterListOnTheBasisOfStoreId.getTotalPages()).currentPage(page)
				.data(countersFinalResponseList).build();

		Logger.builder("findCountersByStoreId() method END User is Admin " + successResponse.toString()).info();
		return new ResponseEntity<>(successResponse, HttpStatus.OK);
	}

	private Page<StoreCountersDto> getCounterByStoreIdForCustomer(Long storeId, Pageable paging, String searchCounter,
			CASUser casUser) {
		if (searchCounter.isEmpty()) {
			Logger.info("Its a Merchant without Filter " + casUser.getCustomerID());
			Page<StoreCountersDto> counterListOnTheBasisOfStoreId = counterRepository.findByCountersStoreId(paging,
					storeId, casUser.getCustomerID());
			Logger.builder("getCounterByStoreIdForCustomer() method END User is Merchant without Filter "
					+ counterListOnTheBasisOfStoreId.toString()).info();
			return counterListOnTheBasisOfStoreId;
		} else {
			Logger.info("Its a Merchant with Filter " + casUser.getCustomerID());
			Page<StoreCountersDto> counterListOnTheBasisOfStoreId = counterRepository.fetchCounterByFilter(storeId,
					searchCounter, casUser.getCustomerID(), paging);
			Logger.builder("getCounterByStoreIdForCustomer() method END User is Merchant with Filter "
					+ counterListOnTheBasisOfStoreId.toString()).info();
			return counterListOnTheBasisOfStoreId;
		}

	}

	private Page<StoreCountersDto> getCounterByStoreIdForStoreManager(Long storeId, Pageable paging,
			String searchCounters, CASUser casUser, Long userIdForStoreManager) {
		Logger.info("getCounterByStoreIdForStoreManager start Its a store Manager");
		Long checkingStoreId = storeAssignmentRepository.findStoreId(userIdForStoreManager);
		Stores stores = storeRepository.findStoreById(checkingStoreId);
		if (stores == null) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		} else {
			if (storeId.equals(stores.getStoreId())) {
				if (searchCounters.isEmpty()) {
					Logger.info("Its a StoreManager without Filter " + casUser.getCustomerID());
					Page<StoreCountersDto> counterListOnTheBasisOfStoreId = counterRepository
							.findByCountersStoreId(paging, storeId, casUser.getCustomerID());
					Logger.builder(
							"getCounterByStoreIdForStoreManager() method END User is StoreManager without Filter "
									+ counterListOnTheBasisOfStoreId.toString())
							.info();
					return counterListOnTheBasisOfStoreId;
				} else {
					Logger.info("Its a StoreManager with Filter " + casUser.getCustomerID());
					Page<StoreCountersDto> counterListOnTheBasisOfStoreId = counterRepository
					.fetchCounterByFilter(storeId, searchCounters, casUser.getCustomerID(), paging);

					Logger.builder(
							"getCounterByStoreIdForStoreManager() method END User is StoreManager without Filter "
									+ counterListOnTheBasisOfStoreId.toString())
							.info();
					return counterListOnTheBasisOfStoreId;
				}
			}
				throw new PermissionException(AppConstants.PERMISSION_FAILED);

		}
	}

	private Page<StoreCountersDto> getCounterByStoreIdForAdmin(Long storeId, Pageable paging, String searchCounters) {
		if (searchCounters.isEmpty()) {
			Logger.info("Its a Admin without Filter");
			return counterRepository.findByCountersStoreIdForAdmin(storeId, paging);

		} else {
			Logger.info("Its a Admin with Filter");
			return counterRepository.fetchCounterByFilterForAdmin(storeId, searchCounters, paging);

		}
	}

	private ResponseEntity<Object> updateDeviceIdForCustomers(DeviceIdDto deviceIdDto) {
		Logger.builder(" updateDeviceId() method START " + deviceIdDto.getDeviceID()).info();
		SuccessResponse response = new SuccessResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.DEVICEID_NOT_UPDATED, null);
		List<Users> userList = userRepository.findByUserId(deviceIdDto.getUserId());
		if (!userList.isEmpty()) {
			Long counterCode = counterRepository.findCounterCodeForSpecificClient(deviceIdDto.getUserId());
			Logger.info("is counterCode --> " + counterCode);
			if (counterCode != null) {
				int isUpdated = counterRepository.updateDeviceIdOnCounters(deviceIdDto.getDeviceID(), counterCode);
				Logger.info("is Updated --> " + isUpdated);
				if (isUpdated > 0) {
					response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.DEVICEID_UPDATED,
							null);
					Logger.builder(" updateDeviceId() method END with Success Response " + new Gson().toJson(response))
							.info();
					return new ResponseEntity<>(response, HttpStatus.OK);
				} else {
					Logger.builder(" updateDeviceId() method END  with Bad Request " + new Gson().toJson(response))
							.info();
					return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
				}
			} else {
				throw new NotFoundExceptions(AppConstants.COUNTER_NOT_ASSIGN);
			}
		} else {

			throw new NotFoundExceptions(AppConstants.USERID_NOT_FOUND);
		}

	}

	@Override
	public ResponseEntity<Object> updateDeviceId(DeviceIdDto deviceIdDto, CASUser casUser) {
		Logger.builder(" updateDeviceId() method START " + deviceIdDto.getDeviceID()).info();
		SuccessResponse response = new SuccessResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.DEVICEID_NOT_UPDATED, null);
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {

			Logger.builder(" updateCounter() method END Its Admin Not Authorized User " + new Gson().toJson(response))
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else {
			return updateDeviceIdForCustomers(deviceIdDto);
		}

	}

	private ResponseEntity<Object> editCounter(UpdateCounterDto updateCounterDto,Counters counter) {
		Logger.builder(" editCounter() method Start " + new Gson().toJson(updateCounterDto)).info();
		SuccessResponse response = null;
		
		List<CountersDto> countersList = counterRepository.findByCounterNameAndCounterId(
				updateCounterDto.getCounterName(), counter.getStoreId(), counter.getCounterId());
		Logger.builder(" Checking  Counter Name is already Exist or not in Database " + new Gson().toJson(countersList))
				.info();
		if (!countersList.isEmpty()) {
			Logger.builder("updateCounter() method END with Bad Request Counter name Already Exist ").info();
			throw new AlreadyExistExceptions(AppConstants.COUNTER_NAME_ALREADY_EXIST);
		}
		List<CountersDto> counterPhoneList = counterRepository.findByMsisdnAndCounterId(updateCounterDto.getMsisdn(),
				counter.getStoreId(), counter.getCounterId());
		Logger.builder(" Checking  Msisdn  is already Exist or not in Database " + new Gson().toJson(counterPhoneList))
				.info();
		if (!counterPhoneList.isEmpty()) {
			Logger.builder("saveCounter() method END with Bad Request, Phone Number Already Exist ").info();
			throw new AlreadyExistExceptions(AppConstants.COUNTER_PHONE_ALREADY_EXIST);
		}

		int updateValue = counterRepository.updateCounters(updateCounterDto.getCounterName(),
				counter.getCounterId(), updateCounterDto.getMsisdn(),
				(updateCounterDto.getIsReference()).equalsIgnoreCase("yes") ? IsReference.YES : IsReference.NO);
		if (updateValue > 0) {
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.COUNTER_UPDATED_SUCCESSFULLY,
					updateCounterDto);
			Logger.builder(" updateCounter is End With Success Response " + new Gson().toJson(response)).info();
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			response = new SuccessResponse(true, AppConstants.SQL_EXCEPTIONS, AppConstants.REQUEST_UNABLE_TO_PROCESS,
					updateCounterDto);
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@Override
	public ResponseEntity<Object> updateCounter(UpdateCounterDto updateCounterDto, CASUser casUser,Counters counter) {
		Logger.builder(" updateCounter() method Start " + new Gson().toJson(updateCounterDto)).info();
		SuccessResponse response = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			
			String isref = counter.getIsReference().toString();
			if (!counter.getCounterName().equals(updateCounterDto.getCounterName())
					|| !isref.equalsIgnoreCase(updateCounterDto.getIsReference())) {
				throw new PermissionException(AppConstants.PERMISSION_DENIED);
			}
			return editCounter(updateCounterDto,counter);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Checking which type of Customer is --->>>");
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (userIdForStoreManager != null) {
				Logger.info("It Store Manager  --->>");
				return updateCounterForStoreManager(userIdForStoreManager, updateCounterDto,counter);

			} else if (userIdForCashier != null) {
				Logger.builder(
						" updateCounters() method END User is cashier.So Cashier is Not Authorized User to Update Counters "
								+ new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("Its Merchant --->>>>");
				Stores store = storeRepository.findStoresByStoreIdAndClientId(counter.getStoreId(),
						casUser.getCustomerID());
				Logger.info("checking Stores for counterCode "+new Gson().toJson(counter));
				if (store != null) {
					return editCounter(updateCounterDto,counter);
				} else {
					Logger.builder(" updateCounters() method END because it want to update others store counter")
							.info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				}
			}
		} 
			throw new PermissionException(AppConstants.PERMISSION_FAILED);

	}

	private ResponseEntity<Object> updateCounterForStoreManager(Long userIdForStoreManager,
			UpdateCounterDto updateCounterDto,Counters counter) {
		Logger.info("Its a store Manager ---->>>");
		Long checkingStoreId = storeAssignmentRepository.findStoreId(userIdForStoreManager);
		Stores stores = storeRepository.findStoreById(checkingStoreId);
		if (stores == null) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		} else {
			Counters counters = counterRepository.findCounterOnTheBasisOfStoreId(stores.getStoreId(),
					counter.getCounterId());
			if (counters != null) {
				return editCounter(updateCounterDto,counter);
			} else {

				Logger.builder(
						" updateCounterForStoreManager() method END because it want to delete others store counter")
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}
		}
	}

	private ResponseEntity<Object> removeCounter(String counterCode,Counters counter) {
		Logger.info("Now we are in counterServiceImp class and method name is deleteCounter " + counterCode);
		SuccessResponse response = null;
		List<CounterCodes> counterCodesList = counterCodesRepository.findConterCodesByCounterID(counter.getCounterId());
		Logger.info("CounterCode List "+new Gson().toJson(counterCodesList));
		List<CounterAssignment> counterAssignmentList = counterAssignmentRepository
				.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId());
		Logger.info("Cashier is assign for particular Counter " + new Gson().toJson(counterAssignmentList));
		if (counterAssignmentList != null && !counterAssignmentList.isEmpty()) {
			Logger.info("Now Updating counterAssignment table and set active = 0 for particular Counter");
			return updateCounterAssignmentAndCounterTable(counterCode,counter,counterCodesList);

		} else {
			Logger.info("This Counter does not have any cashier");
			if(counterCodesList.size()==1) {
				int updateCounter = counterRepository.updateCountersActive(counter.getCounterId());
				Logger.info("Updated in counter Table "+updateCounter);
				int updateCounterCodes = counterCodesRepository.updateCounterCodesActive(counter.getCounterId());
				Logger.info("Update counters and counterCode active status counters -> " + updateCounter
						+ " counterCodes -> " + updateCounterCodes);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
						AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				int updateCounterCodes = counterCodesRepository.updateCounterCodesActiveBycounterCode(counterCode);
				Logger.info("Updated Only counterCodes table because some counterCode is attached to this counter "+updateCounterCodes);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
						AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		

		}

	}

	@Override
	public ResponseEntity<Object> deleteCounter(String counterCode, CASUser casUser,Counters counter) {
		Logger.info("Now we are in counterServiceImp class and method name is deleteCounter " + counterCode);
		SuccessResponse response = null;
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.builder(" deleteCounter() method END Admin Not Authorized User ").info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Checking which type of Customer is -----?>>");
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (userIdForStoreManager != null) {
				Logger.info("It Store Manager ------->>>  ");
				return pleaseDeleteCounterForStoreManager(counterCode, userIdForStoreManager,counter);

			} else if (userIdForCashier != null) {
				Logger.builder(" deleteCounter() method END Cashier Not Authorized User " + new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("Its Merchant");
				
				Stores store = storeRepository.findStoresByStoreIdAndClientId(counter.getStoreId(),
						casUser.getCustomerID());
				if (store != null) {
					return removeCounter(counterCode,counter);
				} else {
					Logger.builder(" deleteCounter() method END because it want to delete others store counter"
							+ new Gson().toJson(response)).info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				}

			}
		} else {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}

	}

	private ResponseEntity<Object> pleaseDeleteCounterForStoreManager(String counterCode, Long userIdForStoreManager,Counters counter) {
		Logger.info("Its a store Manager ------>>>>>>>>>>");
		Long checkingStoreId = storeAssignmentRepository.findStoreId(userIdForStoreManager);
		Stores stores = storeRepository.findStoreById(checkingStoreId);
		if (stores == null) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		} else {
			Counters counters = counterRepository.findCounterOnTheBasisOfStoreId(stores.getStoreId(), counter.getCounterId());
			if (counters != null) {
				return removeCounter(counterCode,counter);
			} else {
				Logger.builder(
						" pleaseDeleteCounterForStoreManager() method END because it want to delete others store counter")
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}
		}

	}

	private ResponseEntity<Object> updateCounterAssignmentAndCounterTable(String counterCode,Counters counters,List<CounterCodes> counterCodesList) {
		Logger.info("This Counter has cashier ");
		SuccessResponse response = null;
		if(counterCodesList.size()==1) {
			int updateCounterAssignment = counterAssignmentRepository.updateCounterAssignmnet(counters.getCounterId());
			Logger.info(" Yes CounterAssgnment Deleted succesFully..!!!" + updateCounterAssignment);
			int updateCounter = counterRepository.updateCountersActive(counters.getCounterId());
			int updateCounterCodes = counterCodesRepository.updateCounterCodesActive(counters.getCounterId());
			Logger.info("Update counters and counterCode active status counters -> " + updateCounter
					+ " counterCodes -> " + updateCounterCodes);
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
					AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			int updateCounterCodes = counterCodesRepository.updateCounterCodesActiveBycounterCode(counterCode);
			Logger.info("Updated in counterCodes Table only and value is "+updateCounterCodes);
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
					AppConstants.COUNTER_DELETED_SUCCESSFULLY, counterCode);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
			

	}

	private ResponseEntity<Object> getCounterById(String counterId,Counters counter) {
		SuccessResponse response = null;
		Logger.info("Checking Counter is available  or Not");
		
		if (counter != null) {
			List<CounterAssignment> counterAssignmentList = counterAssignmentRepository
					.findCounterAssignmnetOnTheBasisOfCounterId(counter.getCounterId());
			Logger.info("Cashier is assign for particular Counter " + new Gson().toJson(counterAssignmentList));
			if (counterAssignmentList != null && !counterAssignmentList.isEmpty()) {
				CounterInfo counterInfo = counterRepository.counterInformation(counter.getCounterId());
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						counterInfo);
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				Logger.info("No Cashier is assign to particular Counter ");
				Stores store = storeRepository.findStoreById(counter.getStoreId());

				CounterInfo counterInfo = new CounterInfo();
				counterInfo.setCounterCode(counterId);
				counterInfo.setCounterName(counter.getCounterName());
				counterInfo.setMsisdn(counter.getMsisdn());
				if (store != null) {
					counterInfo.setStoreName(store.getStoreName());
				}
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						counterInfo);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		} else {
			throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
		}

	}

	@Override
	public ResponseEntity<Object> fetchCounterById(String counterId, CASUser casUser,Counters counter) {
		Logger.info("Now we are in counterServiceImp class and method name is fetchCounterById " + counterId);
		SuccessResponse response = new SuccessResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null);
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("User is Admin");
			return getCounterById(counterId,counter);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is customer Checking which type of customer");
			Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
					applicationProperties.getCashierRole());
			Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (userIdForStoreManager != null) {
				return getStoreManagerCounterById(counterId, userIdForStoreManager,counter);

			} else if (userIdForCashier != null) {
				Logger.builder(" fetchCounterById() method END Not Authorized User " + new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("user is Merchant");
				
				Stores store = storeRepository.findStoresByStoreIdAndClientId(counter.getStoreId(),
						casUser.getCustomerID());
				if (store != null) {
					return getCounterById(counterId,counter);
				} else {
					Logger.builder(" fetchCounterById() method END because it want to access others store counter"
							+ new Gson().toJson(response)).info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				}

			}

		} else {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}
	}

	private ResponseEntity<Object> getStoreManagerCounterById(String counterId, Long userIdForStoreManager,Counters counters) {
		Logger.info("Its a store Manager");
		Long checkingStoreId = storeAssignmentRepository.findStoreId(userIdForStoreManager);
		Stores stores = storeRepository.findStoreById(checkingStoreId);
		if (stores == null) {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		} else {
			Counters counter = counterRepository.findCounterOnTheBasisOfStoreId(stores.getStoreId(), counters.getCounterId());
			if (counter != null) {
				return getCounterById(counterId,counters);
			} else {
				Logger.builder(" fetchCounterById() method END because it want to access others store counter").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}
		}
	}

	@Override
	public ResponseEntity<Object> fetchCashierDetail(String role, CASUser casUser) {
		Logger.info(
				"Now we are in counterServiceImp class and method name is fetchCashierDetail " + casUser.getUserID());
		SuccessResponse response = null;

		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("Its Customer or ");
			role = role.replaceAll("\\s", "");
			if (role.equals(applicationProperties.getCashierRoleName())) {
				Logger.info("Its Customer or ");
				MerchantDetail cashierInfo = userRepository.findCashierInfo(casUser.getUserID());
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						cashierInfo);
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				Logger.info("Its Not  Cashier ");
				Logger.builder(
						" fetchStoresAndCountersCount() method END Not Authorized User " + new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}

		} else {
			Logger.builder(" fetchCashierDetail() method END Not Authorized User " + new Gson().toJson(response))
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}
	}

}
