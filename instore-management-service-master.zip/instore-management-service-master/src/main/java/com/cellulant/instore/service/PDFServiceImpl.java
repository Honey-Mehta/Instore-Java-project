package com.cellulant.instore.service;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.cellulant.core.logging.Logger;
import com.lowagie.text.DocumentException;

@Service
public class PDFServiceImpl implements PDFservice {
	
	
	@Autowired
    private TemplateEngine templateEngine;
	

	   @Override
	    public @ResponseBody ResponseEntity<InputStreamResource> generatePdfFile(String templateName, Map<String, Object> data, String pdfFileName,String counterCode)  {
	       Logger.info("In PDF service Impl class "); 
		   Context context = new Context();
	        context.setVariables(data);
	        try {
	        	Logger.info("In Try block");
	        String htmlContent = templateEngine.process(templateName, context);
	        Logger.info("htmlContent ");
	        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ITextRenderer renderer = new ITextRenderer();
			Logger.info("renderer ");
			renderer.setDocumentFromString(htmlContent);
			Logger.info("setDocumentFromString ");
			renderer.layout();
			Logger.info("layout ");
			renderer.createPDF(byteArrayOutputStream, false);
			Logger.info("createPDF ");
			renderer.finishPDF();
			Logger.info("Pdf Generated SuccessFully...!!!!!");
			HttpHeaders headers = new HttpHeaders();
   
			headers.add("Content-Disposition", "attachment; filename=qrCode" + counterCode + ".pdf");
			return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
					.body(new InputStreamResource(new ByteArrayInputStream(byteArrayOutputStream.toByteArray())));
	        } catch (DocumentException e) {
	        	 Logger.info("DocumentException "+ e.getMessage());
	        }
			return null;
			
	    }

}
