package com.cellulant.instore.service;
import java.util.Map;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ResponseBody;



public interface PDFservice {

	@ResponseBody ResponseEntity<InputStreamResource> generatePdfFile(String templateName, Map<String, Object> data, String pdfFileName,String counterCode) ;
}
