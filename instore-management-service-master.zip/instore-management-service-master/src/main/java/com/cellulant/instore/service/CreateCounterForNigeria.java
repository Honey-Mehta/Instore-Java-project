package com.cellulant.instore.service;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.NigeriaDto;
import com.cellulant.instore.dto.NigeriaResponseDto;
import com.cellulant.instore.dto.ServiceInfo;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.CounterCodes;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CounterResponseDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;
import com.google.gson.Gson;

@Component
public class CreateCounterForNigeria implements CounterCreation {

	private static final String ISOCOUNTRYCODE = "NGA";

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private Utility utility;

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private CounterRepository counterRepository;
	@Autowired
	private CounterCodesRepository counterCodesRepository;
	private static long current = System.currentTimeMillis();
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Gson gson;

	@Override
	public ResponseEntity<Object> createCounter(List<CounterDto> counterDto, CASUser casUser, String countryCode) {
		Logger.info("createCounters() Method Start its For Nigeria -->> " + new Gson().toJson(counterDto));
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {

			Logger.info("createCounters() Method  End Admin is Not Authorized for create counter ");
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Checking type of customer");
			Long cashierId = userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole());
			Long storeManagerId = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (storeManagerId != null) {
				Logger.info("User is Store Manager -> ");
				return saveCounters(counterDto, casUser, countryCode);
			} else if (cashierId != null) {
				Logger.builder(" createCounters() method END Cashier is Not Authorized For create Counter ").info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("User is Merchant ");
				return saveCounters(counterDto, casUser, countryCode);
			}

		} else {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}
	}

	private ResponseEntity<Object> saveCounters(List<CounterDto> counterDto, CASUser casUser, String countryCode) {
		Logger.info("saveCounters Method Start -- >>> ");
		List savedCounterList = new ArrayList<>();
		for (CounterDto dto : counterDto) {
			utility.checkCounterNameAndPhoneAlreadyExistOrNot(dto);
			Stores store = storeRepository.findStoreById(dto.getStoreId());
			if (store != null) {
				utility.validateClientID(store, casUser);
				utility.validateCountry(store, countryCode);
				Counters counter = utility.setCounterInformation(dto, casUser);

				Logger.info("Saving data in counters table " + counter);

				Counters counters = counterRepository.save(counter);
				Logger.info("Update counter in counters table " + counters);

				String counterCode = updateCounterCodeForNigeria(store, countryCode);

				CounterCodes counterCodesDto = new CounterCodes();
				int counterCodeTypeId = findCounterCodeTypeID(applicationProperties.getBankName());

				Logger.builder("Calling setCounterCodeInfo method() ->").info();
				counterCodesDto = setCounterCodeInfo(counters, store, counterCode, counterCodeTypeId);
				Logger.info("Saving data in countercodes table " + counterCodesDto);
				CounterCodes counterCodesSave = counterCodesRepository.save(counterCodesDto);
				Logger.info("Update countercode in countercodes table " + counterCodesSave);
				CounterResponseDto response = this.formulateResponse(dto, counterCodesDto);
				savedCounterList.add(response);
				Logger.info("counter for Nigeria successfully updated" + counterCodesSave);

			} else {
				throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
			}
		}
		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
				AppConstants.COUNTER_ADDED_SUCCESSFULLY, savedCounterList);
		Logger.builder("saveCounter() method END Success " + response.toString()).info();
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	public String updateCounterCodeForNigeria(Stores store, String countryCode) {

		Logger.info("updateCounterCodeForNigeria() method start");

		NigeriaDto dto = new NigeriaDto();
		dto.setAccountReference(applicationProperties.getAccountReference());
		dto.setAmount(applicationProperties.getAmount());
		dto.setClientId(applicationProperties.getClientId());
		Long autoIncrementedMerchantId = counterRepository.autoIncrementValue(applicationProperties.getDataBaseName(),
				applicationProperties.getCounterTableName());
		dto.setMerchantId(String.valueOf(autoIncrementedMerchantId));
		ServiceInfo serviceInfo = getServiceCode(store.getClientID(), countryCode);
		dto.setServiceCode(serviceInfo.getServiceCode());// from setup api
		dto.setUniqueId(String.valueOf(getUniqId()));// generate unique id
		dto.setServiceName(serviceInfo.getServiceName());

		Logger.info("Calling getCounterCode method with data  " + dto);
		String response = this.getCounterCode(dto);

		Logger.info("Response from getCounterCode method  " + response);

		NigeriaResponseDto ngResponse = gson.fromJson(response, NigeriaResponseDto.class);

		Logger.info("Return counterCode  " + ngResponse.getAccountnumber());
		return ngResponse.getAccountnumber();
	}

	public String getCounterCode(NigeriaDto request) {
		Logger.info("Inside getCounterCode() method  " + request);
		HttpHeaders headers = new HttpHeaders();
		headers.set("content-type", "application/json");
		HttpEntity<Object> http = new HttpEntity<>(headers);
		String url = applicationProperties.getNigeriaUrl() + "uniqueId=" + request.getUniqueId() + "&ServiceCode="
				+ request.getServiceCode() + "&merchantType=" + applicationProperties.getMerchantType() + "&Name="
				+ request.getServiceName() + "&Amount=" + request.getAmount() + "&accountReference="
				+ request.getAccountReference();
		Logger.info("Invoking jogo jogo api  " + url + "  Entity ->" + http);
		String restResponse = restTemplate.postForObject(url, http, String.class);
		Logger.info("Receive response from JOGO JOGO api " + restResponse);

		if (restResponse == null) {
			Logger.info("Receive null response from JOGO JOGO" + restResponse);
			throw new NotFoundExceptions(AppConstants.COUNTERCODE_NOTFOUND);
		}
		JSONObject data = new JSONObject(restResponse);
		if (!data.toString().contains("accountnumber")) {
			Logger.info(AppConstants.COUNTERCODE_NOTFOUND + data);
			throw new NotFoundExceptions(AppConstants.COUNTERCODE_NOTFOUND);
		}

		Logger.info("Return response with data" + restResponse);
		return restResponse;
	}

	public ServiceInfo getServiceCode(Long customerID, String countryCode) {
		Logger.builder("getServiceCode method Start()").info();
		String url = applicationProperties.getServiceId() + customerID + "/services" + "?mapping=" + countryCode
				+ "&paymentChannelCode=" + applicationProperties.getPaymentChannelCode();
		Logger.builder(" api url :- " + url).info();
		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
		Logger.builder("Receive setup api response " + new Gson().toJson(response)).info();

		String body = response.getBody();
		JSONObject obj = new JSONObject(body);
		JSONArray data = (JSONArray) obj.get("data");
		if (data.isEmpty()) {
			Logger.info("Getting null data for existing client " + data);

			throw new NotFoundExceptions(AppConstants.SERVICECODE_NOTFOUND);
		}
		ServiceInfo serviceInfo = new ServiceInfo();
		JSONObject obj2 = (JSONObject) data.get(0);
		String serviceName = (String) obj2.get("serviceName");
		JSONObject mapping = (JSONObject) obj2.get("mapping");
		String code = (String) mapping.get("code");
		serviceInfo.setServiceName(serviceName);
		serviceInfo.setServiceCode(code);
		Logger.builder("Return serviceInfo " + serviceInfo).info();

		return serviceInfo;
	}

	@Override
	public String getCounterCreationName() {

		return ISOCOUNTRYCODE;
	}

	public CounterResponseDto formulateResponse(CounterDto dto, CounterCodes counterCodesDto) {
		Logger.builder("Inside formulateResponse method Start() " + dto + "  " + counterCodesDto).info();
		CounterResponseDto counterResponseDto = new CounterResponseDto();
		counterResponseDto.setCounterId(counterCodesDto.getCounterId());
		counterResponseDto.setActive(counterCodesDto.getActive());
		counterResponseDto.setCounterCode(counterCodesDto.getCounterCode());
		counterResponseDto.setCounterName(dto.getCounterName());
		counterResponseDto.setMsisdn(dto.getMsisdn());
		counterResponseDto.setStoreId(dto.getStoreId());
		counterResponseDto.setType(applicationProperties.getBankName());

		Logger.builder("Return final Response " + counterResponseDto).info();
		return counterResponseDto;
	}

	public CounterCodes setCounterCodeInfo(Counters counters, Stores store, String counterCode, int counterCodeTypeId) {

		CounterCodes counterCodesDto = new CounterCodes();

		counterCodesDto.setCounterId(counters.getCounterId());
		counterCodesDto.setCountry(store.getCountry());
		counterCodesDto.setCreatedBy(store.getCreatedBy());
		counterCodesDto.setModifiedBy(store.getModifiedBy());
		counterCodesDto.setActive(1);
		counterCodesDto.setCounterCode(counterCode);
		counterCodesDto.setCounterCodeType(counterCodeTypeId);
		return counterCodesDto;
	}

	public int findCounterCodeTypeID(String counterCodeType) {

		Logger.info("findCounterCodeTypeID() method   " + counterCodeType);
		int counterCodeTypeId = counterCodesRepository.findCounterCodeTypeName(counterCodeType);
		Logger.info("fetch counterCodeType Id from db  " + counterCodeTypeId);
		return counterCodeTypeId;
	}

	public synchronized long getUniqId() {
		return current++;
	}

}
