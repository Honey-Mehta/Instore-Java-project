package com.cellulant.instore.service;

import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.request.StoreDto;

import javassist.NotFoundException;

public interface StoreService {


	ResponseEntity<Object> fetchStoresWithPagination(String searchStores,int page,int size, CASUser casUser,String xCountryCode,Long casUserId);
	

	
    ResponseEntity<Object> createStores(StoreDto storeDto,CASUser casUser);
    
    ResponseEntity<Object> updateStoresInfo(StoreDto storeDto,CASUser casUser) throws NotFoundException;
	
	public ResponseEntity<Object> findStoreDetail(Long storeId,CASUser casUser) throws NotFoundException;
	
    public ResponseEntity<Object> fetchStores(CASUser casUser,String xCountryCode);
    
    ResponseEntity<Object> fetchStoresAndCounter(CASUser casUser,String userRole);
    
	public int deleteStoreById(Long storeId);

}
