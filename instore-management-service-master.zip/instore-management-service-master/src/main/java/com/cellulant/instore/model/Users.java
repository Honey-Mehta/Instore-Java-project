package com.cellulant.instore.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "users")
@EqualsAndHashCode(callSuper = true)
public class Users extends Actionable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userID",unique = true,nullable = false)
	private Long userId;
	
	@Column(name = "clientID",nullable = false)
	private Long clientId;
	
	@Column(name = "roleId")
	private Integer roleId;
	
	@Column(name = "username")
	private String username;
	
	private String fullName;
	
	@Column(name = "emailAddress")
	private String emailAddress;
	
	@Column(name = "MSISDN")
	private String msisdn;
	
	
	@Column(name = "casUserID" )
	private Long casUserID;
	
	@Column(name = "idnumber")
	private String idNumber;	
	
	@Column(nullable = false, columnDefinition = "TINYINT(1)",name = "status")
	private  boolean status;

}
