package com.cellulant.instore.service;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.instore.dto.DeviceIDRequest;
import com.cellulant.instore.dto.SystemConfigurationDto;
import com.cellulant.instore.model.SystemConfiguration;

import javassist.NotFoundException;

public interface SystemConfigurationService {

	public ResponseEntity<Object> saveSystemConfiguration(SystemConfigurationDto systemConfigurationDto,CASUser casUser);

	
	public ResponseEntity<Object> removeSystemConfigurationById(Long systemConfigurationId,CASUser casUser) throws NotFoundException;
	
	public Page<SystemConfiguration> getSystemConfiguration(CASUser casUser,int page,int size,Long merchantId);
	
	public ResponseEntity<Object> saveDeviceId(DeviceIDRequest deviceIDRequest,CASUser casUser);



	
}
