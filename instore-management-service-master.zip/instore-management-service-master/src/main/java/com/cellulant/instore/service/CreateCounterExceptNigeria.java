package com.cellulant.instore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.exceptions.AlreadyExistExceptions;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.CounterCodes;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterCodesRepository;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.response.CounterResponseDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;
import com.google.gson.Gson;

@Component
public class CreateCounterExceptNigeria implements CounterCreation {

	private static final String ISOCOUNTRYCODE = "ALL";

	@Autowired
	private Utility utility;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private CounterRepository counterRepository;

	@Autowired
	private CounterCodesRepository counterCodesRepository;

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private Utility util;

	@Override
	public ResponseEntity<Object> createCounter(List<CounterDto> counterDto, CASUser casUser, String countryCode) {
		Logger.info("createCounters() Method Start its For Other-Country -->> " + new Gson().toJson(counterDto));
		if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
			Logger.info("User  is Admin And Admin Not Authorized for create counter ");
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
			Logger.info("User is Customer Checking type of customer");
			Long cashier = userRepository.findCashier(casUser.getUserID(), applicationProperties.getCashierRole());
			Long storeManager = userRepository.findCasUser(casUser.getUserID(),
					applicationProperties.getStoreManagerRole());
			if (!Objects.isNull(storeManager)) {
				Logger.info("User is Store Manager  " + new Gson().toJson(storeManager));
				return saveCountersForAll(counterDto, casUser, countryCode);
			} else if (!Objects.isNull(cashier)) {
				Logger.builder(
						" createCounters() method END because user is Cashier.Cashier is Not Authorized For create Counter "
								+ new Gson().toJson(cashier))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Logger.info("User is Merchant So Creating Counter ");
				return saveCountersForAll(counterDto, casUser, countryCode);
			}

		} else {
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}
	}

	public ResponseEntity<Object> saveCountersForAll(List<CounterDto> counterDto, CASUser casUser, String countryCode) {
		Logger.info("saveCountersForAll Method Start -- >>> ");
		List<CounterResponseDto> savedCounterList = new ArrayList<>();
		for (CounterDto dto : counterDto) {

			utility.checkCounterNameAndPhoneAlreadyExistOrNot(dto);
			Stores store = storeRepository.findStoreById(dto.getStoreId());

			if (store != null) {
				utility.validateClientID(store, casUser);
				utility.validateCountry(store, countryCode);

				savedCounterList = this.setCounterCode(dto, store, casUser);
			} else {
				throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
			}
		}

		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS,
				AppConstants.COUNTER_ADDED_SUCCESSFULLY, savedCounterList);
		Logger.builder("saveCounter() method END Success " + response.toString()).info();
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	public List<CounterResponseDto> setCounterCode(CounterDto dto, Stores store, CASUser casUser) {
		List<CounterResponseDto> savedCounterList = new ArrayList<>();
		long maxCounterCodeVal = 0;
		boolean counterCodeExist = true;
		if (dto.getCounterCode() != null && !dto.getCounterCode().isEmpty()) {
			Logger.info("counterCode is present in request -- >>> " + dto.getCounterCode());
			util.validateCounterCodeLength(dto.getCounterCode());
			counterCodeExist = this.checkCounterCodeAlreadyExist(store.getCountry(),
					Long.valueOf(dto.getCounterCode()));
			if (counterCodeExist) {
				Logger.info("counterCode already exist in db  -- >>> " + counterCodeExist);
				throw new AlreadyExistExceptions("CounterCode already exist please select another one");
			}

			int counterCodeTypeId = findCounterCodeTypeID(applicationProperties.getCustom());
			dto.setCounterCodeType(counterCodeTypeId);
			Counters saveCounter = saveInCounters(dto, casUser, maxCounterCodeVal);
			CounterCodes countercodes = this.saveInCounterCodes(dto, casUser, saveCounter, store);
			CounterResponseDto response = this.formulateResponse(dto, countercodes, applicationProperties.getCustom());
			savedCounterList.add(response);

		} else {
			Logger.info("counterCode is not present in request so autoIncrement counterCode -- >>> ");
			int counterCodeTypeId = findCounterCodeTypeID(applicationProperties.getAutoGenerated());
			Logger.info("Requesting for maxCounterCode  -- >>> " + store.getCountry() + "  " + counterCodeTypeId);

			String maxCounterCode = counterCodesRepository.findMaxCounterCode(store.getCountry(), counterCodeTypeId);

			maxCounterCodeVal = (long) Double.parseDouble(maxCounterCode);
			Logger.info("maxCounterCodeVal is-- >>> " + maxCounterCodeVal);
			Logger.info("Checking for counterCode already exist or not  -- >>> ");

			while (counterCodeExist) {
				maxCounterCodeVal = maxCounterCodeVal + 1;
				Logger.info(
						"CounterCode is already exist so incresing maxCounterCode by 1  -- >>> " + maxCounterCodeVal);
				counterCodeExist = this.checkCounterCodeAlreadyExist(store.getCountry(), maxCounterCodeVal);

			}

			dto.setCounterCode(String.valueOf(maxCounterCodeVal));

			dto.setCounterCodeType(counterCodeTypeId);
			Counters saveCounter = saveInCounters(dto, casUser, maxCounterCodeVal);
			CounterCodes countercodes = this.saveInCounterCodes(dto, casUser, saveCounter, store);
			CounterResponseDto response = this.formulateResponse(dto, countercodes,
					applicationProperties.getAutoGenerated());

			savedCounterList.add(response);
		}
		return savedCounterList;

	}

	private boolean checkCounterCodeAlreadyExist(String country, long counterCode) {
		Logger.info("Inside checkCounterCodeAlreadyExist() method  " + country + "  " + counterCode);
		String reponse = counterCodesRepository.findAlreadyExistCounterCode(country, String.valueOf(counterCode));
		if (reponse != null) {
			return true;
		} else {
			return false;
		}

	}

	private Counters saveInCounters(CounterDto dto, CASUser casUser, Long counterCode) {
		Counters counter = utility.setCounterInformation(dto, casUser);
		counter.setCounterCode(counterCode);
		Logger.info("Prepare object to save in counters table  " + counter);
		Counters saveCounter = counterRepository.save(counter);
		Logger.info("Data saved in counters table  " + saveCounter);
		return saveCounter;
	}

	private CounterCodes saveInCounterCodes(CounterDto dto, CASUser casUser, Counters counters, Stores store) {
		CounterCodes counterCodesDto = new CounterCodes();
		counterCodesDto.setCounterCode(String.valueOf(dto.getCounterCode()));
		counterCodesDto.setCounterCodeType(dto.getCounterCodeType());
		counterCodesDto.setCounterId(counters.getCounterId());
		counterCodesDto.setCountry(store.getCountry());
		counterCodesDto.setCreatedBy(casUser.getUserID());
		counterCodesDto.setModifiedBy(casUser.getUserID());
		counterCodesDto.setActive(1);
		Logger.info("Prepare object to save in countercodes table  " + counterCodesDto);
		CounterCodes saveCounterCodes = counterCodesRepository.save(counterCodesDto);
		Logger.info("Data saved in countercodes table  " + saveCounterCodes);
		return saveCounterCodes;
	}

	public CounterResponseDto formulateResponse(CounterDto dto, CounterCodes counterCodesDto,
			String counterCodeTypeName) {
		Logger.builder("Inside formulateResponse method Start() " + dto + "  " + counterCodesDto).info();
		CounterResponseDto counterResponseDto = new CounterResponseDto();
		counterResponseDto.setCounterId(counterCodesDto.getCounterId());
		counterResponseDto.setActive(counterCodesDto.getActive());
		counterResponseDto.setCounterCode(counterCodesDto.getCounterCode());
		counterResponseDto.setCounterName(dto.getCounterName());
		counterResponseDto.setMsisdn(dto.getMsisdn());
		counterResponseDto.setStoreId(dto.getStoreId());
		counterResponseDto.setType(counterCodeTypeName);
		Logger.builder("Return final Response " + counterResponseDto).info();
		return counterResponseDto;
	}

	private int findCounterCodeTypeID(String counterCodeType) {

		Logger.info("findCounterCodeTypeID() method   " + counterCodeType);
		int counterCodeTypeId = counterCodesRepository.findCounterCodeTypeName(counterCodeType);
		Logger.info("fetch counterCodeType Id from db  " + counterCodeTypeId);
		return counterCodeTypeId;
	}

	@Override
	public String getCounterCreationName() {

		return ISOCOUNTRYCODE;
	}

}
