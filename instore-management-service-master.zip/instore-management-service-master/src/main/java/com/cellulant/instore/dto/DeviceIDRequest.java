package com.cellulant.instore.dto;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class DeviceIDRequest {

	@NotNull(message = "deviceID is required")
	@NotEmpty(message = "deviceID can not be null")
	private String deviceID;
	
	@NotNull(message = "role is required")
	@NotEmpty(message = "role can not be null")
	private String role;
}
