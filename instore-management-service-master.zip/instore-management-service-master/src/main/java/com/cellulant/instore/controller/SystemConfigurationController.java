package com.cellulant.instore.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.DeviceIDRequest;
import com.cellulant.instore.dto.SystemConfigurationDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.GenericPagedResponse;
import com.cellulant.instore.service.SystemConfigurationService;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;
import com.google.gson.Gson;

import javassist.NotFoundException;

@RestController
@CrossOrigin(origins = "*")
public class SystemConfigurationController {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private SystemConfigurationService systemConfigurationService;
	
	@Autowired
	private SystemConfigurationRepository repository;
	
	@Autowired
	private ApplicationProperties applicationProperties;
	
	@Autowired
	private Utility utility;
	
	@PostMapping("/addSystemConfiguration")
	public ResponseEntity<Object>  addSystemConfiguration(@Valid @RequestBody SystemConfigurationDto systemConfigurationDto,@AuthenticationPrincipal CASUser casUser){
		Logger.info("addSystemConfiguration Methoad Start "+new Gson().toJson(systemConfigurationDto));
		return systemConfigurationService.saveSystemConfiguration(systemConfigurationDto, casUser);
	}
	

	
	@DeleteMapping("/deleteSystemConfiguration/{systemConfigurationId}")
	public ResponseEntity<Object> deleteSystemConfiguration(@PathVariable Long systemConfigurationId,@AuthenticationPrincipal CASUser casUser) throws NotFoundException{
		Logger.info("deleteSystemConfiguration Methoad Start systemConfiguration id is "+systemConfigurationId);
		return systemConfigurationService.removeSystemConfigurationById(systemConfigurationId, casUser);
	}
	
	
	
	@GetMapping("/fetchSystemConfiguration")
	public ResponseEntity<Object> fetchSystemConfiguration(@RequestParam(name = "page", required = false,defaultValue = "1") int page,
			@RequestParam(name = "merchantId", required = true) Long merchantId,
			@RequestParam(name = "size", required = false,defaultValue = "10") int size,
			@AuthenticationPrincipal CASUser casUser) throws NotFoundExceptions, NotFoundException{
			Logger.info("fetchSystemConfiguration Method Start ");
			List<SystemConfiguration> systemConfigurationList = repository.getMerchanthasConfigValueOrNot(merchantId);
			Logger.info(" systemConfigurationList --->> "+systemConfigurationList);
			
			if(systemConfigurationList!=null) {
				if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) { 
					Logger.info("user is Admin");
					Page<SystemConfiguration> systemConfigurationPagingList = systemConfigurationService.getSystemConfiguration(casUser, page, size, merchantId);
					GenericPagedResponse<SystemConfiguration> pageResponse = GenericPagedResponse.<SystemConfiguration>builder()
		    			    .success(true).statusCode(AppConstants.SUCCESS_STATUS).message(AppConstants.SUCCESS_MESSAGE).size((long) size)
		                    .totalItems(systemConfigurationPagingList.getTotalElements()).totalPages((long) systemConfigurationPagingList.getTotalPages())
		                    .currentPage(page).data(systemConfigurationPagingList.getContent()).build();
		    		return new ResponseEntity<>(pageResponse, HttpStatus.OK);
				} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
					return getSystemConfigurationForCustomer(merchantId,page,size,casUser);
				}
			}
			 else {
				 
			     throw new NotFoundException(AppConstants.SYSTEM_CONFIGURATION_NOT_FOUND);
			}
		
		Logger.info("User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
		 
	}



	private ResponseEntity<Object> getSystemConfigurationForCustomer(Long merchantId, int page, int size, CASUser casUser) {
		
		Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole());
		Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole());
		if (userIdForStoreManager != null) {
			
			Logger.builder(" fetchSystemConfiguration() method END Not Authorized User for Store Manager")
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if (userIdForCashier != null) {
			Logger.builder(" fetchSystemConfiguration() method END Not Authorized User for cashier" )
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		}else {
			Logger.info("Its Merchant " );
			if(merchantId.equals(casUser.getCustomerID())) {
				Page<SystemConfiguration> systemConfigurationPagingList = systemConfigurationService.getSystemConfiguration(casUser, page, size, merchantId);
				GenericPagedResponse<SystemConfiguration> pageResponse = GenericPagedResponse.<SystemConfiguration>builder()
	    			    .success(true).statusCode(AppConstants.SUCCESS_STATUS).message(AppConstants.SUCCESS_MESSAGE).size((long) size)
	                    .totalItems(systemConfigurationPagingList.getTotalElements()).totalPages((long) systemConfigurationPagingList.getTotalPages())
	                    .currentPage(page).data(systemConfigurationPagingList.getContent()).build();
	    		return new ResponseEntity<>(pageResponse, HttpStatus.OK);
			} else {
				Logger.builder(" fetchSystemConfiguration() method END Not Authorized User for merchant ")
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}
		}

	}
	
	@PostMapping("/addDeviceID")
	public ResponseEntity<Object> addDeviceId(@Valid @RequestBody DeviceIDRequest deviceIDRequest,@AuthenticationPrincipal CASUser casUser){
		Logger.info("In addDeviceId method "+new Gson().toJson(deviceIDRequest));
		utility.validateRole(deviceIDRequest.getRole());
		return systemConfigurationService.saveDeviceId(deviceIDRequest, casUser);
		
	}

	
	
}
