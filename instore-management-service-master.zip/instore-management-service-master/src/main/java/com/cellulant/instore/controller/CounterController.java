package com.cellulant.instore.controller;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.DeviceIdDto;
import com.cellulant.instore.dto.UpdateCounterDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.CounterDto;
import com.cellulant.instore.service.CheckCustomCounterCode;
import com.cellulant.instore.service.CounterCreation;
import com.cellulant.instore.service.CounterCreationFactory;
import com.cellulant.instore.service.CounterService;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;
import com.google.gson.Gson;
import com.itextpdf.text.DocumentException;

@RestController
@Validated
@CrossOrigin(origins = "*")
public class CounterController {

	private static final String ISOCOUNTRYCODEFORNIGERIA = "NGA";

	@Autowired
	private CounterService counterService;

	@Autowired
	private CounterRepository counterRepository;

	@Autowired
	private StoreRepository storeRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CheckCustomCounterCode checkCustomCounterCode;

	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private Utility util;

	@GetMapping("/fetchCounters")
	public ResponseEntity<Object> getCounters(@AuthenticationPrincipal CASUser casUser) {

		Logger.builder(" getCounters() method START ").info();
		return counterService.getCounters(casUser);

	}

	@PostMapping("/createCounter")
	public ResponseEntity<Object> saveCounter(
			@RequestBody @NotEmpty(message = "Input Counter list cannot be empty.") List<@Valid CounterDto> counterDto,
			@RequestHeader(value = "X-Country-Code", required = true) String xCountryCode,
			@AuthenticationPrincipal CASUser casUser) {

		Logger.builder(
				" saveCounter() method START " + new Gson().toJson(counterDto) + " X-Country-Code  " + xCountryCode)
				.info();
		String isoCountryCode = getIsoCountryCode(xCountryCode.toUpperCase());
		Logger.builder(" IsoCounrtyCode is " + isoCountryCode).info();
		
		CounterCreation counterCreationFactory = CounterCreationFactory.createInstance(isoCountryCode);
		return counterCreationFactory.createCounter(counterDto, casUser, xCountryCode);
	}

	@GetMapping("/checkCustomCounterCode")
	public ResponseEntity<Object> checkCustomCounterCode(
			@RequestParam(name = "countryCode", required = true) String countryCode,
			@RequestParam(name = "counterCode", required = true) String counterCode) {
		Logger.builder(" checkCustomeCounterCode() method START with countryCode--> " + countryCode + " counterCode--> "
				+ counterCode).info();
		util.validateCounterCodeLength(counterCode);
		return checkCustomCounterCode.checkCustomCounterCodeAlreadyExist(countryCode, counterCode);
	}

	private String getIsoCountryCode(String xCountryCode) {
		if (xCountryCode.equals(ISOCOUNTRYCODEFORNIGERIA)) {
			return applicationProperties.getXCountryCodeNigeria();
		}

		else {

			return applicationProperties.getXCountryCodeForOther();
		}

	}

	@PutMapping("/updateCounter")
	public ResponseEntity<Object> updateCounterInfo(@Valid @RequestBody UpdateCounterDto updateCounterDto,
			@RequestHeader(value = "X-Country-Code", required = true) String xCountryCode,
			@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" updateCounterInfo() method START " + new Gson().toJson(updateCounterDto)).info();
		Counters counter = counterRepository.findCounterByCounterCodeAndxcountryCode(updateCounterDto.getCounterId(),
				xCountryCode);
		Logger.info("counter Object " + counter);
		if (counter != null) {
			return counterService.updateCounter(updateCounterDto, casUser, counter);
		} else {
			throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
		}

	}

	@GetMapping("/fetchStoreCounter/{storeId}")
	public ResponseEntity<Object> getStoreCounter(@PathVariable Long storeId,
			@RequestParam(name = "searchCounters", required = false, defaultValue = "") String searchCounters,
			@RequestParam(name = "page", required = false, defaultValue = "1") int page,
			@RequestParam(name = "size", required = false, defaultValue = "10") int size,

			@AuthenticationPrincipal CASUser casUser)
			throws NotFoundExceptions, PermissionException, IOException, DocumentException {

		Logger.builder(" getStoreCounter() method START " + new Gson().toJson(casUser)).info();

		Stores store = storeRepository.findStoreById(storeId);
		if (store == null) {
			throw new NotFoundExceptions("Store Id Not Found");
		}

		return counterService.findCountersByStoreId(storeId, searchCounters, page, size, casUser);

	}

	@PutMapping("/updateDeviceID")
	public ResponseEntity<Object> updateDeviceIdOnCounters(@Valid @RequestBody DeviceIdDto deviceIdDto,
			@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" updateDeviceIdOnCounters() method START " + new Gson().toJson(deviceIdDto)).info();
		return counterService.updateDeviceId(deviceIdDto, casUser);

	}

	@DeleteMapping("/deleteCounter/{counterCode}")
	public ResponseEntity<Object> deleteCounterByCounterCode(@PathVariable String counterCode,
			@RequestHeader(value = "X-Country-Code", required = true) String xCountryCode,
			@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" deleteCounterByCounterCode() method START " + counterCode).info();
		Counters counter = counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode, xCountryCode);
		if (counter != null) {
			return counterService.deleteCounter(counterCode, casUser, counter);
		} else {
			throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
		}

	}

	@GetMapping("fetchCounterById/{counterId}")
	public ResponseEntity<Object> getCounterById(@PathVariable String counterId,
			@RequestHeader(value = "X-Country-Code", required = true) String xCountryCode,
			@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" getCounterById() method START " + counterId).info();
		Counters counter = counterRepository.findCounterByCounterCodeAndxcountryCode(counterId, xCountryCode);
		Logger.info("counter Object " + counter);
		if (counter != null) {
			return counterService.fetchCounterById(counterId, casUser, counter);
		} else {
			throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
		}

	}

	@GetMapping("fetchCashier/info")
	public ResponseEntity<Object> getCashierDetail(@RequestParam(name = "role", required = true) String role,
			@AuthenticationPrincipal CASUser casUser) {
		Logger.builder(" getCashierDetail() method START ").info();
		return counterService.fetchCashierDetail(role, casUser);
	}

}
