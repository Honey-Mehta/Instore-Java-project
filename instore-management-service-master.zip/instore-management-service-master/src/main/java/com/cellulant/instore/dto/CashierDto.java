package com.cellulant.instore.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CashierDto {
	
	
	@NotNull(message = "username is required")
	@NotEmpty(message = "username can not be null")
	private String username;
	
	@NotNull(message = "msisdn number is required")
	@NotEmpty(message = "msisdn can not be null")
	private String msisdn;
	
	
	
	private String counterCode;
	
	@NotNull(message = "Email Address  is required")
	@NotEmpty(message = "Email Address can not be null")
	private String emailAddress;
	
	@NotEmpty(message = "fullName can not be null")
	@NotNull(message = "fullName   is required")
	private String fullName;
	
	@NotNull(message = "idNumber is required")
	private String idNumber;
	
	@NotNull(message = "roleId can not be null")
	@Min(value = 1, message = "roleId should not be smaller than 1")
	private int roleId;
	
	@NotNull(message = "storeId can not be null")
	private Long storeId;
	 

}
