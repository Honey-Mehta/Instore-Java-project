package com.cellulant.instore.service;
public interface QRCodeService {

    byte[] generateQRCode(String qrContent, int width, int height);

}
