package com.cellulant.instore.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class StoresParam {
	
    private Long storeId;
	
	private String storeName;
	
	private String city;
	private String address;
	private String msisdn;
	private String country;
	
	private Long totalCounter;
	private String storeManager;
	
	
	
	

}
