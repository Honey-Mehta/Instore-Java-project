package com.cellulant.instore.exceptions;

import java.io.IOException;
import java.security.NoSuchProviderException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cellulant.core.logging.Benchmark;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.response.ErrorResponse;
import com.cellulant.instore.response.Response;
import com.cellulant.instore.utils.AppConstants;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@Override
	public ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		String paramName = ex.getParameterName();
		String message = paramName + " is required";
		Logger.info(AppConstants.EXCEPTION_OCCUR + message);
		Response response = new Response(AppConstants.MISSING_PARAMETER, message);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		String error = ex.getLocalizedMessage();
		Logger.info(AppConstants.EXCEPTION_OCCUR + error);
		Response response = new Response(HttpStatus.BAD_REQUEST.value(), error);
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ResponseBody
	@ExceptionHandler(MissingRequestHeaderException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<Object> handleMissingRequestHeaderException(MissingRequestHeaderException ex) {
		long start = Benchmark.start();
		Logger.builder("MissingRequestHeaderException Exception occurs : " + ex).start(start).error();
		ErrorResponse error = new ErrorResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, ex.getLocalizedMessage());

		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, ex.getMessage());
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(NullPointerException.class)
	public final ResponseEntity<Object> handleNullPointerException(NullPointerException ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, details);
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}


	@ExceptionHandler(NoSuchProviderException.class)
	public final ResponseEntity<Object> handleNoSuchProviderException(NoSuchProviderException ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		String message = "Security provider is not available";
		ErrorResponse error = new ErrorResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE, message, null, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IOException.class)
	public final ResponseEntity<Object> handleIOException(IOException ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST); 
	}

	@ExceptionHandler(JsonParseException.class)
	public final ResponseEntity<Object> handleJsonParseException(JsonParseException ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());

		ErrorResponse error = new ErrorResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(JsonSyntaxException.class)
	public final ResponseEntity<Object> handleJsonSyntaxException(JsonSyntaxException ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());

		ErrorResponse error = new ErrorResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public final ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex,
			WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());

		ErrorResponse error = new ErrorResponse(false, AppConstants.BAD_REQUEST_STATUS_CODE,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ResponseBody
	@ExceptionHandler(InvalidInputException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<Object> invalidInputExceptionHandler(InvalidInputException ex) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(false, AppConstants.INVALID_PARAMETER, ex.getLocalizedMessage(), null,
				details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(ValidationException.class)
	public final ResponseEntity<Object> handleValidationException(Exception ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.VALIDATION_FAILED, null,
				details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NumberFormatException.class)
	public final ResponseEntity<Object> handleNumberFormatException(NumberFormatException ex, WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getMessage());
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse(true, AppConstants.SUCCESS_STATUS,
				AppConstants.REQUEST_UNABLE_TO_PROCESS, null, details);
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public final ResponseEntity<Object> handleMethodArgumentTypeMismatchException(Exception ex, WebRequest request) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = ErrorResponse.builder().statusCode(AppConstants.BAD_REQUEST_STATUS_CODE)
				.message(AppConstants.METHOD_ARGUMENT_MISMATCH).data(details).build();
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<String> errors = new ArrayList<>();
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		ex.getBindingResult().getAllErrors().forEach(error -> {

			String errorMessage = error.getDefaultMessage();

			errors.add(errorMessage);
		});
		String message = errors.get(0);
		Response response = new Response(AppConstants.MISSING_PARAMETER, message);
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	@ResponseBody
	@ExceptionHandler(MissingParameterException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public Response missingParameterExceptionHandler(MissingParameterException ex) {
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		return new Response(AppConstants.MISSING_PARAMETER, ex.getMessage());
	}

	@ResponseBody
	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public Response onConstraintValidationException(ConstraintViolationException e) {
		List<String> errors = new ArrayList<>();
		Logger.info(AppConstants.EXCEPTION_OCCUR + e.getLocalizedMessage());
		for (ConstraintViolation violation : e.getConstraintViolations()) {
			errors.add(violation.getMessage());
		}
		String message = errors.get(0);
		return new Response(AppConstants.MISSING_PARAMETER, message);
	}

	@ExceptionHandler(NotFoundExceptions.class)
	public ResponseEntity<Object> handlerException(NotFoundExceptions ex) {
		List<String> details = new ArrayList<>();
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		details.add(ex.getLocalizedMessage());
	
		ErrorResponse error = ErrorResponse.builder().success(false).statusCode(AppConstants.NOT_FOUND)
				.message(ex.getMessage()).data(null).build();

		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(PermissionException.class)
	public ResponseEntity<Object> handlerPermissionException(PermissionException ex) {
		List<String> details = new ArrayList<>();
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = ErrorResponse.builder().success(false).statusCode(AppConstants.NOT_AUTHORIZED)
				.message(AppConstants.PERMISSION_FAILED).data(ex.getLocalizedMessage()).build();

		return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(AlreadyExistExceptions.class)
	public ResponseEntity<Object> handlerPhoneNumberAlreadyExistException(AlreadyExistExceptions ex) {
		List<String> details = new ArrayList<>();
		Logger.info(AppConstants.EXCEPTION_OCCUR + ex.getLocalizedMessage());
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = ErrorResponse.builder().success(false).statusCode(AppConstants.BAD_REQUEST_STATUS_CODE)
				.message(ex.getMessage()).data(null).build();

		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

}
