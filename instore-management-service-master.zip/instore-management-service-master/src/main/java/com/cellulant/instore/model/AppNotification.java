package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
@Entity
@Table(name = "appnotifications")
public class AppNotification extends Actionable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AppNotificationID",unique = true,nullable = false)
	private Long appNotificationId;
	
	@Column(name = "merchantNotficationID",nullable = false)
	private Long merchantNotificationId;
	
	@Column(name="deviceID")
	private String deviceId;
	
	@Column(name = "title")
	private String title;
	
	@Column(name = "message")
	private String message;
	
	
	@Column(name = "numberOfSends",nullable = false)
	private Integer numberOfSends;
	
	@Column(name = "status",nullable = false)
	private Integer status;
	
	@Column(name = "statusHistory")
	private String statusHistory;
	
	@Column(name = "requestPayload")
	private String requestPayload;
	
	@Column(name = "responsePayload")
	private String responsePayload;
	
	@Column(name = "active")
	private Integer active;		
	
	

}
