package com.cellulant.instore.dto;

import com.cellulant.instore.model.IsReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CountersFinalResponse {


	private Long counterId;

	private String counterName;

	private String msisdn;
	
	private String storeName;
	
	private String username;
	
	private String counterCode;
	
	private IsReference isReference;
	
	private QRCode qrCode;


}

