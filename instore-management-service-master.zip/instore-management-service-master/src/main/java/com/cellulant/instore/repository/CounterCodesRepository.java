package com.cellulant.instore.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cellulant.instore.model.CounterCodes;

public interface CounterCodesRepository extends JpaRepository<CounterCodes, Long> {

	@Query(nativeQuery = true, value = "SELECT max(CAST(c.counterCode AS DECIMAL(19,0))) FROM countercodes c where c.country=:country AND c.counterCodeType=:counterCodeType AND c.active!=0")
	String findMaxCounterCode(@Param("country") String country, @Param("counterCodeType") int counterCodeType);

	@Query(value = "select c.counterCode from CounterCodes c where c.counterCode=:counterCode And c.active!=0 AND c.country =:country")
	String findAlreadyExistCounterCode(@Param("country") String country, @Param("counterCode") String counterCode);

	
	@Query(value = "select c.id from CounterCodeType c where c.counterCodeTypeName=:counterCodeType")
	int findCounterCodeTypeName(@Param("counterCodeType") String counterCodeType);

	@Query(value = "SELECT c from CounterCodes c where c.counterId=:counterId AND c.active!=0 AND c.counterCodeType=:provider")
	CounterCodes findExistingProvider(@Param("provider") int provider, @Param("counterId") Long counterId);
	
	@Query(value = "SELECT cc from CounterCodes cc WHERE cc.counterId=:counterID AND cc.active!=0 ")
	List<CounterCodes> findConterCodesByCounterID(@Param("counterID")Long counterID);

	@Transactional
	@Modifying
	@Query("UPDATE CounterCodes cc  SET cc.active=0 WHERE cc.counterId=:counterId AND cc.active!=0")
	int updateCounterCodesActive(@Param("counterId") Long counterId);
	
	@Transactional
	@Modifying
	@Query("UPDATE CounterCodes cc  SET cc.active=0 WHERE cc.counterCode=:counterCode AND cc.active!=0")
	int updateCounterCodesActiveBycounterCode(@Param("counterCode") String counterCode);

}
