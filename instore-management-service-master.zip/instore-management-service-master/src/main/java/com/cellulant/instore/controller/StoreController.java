package com.cellulant.instore.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.StoreRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.request.StoreDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.service.StoreService;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.cellulant.instore.utils.Utility;
import com.google.gson.Gson;

import javassist.NotFoundException;

@RestController
@CrossOrigin(origins = "*")
public class StoreController {

	@Autowired
	private StoreService storeService;
	
	@Autowired
	private StoreRepository storeRepository;


	@Autowired
	private ApplicationProperties applicationProperties;
	
	@Autowired
	private StoreAssignmentRepository storeAssignmentRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	
	
	

	
	@GetMapping("/fetchStores/all")
	public ResponseEntity<Object> getStores(@RequestParam(name = "searchStores", required = false, defaultValue = "") String searchStores,
			@RequestHeader(value = "X-Country-Code", required = true)  String xCountryCode,
			@RequestParam(name = "page", required = false,defaultValue = "1") int page,
			@RequestParam(name = "casUserId", required = false) Long casUserId,
	        @RequestParam(name = "size", required = false,defaultValue = "10") int size,
	        @AuthenticationPrincipal CASUser casUser){
		Logger.builder(" fetch all stores () method START " +casUser).info();
		Logger.builder(" getStores() method START "+xCountryCode+" CasId "+casUser.getUserID()).info();
	      return storeService.fetchStoresWithPagination(searchStores, page, size, casUser, xCountryCode,casUserId);
	        
	}
	
	
	
	@GetMapping("/fetchStores")
	public ResponseEntity<Object> getStoresWithoutPagination(@RequestHeader(value = "X-Country-Code", required = true)  String xCountryCode,
			@AuthenticationPrincipal CASUser casUser) {
				Logger.builder(" getStoresWithoutPagination() method START "+new Gson().toJson(casUser)).info();
			    return storeService.fetchStores(casUser,xCountryCode);
		
	}
	
	
	

	@PostMapping("/createStore")
	public ResponseEntity<Object> saveStore(@Valid @RequestBody StoreDto storeDto,
			@AuthenticationPrincipal CASUser casUser) {
		 Logger.builder(" saveStore() method START "+new Gson().toJson(storeDto)).info();
		 Utility.validateCountryCode(storeDto.getCountryID());
		 return storeService.createStores(storeDto, casUser);

	}

	@PutMapping("/updateStore")
	public ResponseEntity<Object> updateStore(@Valid @RequestBody StoreDto storeDto,@AuthenticationPrincipal CASUser casUser) throws NotFoundException {
		 Logger.builder(" updateStore() method START "+new Gson().toJson(storeDto)).info();
		 return storeService.updateStoresInfo(storeDto, casUser);

	}

	@GetMapping("fetchStore/{id}")
	public ResponseEntity<Object> getStoresById(@PathVariable Long id, @AuthenticationPrincipal CASUser casUser) throws NotFoundException {

		Logger.builder(" getStoresById() method START " + id).info();
		Stores store = storeRepository.findStoreById(id);

		if (store != null) {
			return storeService.findStoreDetail(id, casUser);

		} else {
			throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
		}

	}
	
	
	 @DeleteMapping("/deleteStoreById/{storeId}")
		public ResponseEntity<Object> deleteStoreById(@PathVariable Long storeId,@AuthenticationPrincipal CASUser casUser) throws NotFoundExceptions {
		
		 Logger.builder(" deleteStoreById() method START "+storeId).info();
			SuccessResponse response =null;
			Stores store = storeRepository.findStoreById(storeId);
			if(store!=null) {
				if(casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
					Logger.builder(" deleteStoreById() method END. Not Authorized User because its admin " + new Gson().toJson(response))
							.info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				} else if(casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
					return getCustomerDataForDeleteStore(storeId,casUser);
				}
				
				
			}else
			{
				throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
			}
			 Logger.info("User is Not Admin Not Customer ");
			 throw new PermissionException(AppConstants.PERMISSION_FAILED);
			
		}



	private ResponseEntity<Object> getCustomerDataForDeleteStore(Long storeId, CASUser casUser) {
		SuccessResponse response = new SuccessResponse(false, AppConstants.INTERNAL_ERROR_STATUS_CODE, AppConstants.INTERNAL_SERVER_ERROR_MESSAGE, null); 
		Logger.info("user is Custommer");
		Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
				applicationProperties.getCashierRole());
		Long storeManagerId = userRepository.findCasUser(casUser.getUserID(),
				applicationProperties.getStoreManagerRole());
		if(storeManagerId!=null) {
			Logger.builder(" deleteStoreById() method END Not Authorized User because it store Manager" + new Gson().toJson(response))
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else if(userIdForCashier!=null) {
			Logger.builder(" deleteStoreById() method END Not Authorized User because its cashier " + new Gson().toJson(response))
					.info();
			throw new PermissionException(AppConstants.PERMISSION_FAILED);
		} else {
			Logger.info("user is  Merchant");
			Stores stores =  storeRepository.findStoresByStoreIdAndClientId(storeId, casUser.getCustomerID());
			if(stores!=null) {
				int i=storeService.deleteStoreById(storeId);
				if(i>=1) {
					 Logger.builder("deleteStoreById() method END "+response.toString()).info();
					 response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.STORE_DELETED_SUCCESSFULLY, null);
					return new ResponseEntity<>(response, HttpStatus.OK);
				}
			} else {
				Logger.builder(" deleteStoreById() method END Not Authorized User " + new Gson().toJson(response))
						.info();
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			}
		}
		throw new PermissionException(AppConstants.PERMISSION_FAILED);
		
	}
	
	@GetMapping("/fetchStoresAndCounters")
	public ResponseEntity<Object> getStoresCounters(@RequestParam(name = "role", required = true, defaultValue = "") String role,
			@AuthenticationPrincipal CASUser casUser){
		Logger.info("getStoresCounters Method Start -->>> "+new Gson().toJson(casUser)+" role  "+role);
		return storeService.fetchStoresAndCounter(casUser, role);
	}
	

}
