package com.cellulant.instore.response;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StoreDetail {
	
	private Long storeId;
	
	private String storeName;
	
	private String storeMsisdn;
	
	@JsonIgnore
	private String counterName;
	
	@JsonIgnore
	private String counterMsisdn;
	

}
