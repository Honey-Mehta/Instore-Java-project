package com.cellulant.instore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "stores")
@EqualsAndHashCode(callSuper = true)
public class Stores extends Actionable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "storeID",unique = true,nullable = false)
	private Long storeId;
	
	@Column(name = "clientID",nullable = false)
	private Long clientID;
	
	@Column(name = "storeName")
	private String storeName;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "storeCode")
	private String storeCode;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "active")
	private Integer active;
	
	@Column(name = "serviceCode")
	private String serviceCode;

	
}
