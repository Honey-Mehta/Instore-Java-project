package com.cellulant.instore.exceptions;

public class AlreadyExistExceptions extends RuntimeException {
	
	public AlreadyExistExceptions(String message, Throwable cause) {
		super(message, cause);
		
	}

	public AlreadyExistExceptions(String message) {
		super(message);
		
	}

	public AlreadyExistExceptions(Throwable cause) {
		super(cause);
		
	}
}
