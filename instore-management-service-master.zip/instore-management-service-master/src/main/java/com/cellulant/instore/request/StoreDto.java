package com.cellulant.instore.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class StoreDto {
	
	private Long storeId;

	@NotNull(message = "city is required")
	@NotEmpty(message = "city can not be null")
	private String city;
	
	
	private String countryID;
	
	@NotNull(message = "address is required")
	@NotEmpty(message = "address can not be null")
	private String address;
	
	
	private String description;
	
	@NotNull(message = "storeName is required")
	@NotEmpty(message = "storeName can not be null")
	private String storeName;

	private Integer active;
	
	private String storeCode;
	
	
	
}
