package com.cellulant.instore.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cellulant.cas.auth.model.CASUser;
import com.cellulant.cas.auth.model.CustomerLevel;
import com.cellulant.core.logging.Logger;
import com.cellulant.instore.dto.CounterAndCashierCountDto;
import com.cellulant.instore.dto.StoreCounterCountDto;
import com.cellulant.instore.exceptions.NotFoundExceptions;
import com.cellulant.instore.exceptions.PermissionException;
import com.cellulant.instore.model.Counters;
import com.cellulant.instore.model.MerchantNotification;
import com.cellulant.instore.model.Stores;
import com.cellulant.instore.model.SystemConfiguration;
import com.cellulant.instore.repository.CounterRepository;
import com.cellulant.instore.repository.MerchantNotificationRepository;
import com.cellulant.instore.repository.StoreAssignmentRepository;
import com.cellulant.instore.repository.SystemConfigurationRepository;
import com.cellulant.instore.repository.UserRepository;
import com.cellulant.instore.response.GenericPagedResponse;
import com.cellulant.instore.response.MerchantDetail;
import com.cellulant.instore.response.MerchantDetailDto;
import com.cellulant.instore.response.SuccessResponse;
import com.cellulant.instore.utils.AppConstants;
import com.cellulant.instore.utils.ApplicationProperties;
import com.google.gson.Gson;

@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private CounterRepository counterRepository;
	
	@Autowired
	private SystemConfigurationRepository systemConfigurationRepository;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private StoreAssignmentRepository storeAssignmentRepository;
	
	
	@Autowired
	private MerchantNotificationRepository merchantNotificationRepository;

	@Autowired
	private com.cellulant.instore.repository.StoreRepository storeRepository;
	
	@Autowired
	private ApplicationProperties applicationProperties;

	@Override
	public ResponseEntity<Object> getMerchantDetailByCounterCode(String counterCode,String xCountry) {

		Logger.builder(" getMerchantDetailByCounterCode() method START " + counterCode).info();
		SuccessResponse response = null;
			Counters counter = counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,xCountry);
			Logger.info("Counter is available or not  "+new Gson().toJson(counter));
			
			if (counter != null ) {
				Stores store = storeRepository.findStoreById(counter.getStoreId());
				SystemConfiguration systemConfiguration = systemConfigurationRepository.findSystemConfigForSettlement(store.getClientID(), applicationProperties.getSettlementType());
				Logger.info("Checking SystemConfiguration "+systemConfiguration);
				 if(systemConfiguration==null||systemConfiguration.getConfigValue().equals("hq")) {
					Logger.info("Settlement Type is Hq");
					 MerchantDetail merchantDetail = merchantNotificationRepository.findMerchantDetailByCounterCode(counterCode,xCountry);
						
						String serviceCode =null;
						return getMerchantInfo(merchantDetail, serviceCode);
					
				}
				 else if (systemConfiguration.getConfigValue().equals("store")){
					Logger.info("Settlement Type is Store");
					MerchantDetail merchantDetail = merchantNotificationRepository.findMerchantDetailByCounterCode(counterCode,xCountry);
					String serviceCode = store.getServiceCode();
					return getMerchantInfo(merchantDetail, serviceCode);
				} else {
					Logger.info("Settlement Type is counter");
					
					MerchantDetail merchantDetail = merchantNotificationRepository.findMerchantDetailByCounterCode(counterCode,xCountry);
					String serviceCode = counter.getServiceCode();
					return getMerchantInfo(merchantDetail, serviceCode);
				}
				
			} 
				Logger.builder(" getMerchantDetailByCounterCode() method END " + new Gson().toJson(response)).info();
				throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
		
	}
	
	public ResponseEntity<Object> getMerchantInfo(MerchantDetail merchantDetail,String serviceCode){
		MerchantDetailDto merchantDetailDto = new MerchantDetailDto();
		merchantDetailDto.setAddress(merchantDetail.getAddress());
		merchantDetailDto.setCounterCode(merchantDetail.getCounterCode());
		merchantDetailDto.setCounterName(merchantDetail.getCounterName());
		merchantDetailDto.setCountryCode(merchantDetail.getCountryCode());
		merchantDetailDto.setCustomerId(merchantDetail.getCustomerId());
		merchantDetailDto.setIsReference(merchantDetail.getIsReference());
		merchantDetailDto.setServiceCode(serviceCode);
		merchantDetailDto.setStoreCode(merchantDetail.getStoreCode());
		merchantDetailDto.setStoreName(merchantDetail.getStoreName());
		SuccessResponse response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
				merchantDetailDto);
		Logger.builder(" getMerchantDetailByCounterCode() method END  with response" + new Gson().toJson(response)).info();
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> getMerchantDetailOnTheBasisOfClientId(Long clientId)  {
		
		Logger.builder(" getMerchantDetailOnTheBasisOfClientId() method START " + clientId).info();
		SuccessResponse response = null;
			List<MerchantNotification> merchantNotification = merchantNotificationRepository.findByClientId(clientId);

			if (merchantNotification == null || merchantNotification.isEmpty()) {
				throw new NotFoundExceptions(AppConstants.CLIENTID_NOT_FOUND);

			}
			response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
					merchantNotification);
			Logger.builder(" getMerchantDetailOnTheBasisOfClientId() method END " +new Gson().toJson(response)).info();
			return new ResponseEntity<>(response, HttpStatus.OK);
	}


	
	@Override
	public ResponseEntity<Object> getTotalCounterAndStoresofParticaularClient(Long customerId, CASUser casUser,
			String xCountryCode) {

		Logger.builder(" getTotalCounterAndStoresofParticaularClient() method START " + customerId).info();
		SuccessResponse response = null;
			if (casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
				Logger.builder(" user is Admin").info();
				Long storeCountForAdmin = merchantNotificationRepository.totalStoreForAdmin(xCountryCode);
				Long counterCountForAdmin = merchantNotificationRepository.totalCountersForAdmin(xCountryCode);
				StoreCounterCountDto storeCounterCountDto = new StoreCounterCountDto(storeCountForAdmin,
						counterCountForAdmin);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						storeCounterCountDto);
				Logger.builder(" getTotalCounterAndStoresofParticaularClient() method END returning admin data "
						+ new Gson().toJson(response)).info();
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else if (casUser.getCustomerLevel().equals(CustomerLevel.Code.CUSTOMER)) {
				Logger.info("User is Customer checkimh its type");
				Long userIdForStoreManager = userRepository.findCasUser(casUser.getUserID(),
						applicationProperties.getStoreManagerRole());
				Long userIdForCashier = userRepository.findCashier(casUser.getUserID(),
						applicationProperties.getCashierRole());
				if (userIdForStoreManager != null) {
					Logger.info("Its a store Manager");
					Long storeId = storeAssignmentRepository.findStoreId(userIdForStoreManager);
					Stores stores = storeRepository.findStoreById(storeId);
					if (stores == null) {
						throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
					} else {
						Long storeCountForStoreManager = AppConstants.STORE_COUNT_FOR_STORE_MANAGER;
						Long counterCountForStoreManager = merchantNotificationRepository
								.totalCountersForStoreManager(storeId);
						StoreCounterCountDto storeCounterCountDto = new StoreCounterCountDto(storeCountForStoreManager,
								counterCountForStoreManager);
						response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
								storeCounterCountDto);
						Logger.builder(" fetchStoresAndCountersCount() method END returning Store Manager Data data "
								+ new Gson().toJson(response)).info();
						return new ResponseEntity<>(response, HttpStatus.OK);
					}

				} else if (userIdForCashier != null) {
					Logger.builder(" fetchStoresAndCountersCount() method END Not Authorized User "
							+ new Gson().toJson(response)).info();
					throw new PermissionException(AppConstants.PERMISSION_FAILED);
				} else {
					Logger.builder(" user is Merchant").info();
					Long storeCount = merchantNotificationRepository.totalStoreForCustomer(customerId, xCountryCode);
					Long counterCount = merchantNotificationRepository.totalCountersForCustomer(customerId,
							xCountryCode);
					StoreCounterCountDto storeCounterCountDto = new StoreCounterCountDto(storeCount, counterCount);
					response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
							storeCounterCountDto);
					Logger.builder(
							" getTotalCounterAndStoresofParticaularClient() method END " + new Gson().toJson(response))
							.info();
					return new ResponseEntity<>(response, HttpStatus.OK);

				}
			}
		Logger.info("User is Not Admin Not Customer ");
		throw new PermissionException(AppConstants.PERMISSION_FAILED);

	}

	

	@Override
	public ResponseEntity<Object> getTotalCashierAndCounterOnTheBasisOfStoreId(Long storeId) {

		Logger.builder(" getTotalCashierAndCounterOnTheBasisOfStoreId() method START ").info();
		SuccessResponse response =  null;
			List<Stores> storeList = storeRepository.findByStoreId(storeId);
			if (storeList.isEmpty()) {
				Logger.builder(" getTotalCashierAndCounterOnTheBasisOfStoreId() method END ").info();
				throw new NotFoundExceptions(AppConstants.STORE_NOT_FOUND);
			}
			
				Long counterCount = storeRepository.totalCounters(storeId);
				Long cashierCount = storeRepository.totalCashierOfCounter(storeId);
				CounterAndCashierCountDto counterAndCashierCountDto = new CounterAndCashierCountDto(counterCount,
						cashierCount);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						counterAndCashierCountDto);
				Logger.builder(" getTotalCashierAndCounterOnTheBasisOfStoreId() method END "+new Gson().toJson(response)).info();
				return new ResponseEntity<>(response, HttpStatus.OK);
	}
 
	@Override
	public ResponseEntity<Object> getMerchantDetailOnTheBasisOfEmail(String email, Integer page, Integer size,
			Long storeID,CASUser casUser,String xCountryCode) {
	    storeExistOrNot(storeID);
		Logger.builder(" getMerchantDetailOnTheBasisOfEmail() method START and email is " + email).info();
		Pageable paging = PageRequest.of(page - 1, size,Sort.by("merchantNotificationId").descending());
			if(casUser.getCustomerLevel().equals(CustomerLevel.Code.ADMIN)) {
				throw new PermissionException(AppConstants.PERMISSION_FAILED);
			} else {
				Long userIdForStoreManager = userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
						applicationProperties.getStoreManagerRole(),email);
				Long userIdForCashier = userRepository.findUserIdByUserIdAndRoleAndEmail(casUser.getUserID(),
						applicationProperties.getCashierRole(),email);
			if(userIdForCashier!=null) {
				Logger.info("User is Cashier  "+email);
				Page<MerchantNotification> merchantNotificationsList = merchantNotificationRepository
						.findByUserId(userIdForCashier,paging);
				GenericPagedResponse<MerchantNotification> successResponse= getResponseEntityObjectInPagination(merchantNotificationsList, page, size);
				return new ResponseEntity<>(successResponse,HttpStatus.OK);
			} else if(userIdForStoreManager!=null) {
				Logger.info("User is StoreManager  "+email);
				Long storeId = storeAssignmentRepository.findStoreId(userIdForStoreManager);
				List<Long> counterIdList = counterRepository.findcounterIdListByStoreId(storeId);
				Logger.info("counterIdList on the Basis of Country Code "+counterIdList);
				Page<MerchantNotification> merchantNotificationsList = merchantNotificationRepository
						.findNotificationForMerchantOnTheBasisOfClientAndCountryCode(casUser.getCustomerID(),paging,counterIdList);
				GenericPagedResponse<MerchantNotification> successResponse= getResponseEntityObjectInPagination(merchantNotificationsList, page, size);
				return new ResponseEntity<>(successResponse,HttpStatus.OK);
			}
			else {
				Logger.info("User is Merchant");
				List<Long> counterId; 
				if(storeID!=null) {
					Logger.info("StoreId is "+storeID);
					Stores store = storeRepository.findStoresByStoreIdAndClientId( storeID,casUser.getCustomerID());
					if(store==null) {
						throw new PermissionException("Merchant Admin Accessing other merchant StoreID");
					}
					counterId = counterRepository.findcounterIdListByStoreId(storeID);
					Logger.info("CounterId List "+counterId);
				} else {
					Logger.info("Not Passing StoreId  ");
					 counterId = counterRepository.findcounterIdByClientIdAndCountryCode(casUser.getCustomerID(), xCountryCode);
					 Logger.info("CounterId List without Filter "+counterId);
				}
				
				Logger.info("CounterId on the Basis of Country Code "+counterId);
				Page<MerchantNotification> merchantNotificationsList = merchantNotificationRepository
						.findNotificationForMerchantOnTheBasisOfClientAndCountryCode(casUser.getCustomerID(),paging,counterId);
				GenericPagedResponse<MerchantNotification> successResponse= getResponseEntityObjectInPagination(merchantNotificationsList, page, size);
				return new ResponseEntity<>(successResponse,HttpStatus.OK);
			}
		}
			
	}
	
	private void storeExistOrNot(Long storeID) {
		if(storeID!=null) {
			Stores stores = storeRepository.findStoreById(storeID);
			if(stores==null) {
				throw new NotFoundExceptions("StoreId Not Found");
			}
		}
		
	}

	public GenericPagedResponse<MerchantNotification> getResponseEntityObjectInPagination(Page<MerchantNotification> merchantNotificationsList,Integer page, Integer size){
	
		GenericPagedResponse<MerchantNotification> successResponse = GenericPagedResponse.<MerchantNotification>builder()
			    .success(true).statusCode(AppConstants.SUCCESS_STATUS).message(AppConstants.SUCCESS_MESSAGE).size((long)size)
                .totalItems(merchantNotificationsList.getTotalElements()).totalPages((long) merchantNotificationsList.getTotalPages())
                .currentPage(page).data(merchantNotificationsList.getContent()).build();
		Logger.builder(" getMerchantDetailOnTheBasisOfUserId() method END with Success  "+new Gson().toJson(successResponse)).info();
		return successResponse;
	}

	@Override
	public ResponseEntity<Object> getCounterInfoByCounterCode(String counterCode,String xCountry) {
		Logger.builder(" getCounterInfoByCounterCode() method START with CounterCode " + counterCode).info();
		SuccessResponse response = null;
			Counters counterIsAvailable = counterRepository.findCounterByCounterCodeAndxcountryCode(counterCode,xCountry);
			Logger.info("Counter is available or not  "+new Gson().toJson(counterIsAvailable));
			if (!Objects.isNull(counterIsAvailable) ) {
				
				MerchantDetail merchantInfo = merchantNotificationRepository.findMerchantDetailByCounterCode(counterCode,xCountry);
				response = new SuccessResponse(true, AppConstants.SUCCESS_STATUS, AppConstants.SUCCESS_MESSAGE,
						merchantInfo);
				Logger.builder(" getCounterInfoByCounterCode() method END sending Success response " + new Gson().toJson(response)).info();
				return new ResponseEntity<>(response, HttpStatus.OK);
			} else {
				Logger.builder(" getCounterInfoByCounterCode() method END with Counter Not Found Exception" + new Gson().toJson(response)).info();
				throw new NotFoundExceptions(AppConstants.COUNTER_CODE_NOT_FOUND);
			}
		
	}

}
